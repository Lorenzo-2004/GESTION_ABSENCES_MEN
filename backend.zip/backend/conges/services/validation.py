"""Circuit de validation hiérarchique (CDC §3.2 Phase 3, RG-03, RG-07, RG-10)."""

from django.core.exceptions import ValidationError
from django.db import transaction

from personnels.enums import Role

from ..enums import Avis, Niveau, StatutDemande, TypeAbsence
from ..models import DemandeAbsence, SoldeConge, ValidationWorkflow
from ..regles import TYPES_AVEC_OBSERVATION_OBLIGATOIRE


def _niveau_du_valideur(valideur):
    """Traduit le rôle applicatif du compte en niveau du circuit (matrice RBAC)."""
    compte = getattr(valideur, "compte", None)
    role = compte.role if compte else None

    if role == Role.CHEF_SERVICE:
        return Niveau.CHEF_SERVICE
    if role == Role.DIRECTEUR:
        return Niveau.DIRECTEUR
    raise ValidationError(
        "Seuls le chef de service et le directeur peuvent valider une demande."
    )


def _verifier_communs(demande, valideur, avis, observation):
    if avis not in Avis.values:
        raise ValidationError({"avis": "Avis invalide."})
    if valideur.pk == demande.personnel_id:
        raise ValidationError("Vous ne pouvez pas valider votre propre demande.")
    if demande.type_absence in TYPES_AVEC_OBSERVATION_OBLIGATOIRE and not (observation or "").strip():
        raise ValidationError({"observation": "Une observation motivée est obligatoire (RG-07)."})


def _statut_apres_avis_chef(demande, valideur, avis_favorable):
    """Visa du chef de service : APPROUVE_CS ou REJETE, avec les garde-fous RG-10."""
    if demande.statut_demande != StatutDemande.EN_ATTENTE:
        raise ValidationError("Cette demande n'est plus en attente de visa.")

    if demande.personnel.est_chef_de_service:  # RG-10
        raise ValidationError(
            "La demande d'un chef de service va directement au directeur (RG-10)."
        )

    if valideur.service_id is None or valideur.service_id != demande.personnel.service_id:
        raise ValidationError("Cette demande n'appartient pas à votre service.")

    return StatutDemande.APPROUVE_CS if avis_favorable else StatutDemande.REJETE


def _statut_apres_decision_directeur(demande, valideur, avis_favorable):
    """Décision définitive du directeur : VALIDE_DIR ou REJETE."""
    if valideur.direction_id != demande.personnel.direction_id:
        raise ValidationError("Cette demande n'appartient pas à votre direction.")

    demandeur = demande.personnel
    attend_le_directeur = demande.statut_demande == StatutDemande.APPROUVE_CS or (
        demande.statut_demande == StatutDemande.EN_ATTENTE and demandeur.est_chef_de_service
    )
    if not attend_le_directeur:
        raise ValidationError("Cette demande n'est pas en attente de décision du directeur.")

    return StatutDemande.VALIDE_DIR if avis_favorable else StatutDemande.REJETE


def _decompter_le_solde(demande):
    """Déduit le quota uniquement pour un congé annuel validé d'un non-stagiaire (RG-03)."""
    if demande.type_absence != TypeAbsence.CONGE_ANNUEL:
        return None
    if demande.personnel.est_stagiaire:
        return None

    try:
        solde = SoldeConge.objects.select_for_update().get(
            personnel=demande.personnel,
            annee=demande.annee,
        )
    except SoldeConge.DoesNotExist:
        raise ValidationError("Aucun solde de congé activé pour cette année.")

    solde.deduire_jours(demande.nombre_jours)
    return solde


@transaction.atomic
def enregistrer_avis(demande, valideur, avis, observation=""):
    """Enregistre un visa (chef de service) ou une décision (directeur).

    Verrouille la demande pour que deux valideurs ne puissent pas avancer le même
    dossier en parallèle, puis met à jour le statut et, le cas échéant, le solde.
    """
    demande = DemandeAbsence.objects.select_for_update().get(pk=demande.pk)

    niveau = _niveau_du_valideur(valideur)
    _verifier_communs(demande, valideur, avis, observation)
    avis_favorable = avis == Avis.FAVORABLE

    if niveau == Niveau.CHEF_SERVICE:
        nouveau_statut = _statut_apres_avis_chef(demande, valideur, avis_favorable)
    else:
        nouveau_statut = _statut_apres_decision_directeur(demande, valideur, avis_favorable)

    validation = ValidationWorkflow.objects.create(
        demande=demande,
        valideur=valideur,
        niveau=niveau,
        avis=avis,
        observation=observation or "",
    )

    demande.statut_demande = nouveau_statut
    demande.save(update_fields=["statut_demande"])

    if nouveau_statut == StatutDemande.VALIDE_DIR:
        _decompter_le_solde(demande)

    return validation
