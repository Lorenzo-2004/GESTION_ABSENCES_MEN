"""Soldes de congé : activation RH, report des reliquats et archivage (CDC §1.2, §3.2)."""

from django.core.exceptions import ValidationError
from django.db import transaction

from ..enums import StatutDemande, TypeAbsence
from ..models import DecisionConge, DemandeAbsence, SoldeConge
from ..regles import DROIT_ANNUEL_DEFAUT


def _reliquat_a_reporter(personnel, annee):
    """Reliquat non consommé de l'année précédente (jamais négatif)."""
    precedent = personnel.soldes.filter(annee=annee - 1).first()
    if precedent is None:
        return 0
    return max(precedent.solde_restant, 0)


def solde_ou_creer(personnel, annee, droit_annuel=DROIT_ANNUEL_DEFAUT):
    """Retourne le solde de l'année, en le créant avec le report de reliquat si besoin.

    Renvoie un couple (solde, cree).
    """
    solde = personnel.soldes.filter(annee=annee).first()
    if solde is not None:
        return solde, False

    solde = SoldeConge.objects.create(
        personnel=personnel,
        annee=annee,
        droit_annuel=droit_annuel,
        report_anterieur=_reliquat_a_reporter(personnel, annee),
    )
    return solde, True


@transaction.atomic
def reporter_reliquats(annee_source):
    """Reporte sur l'année suivante les reliquats de tous les soldes d'une année.

    Appelé par la RH en fin d'exercice : c'est ce qui garantit « le cumul/report des
    quotas de congés sans perte de reliquats » exigé par le CDC §1.2.
    """
    annee_cible = annee_source + 1
    soldes_reportes = []

    for solde in SoldeConge.objects.filter(annee=annee_source).select_related("personnel"):
        cible, _ = SoldeConge.objects.get_or_create(
            personnel=solde.personnel,
            annee=annee_cible,
            defaults={"droit_annuel": solde.droit_annuel, "report_anterieur": 0},
        )
        cible.report_anterieur = max(solde.solde_restant, 0)
        cible.save()
        soldes_reportes.append(cible)

    return soldes_reportes


@transaction.atomic
def valider_et_activer_par_rh(decision):
    """Valide la décision et ouvre (ou récupère) le solde de chaque année citée.

    Un stagiaire ne peut pas être activé : la décision est refusée avant tout enregistrement.
    """
    decision.clean()  # RG-02 / RG-04
    decision.est_valide = True
    decision.save()

    soldes = []
    for annee in decision.annees():
        solde, _ = solde_ou_creer(
            decision.personnel, annee, droit_annuel=DROIT_ANNUEL_DEFAUT
        )
        soldes.append(solde)

    if not soldes:
        raise ValidationError(
            "La décision ne cite aucune année exploitable dans son champ « années du titre »."
        )
    return soldes


def droits_annuels_du_personnel(personnel, annee):
    """Synthèse des droits d'un agent pour une année, destinée à l'API et au frontend."""
    solde = personnel.get_solde_actif(annee)
    if solde is None:
        return {
            "annee": annee,
            "actif": False,
            "droit_annuel": 0,
            "report_anterieur": 0,
            "jours_pris": 0,
            "jours_engages": 0,
            "solde_restant": 0,
            "jours_disponibles": 0,
            "decision_valide": personnel.verifier_decision_annuelle(annee),
        }

    return {
        "annee": annee,
        "actif": True,
        "droit_annuel": solde.droit_annuel,
        "report_anterieur": solde.report_anterieur,
        "jours_pris": solde.jours_pris,
        "jours_engages": solde.jours_engages(),
        "solde_restant": solde.solde_restant,
        "jours_disponibles": solde.jours_disponibles(),
        "decision_valide": personnel.verifier_decision_annuelle(annee),
    }


@transaction.atomic
def archiver_demandes(annee):
    """Archive les demandes validées de l'année (statut terminal ARCHIVEE)."""
    return DemandeAbsence.objects.filter(
        type_absence__in=[TypeAbsence.CONGE_ANNUEL, TypeAbsence.PERMISSION,
                          TypeAbsence.AUTORISATION, TypeAbsence.MISSION,
                          TypeAbsence.MATERNITE, TypeAbsence.PATERNITE,
                          TypeAbsence.REPOS_SANITAIRE],
        statut_demande=StatutDemande.VALIDE_DIR,
        date_debut__year=annee,
    ).update(statut_demande=StatutDemande.ARCHIVEE)


def solde_du_personnel(personnel, annee):
    """Raccourci de lecture : solde brut ou None."""
    return personnel.soldes.filter(annee=annee).first()


__all__ = [
    "archiver_demandes",
    "droits_annuels_du_personnel",
    "reporter_reliquats",
    "solde_ou_creer",
    "solde_du_personnel",
    "valider_et_activer_par_rh",
]
