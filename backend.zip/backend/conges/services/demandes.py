"""Soumission et justification des demandes d'absence (CDC §3.2 Phase 2).

Orchestre les contrôles : éligibilité (RG-02), durée maximale, justificatif
(RG-08), chevauchement, décision RH et solde (RG-03/RG-04), plafonds (RG-01).
"""

from django.core.exceptions import ValidationError
from django.db import transaction

from personnels.enums import Sexe

from ..enums import StatutDemande, TypeAbsence
from ..regles import (
    EXTENSIONS_JUSTIFICATIF_AUTORISEES,
    JUSTIFICATIF_OBLIGATOIRE,
    TAILLE_MAX_JUSTIFICATIF_OCTETS,
    TYPES_INTERDITS_AUX_STAGIAIRES,
    TYPES_RESERVES_AUX_FEMMES,
    TYPES_RESERVES_AUX_HOMMES,
    duree_maximale,
)
from . import quotas

RESERVES_AUX_FONCTIONNAIRES = (TypeAbsence.MATERNITE, TypeAbsence.PATERNITE)


def _verifier_coherence_des_dates(demande):
    if not (demande.date_debut and demande.date_fin):
        raise ValidationError("Les dates de début et de fin sont obligatoires.")
    if demande.date_fin < demande.date_debut:
        raise ValidationError({"date_fin": "La date de fin précède la date de début."})


def _verifier_eligibilite(demande):
    """RG-02 et restrictions de public (CDC §3.1)."""
    personnel = demande.personnel

    if personnel.est_stagiaire and demande.type_absence in TYPES_INTERDITS_AUX_STAGIAIRES:
        if demande.type_absence == TypeAbsence.CONGE_ANNUEL:
            message = "Les stagiaires n'ont pas droit au congé annuel (RG-02)."
        else:
            message = "Ce congé est réservé aux fonctionnaires et aux ECD."
        raise ValidationError({"type_absence": message})

    if demande.type_absence in TYPES_RESERVES_AUX_FEMMES and personnel.sexe != Sexe.FEMININ:
        raise ValidationError({"type_absence": "Le congé de maternité est réservé aux mères."})

    if demande.type_absence in TYPES_RESERVES_AUX_HOMMES and personnel.sexe != Sexe.MASCULIN:
        raise ValidationError({"type_absence": "Le congé de paternité est réservé aux pères."})


def _verifier_duree_maximale(demande, nombre_jours):
    maximum = duree_maximale(demande.type_absence)
    if maximum is not None and nombre_jours > maximum:
        raise ValidationError(
            {
                "date_fin": (
                    f"Durée maximale dépassée : {maximum} jours pour "
                    f"{demande.get_type_absence_display()}."
                )
            }
        )


def _verifier_justificatif(demande):
    """RG-08 : pièce obligatoire pour mission, repos sanitaire et congés familiaux."""
    if demande.type_absence in JUSTIFICATIF_OBLIGATOIRE and not demande.fichier_justificatif:
        raise ValidationError(
            {
                "fichier_justificatif": (
                    "Un justificatif est obligatoire pour ce type d'absence (RG-08)."
                )
            }
        )


def valider_fichier_justificatif(fichier):
    """Contrôle l'extension et la taille du fichier téléversé (CDC §5.1, sécurité)."""
    if fichier is None:
        raise ValidationError({"fichier_justificatif": "Aucun fichier fourni."})

    nom = (getattr(fichier, "name", "") or "").lower()
    if not nom.endswith(EXTENSIONS_JUSTIFICATIF_AUTORISEES):
        formats = ", ".join(EXTENSIONS_JUSTIFICATIF_AUTORISEES)
        raise ValidationError(
            {"fichier_justificatif": f"Format non autorisé. Formats acceptés : {formats}."}
        )

    taille = getattr(fichier, "size", 0) or 0
    if taille > TAILLE_MAX_JUSTIFICATIF_OCTETS:
        limite_mo = TAILLE_MAX_JUSTIFICATIF_OCTETS // (1024 * 1024)
        raise ValidationError(
            {"fichier_justificatif": f"Le fichier dépasse la taille maximale de {limite_mo} Mo."}
        )


def verifier_regles(demande):
    """Applique toutes les règles de soumission. Lève ValidationError, retourne le nombre de jours."""
    _verifier_coherence_des_dates(demande)

    nombre_jours = demande.calculer_nombre_jours()
    _verifier_eligibilite(demande)
    _verifier_duree_maximale(demande, nombre_jours)

    # Congé annuel : première tranche de 15 jours,
    # puis tranches suivantes de 15 jours maximum.
    quotas.verifier_tranches_conge_annuel(demande, nombre_jours)

    _verifier_justificatif(demande)

    # Une personne ne peut pas être absente deux fois sur les mêmes journées.
    quotas.verifier_absence_de_chevauchement(demande)
    # RG-03 / RG-04 : quota de congé annuel.
    if demande.type_absence == TypeAbsence.CONGE_ANNUEL:
        quotas.verifier_solde_conge_annuel(demande, nombre_jours)

    # RG-01 : plafonds mensuels et annuels des permissions et autorisations.
    quotas.verifier_plafonds(demande)

    return nombre_jours


@transaction.atomic
def soumettre_demande(demande):
    """Vérifie les règles puis enregistre la demande en attente de visa."""
    verifier_regles(demande)
    demande.statut_demande = StatutDemande.EN_ATTENTE
    demande.save()
    return demande


def joindre_justificatif(demande, fichier):
    """Attache une pièce justificative en contrôlant format et taille (RG-08)."""
    valider_fichier_justificatif(fichier)
    demande.fichier_justificatif = fichier
    demande.save(update_fields=["fichier_justificatif"])
    return demande
