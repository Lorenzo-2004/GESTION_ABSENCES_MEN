"""Contrôles de quotas : plafonds RG-01, solde RG-03/RG-04, chevauchements.

Toutes les requêtes sont bornées à la (aux) année(s) couverte(s) par la demande :
on ne parcourt plus l'historique complet de l'agent à chaque soumission.
"""

from collections import Counter
from datetime import date
from ..enums import TypeAbsence

from django.core.exceptions import ValidationError
from django.db.models import Q
from ..models import DemandeAbsence
from ..regles import (
    STATUTS_ACTIFS,
    STATUTS_OCCUPANTS,
    annee_de_reference,
    iter_jours,
    plafond_annuel,
    plafond_mensuel,
)


def annees_couvertes(demande) -> list[int]:
    """Années civiles touchées par la période de la demande."""
    return sorted({jour.year for jour in iter_jours(demande.date_debut, demande.date_fin)})


def _compteurs(jours) -> tuple[Counter, Counter]:
    """Compte les jours par (année, mois) et par année."""
    par_mois, par_annee = Counter(), Counter()
    for jour in jours:
        par_mois[(jour.year, jour.month)] += 1
        par_annee[jour.year] += 1
    return par_mois, par_annee


def demandes_concurrentes(demande, statuts=STATUTS_ACTIFS, meme_type=True):
    """Demandes de l'agent couvrant au moins une des années de la demande courante."""
    annees = annees_couvertes(demande)
    if not annees:
        return DemandeAbsence.objects.none()

    criteres = {
        "personnel": demande.personnel,
        "statut_demande__in": tuple(statuts),
        "date_debut__lte": date(max(annees), 12, 31),
        "date_fin__gte": date(min(annees), 1, 1),
    }
    if meme_type:
        criteres["type_absence"] = demande.type_absence

    requete = DemandeAbsence.objects.filter(**criteres)
    if demande.pk:
        requete = requete.exclude(pk=demande.pk)
    return requete


def jours_deja_consommes(demande) -> tuple[Counter, Counter]:
    """Compteurs des jours déjà posés pour ce type sur les années concernées."""
    jours_existants = (
        jour
        for existante in demandes_concurrentes(demande)
        for jour in iter_jours(existante.date_debut, existante.date_fin)
    )
    return _compteurs(jours_existants)


def verifier_plafonds(demande):
    """Applique les plafonds mensuels et annuels (RG-01). Lève ValidationError."""
    max_mensuel = plafond_mensuel(demande.type_absence)
    if max_mensuel is None:
        return  # ce type d'absence n'est pas plafonné

    max_annuel = plafond_annuel(demande.type_absence)
    mois_nouveaux, annees_nouvelles = _compteurs(
        iter_jours(demande.date_debut, demande.date_fin)
    )
    mois_existants, annees_existantes = jours_deja_consommes(demande)

    for (annee, mois), nombre in mois_nouveaux.items():
        if mois_existants[(annee, mois)] + nombre > max_mensuel:
            raise ValidationError(
                f"Plafond mensuel dépassé : {max_mensuel} jour(s) maximum par mois "
                f"pour {demande.get_type_absence_display()} (RG-01)."
            )

    for annee, nombre in annees_nouvelles.items():
        if annees_existantes[annee] + nombre > max_annuel:
            raise ValidationError(
                f"Plafond annuel dépassé : {max_annuel} jour(s) maximum par an "
                f"pour {demande.get_type_absence_display()} (RG-01)."
            )


def verifier_absence_de_chevauchement(demande):
    """Un agent ne peut pas être absent deux fois sur les mêmes journées."""
    jours_demandes = set(iter_jours(demande.date_debut, demande.date_fin))
    for existante in demandes_concurrentes(demande, statuts=STATUTS_OCCUPANTS, meme_type=False):
        jours_existants = set(iter_jours(existante.date_debut, existante.date_fin))
        conflit = jours_demandes & jours_existants
        if conflit:
            raise ValidationError(
                {
                    "date_debut": (
                        f"Chevauchement avec la demande "
                        f"{existante.numero_enregistrement or existante.pk} "
                        f"du {existante.date_debut:%d/%m/%Y} au {existante.date_fin:%d/%m/%Y} "
                        f"(premier jour en conflit : {min(conflit):%d/%m/%Y})."
                    )
                }
            )

def verifier_tranches_conge_annuel(demande, nombre_jours):
    """
    Vérifie les tranches de congé annuel.

    Première tranche : exactement 15 jours calendaires.
    Tranches suivantes : 15 jours maximum.
    Seules les demandes encore actives ou déjà validées comptent.
    """

    if demande.type_absence != TypeAbsence.CONGE_ANNUEL:
        return

    annee = demande.annee

    tranches_existantes = DemandeAbsence.objects.filter(
    Q(annee_titre=annee)
    | Q(
        annee_titre__isnull=True,
        date_debut__year=annee,
    ),
    personnel=demande.personnel,
    type_absence=TypeAbsence.CONGE_ANNUEL,
    statut_demande__in=STATUTS_ACTIFS,
)

    # La demande en cours de soumission ne doit pas être comptée deux fois.
    if demande.pk:
        tranches_existantes = tranches_existantes.exclude(
            pk=demande.pk
        )

    premiere_tranche = not tranches_existantes.exists()

    if premiere_tranche and nombre_jours != 15:
        raise ValidationError({
            "date_fin": (
                "La première tranche de congé annuel doit être "
                "exactement de 15 jours calendaires."
            )
        })

    if not premiere_tranche and nombre_jours > 15:
        raise ValidationError({
            "date_fin": (
                "Une tranche suivante de congé annuel ne peut pas "
                "dépasser 15 jours calendaires."
            )
        })


def verifier_solde_conge_annuel(demande, nombre_jours):
    """Vérifie la décision RH (RG-04) puis la disponibilité du quota (RG-03)."""
    personnel = demande.personnel
    annee = demande.annee

    if not personnel.verifier_decision_annuelle(annee):  # RG-04
        raise ValidationError(
            {
                "type_absence": (
                    f"Aucune décision de congé valide enregistrée par la RH pour {annee} (RG-04)."
                )
            }
        )

    solde = personnel.get_solde_actif(annee)
    if solde is None:
        raise ValidationError(
            f"Aucun solde de congé activé pour {annee}. La RH doit enregistrer la décision annuelle."
        )

    disponibles = solde.jours_disponibles()
    if nombre_jours > disponibles:
        raise ValidationError(
            f"Solde insuffisant : {disponibles} jour(s) disponible(s) sur {annee} "
            f"({solde.solde_restant} au solde, dont {solde.jours_engages()} déjà engagé(s) "
            f"par des demandes en cours), pour {nombre_jours} jour(s) demandé(s)."
        )
    return solde
