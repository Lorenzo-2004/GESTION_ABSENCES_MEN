#!/usr/bin/env python
import os
import sys


def main():
    # Environnement de développement par défaut ; surchargeable via DJANGO_SETTINGS_MODULE
    # (ex. : config.settings.test pour la suite de tests, config.settings.prod en intranet).
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.dev")
    from django.core.management import execute_from_command_line

    execute_from_command_line(sys.argv)


if __name__ == "__main__":
    main()
