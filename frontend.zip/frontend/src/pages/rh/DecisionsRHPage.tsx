import { useEffect, useState } from 'react'
import type {
  CSSProperties,
  DragEvent,
  FormEvent,
  KeyboardEvent,
  ReactNode,
} from 'react'
import { Link, Navigate } from 'react-router'
import { useAuth } from '../../contexts/useAuth'
import {
  activerDecision,
  creerDecision,
  listerDecisions,
  listerPersonnelsRH,
  reporterReliquats,
  scannerDecision,
} from '../../services/rhDecisionsService'
import type {
  CreationDecision,
  DecisionConge,
  NatureDecision,
  PersonnelDecision,
  ResultatScanDecision,
} from '../../services/rhDecisionsService'
import { Icon, Message, type IconName } from '../../components/men/ui.tsx'
import { delai, useCompteur } from '../../components/men/ui-outils.ts'
import {
  decisionsParAnnee,
  decisionsParMois,
} from '../../components/men/graphiques.tsx'
import {
  CoquilleRH,
  Tiroir,
  type VueRH,
} from '../../components/men/miseEnPageRH.tsx'

type FiltreDecision = 'toutes' | 'valides' | 'non_validees'
type ModeSaisie = 'scan' | 'manuel'

interface FormulaireDecision {
  numero_decision: string
  personnel: string
  direction: string
  budget: string
  imputation_budgetaire: string
  corps_grade: string
  indice: string
  annees_titre: string
  details_jours: string
  date_demande_reference: string
  date_emission: string
  signataire: string
  nature: NatureDecision
}

/* ------------------------------------------------------------------ */
/*  Animations                                                         */
/* ------------------------------------------------------------------ */

const STYLES = `
@keyframes rh-in{from{opacity:0;transform:translate3d(0,14px,0)}to{opacity:1;transform:none}}
@keyframes rh-draw{from{stroke-dashoffset:1}to{stroke-dashoffset:0}}
@keyframes rh-bar{from{transform:scaleX(0)}to{transform:scaleX(1)}}
@keyframes rh-ring{from{stroke-dashoffset:var(--c)}to{stroke-dashoffset:var(--o)}}
@keyframes rh-pulse{0%{box-shadow:0 0 0 0 rgba(217,138,11,.45)}100%{box-shadow:0 0 0 7px rgba(217,138,11,0)}}
@keyframes rh-pop{0%{opacity:0;transform:scale(.92)}100%{opacity:1;transform:none}}
@keyframes rh-fade{from{opacity:0}to{opacity:1}}
@keyframes rh-orbit{to{transform:rotate(360deg)}}
@keyframes rh-sheen{from{transform:translateX(-120%)}to{transform:translateX(280%)}}

.rh-in{animation:rh-in .6s cubic-bezier(.22,1,.36,1) var(--d,0ms) backwards}
.rh-draw{stroke-dasharray:1;animation:rh-draw 1.5s cubic-bezier(.4,0,.2,1) var(--d,150ms) backwards}
.rh-bar{transform-origin:left center;animation:rh-bar .9s cubic-bezier(.22,1,.36,1) var(--d,0ms) backwards}
.rh-ring{animation:rh-ring 1.3s cubic-bezier(.22,1,.36,1) var(--d,300ms) backwards}
.rh-pulse{animation:rh-pulse 1.8s ease-out infinite}
.rh-pop{animation:rh-pop .45s cubic-bezier(.22,1,.36,1) backwards}
.rh-fade{animation:rh-fade .7s ease-out var(--d,0ms) backwards}
.rh-orbit{transform-origin:center;animation:rh-orbit 80s linear infinite}
.rh-sheen::after{content:"";position:absolute;inset:0;width:36%;pointer-events:none;
  background:linear-gradient(100deg,transparent,rgba(255,255,255,.18),transparent);
  animation:rh-sheen 1.5s cubic-bezier(.4,0,.2,1) var(--d,600ms) 1 backwards}

.men-serif{font-family:var(--font-serif,Georgia,'Times New Roman',serif);font-weight:500;letter-spacing:-.01em}

@media (prefers-reduced-motion:reduce){
  .rh-in,.rh-draw,.rh-bar,.rh-ring,.rh-pulse,.rh-pop,.rh-fade,.rh-orbit,.rh-sheen::after{animation:none!important}
  .rh-draw{stroke-dasharray:none}
}
`

/* ------------------------------------------------------------------ */
/*  Styles partagés                                                    */
/* ------------------------------------------------------------------ */

const carte =
  'rounded-[20px] border border-[#E3E8EE] bg-white shadow-[0_1px_2px_rgba(15,36,55,0.04),0_10px_28px_-18px_rgba(15,36,55,0.14)]'

const btnPrimaire =
  'inline-flex h-10 items-center justify-center gap-2 rounded-xl bg-[#00678F] px-4 text-sm font-semibold text-white shadow-[0_1px_2px_rgba(0,103,143,.3),0_8px_16px_-8px_rgba(0,103,143,.55)] transition duration-200 hover:bg-[#005A7D] active:scale-[.98] focus:outline-none focus-visible:ring-4 focus-visible:ring-[#00678F]/25 disabled:pointer-events-none disabled:opacity-60'

const btnContour =
  'inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-[#D5DCE5] bg-white px-4 text-sm font-semibold text-[#0F2437] transition duration-200 hover:border-[#C0CBD7] hover:bg-[#F3F6F9] active:scale-[.98] focus:outline-none focus-visible:ring-4 focus-visible:ring-[#00678F]/15 disabled:pointer-events-none disabled:opacity-60'

const btnIcone =
  'grid h-9 w-9 place-items-center rounded-lg text-[#5B6B7C] transition-colors hover:bg-[#00678F]/10 hover:text-[#00678F] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00678F]/40 disabled:opacity-50'

const btnActiver =
  'inline-flex h-9 items-center gap-1.5 rounded-lg bg-[#00678F]/10 px-3 text-xs font-semibold text-[#00678F] transition duration-200 hover:bg-[#00678F] hover:text-white active:scale-[.97] focus:outline-none focus-visible:ring-4 focus-visible:ring-[#00678F]/20 disabled:pointer-events-none disabled:opacity-50'

const etiquette = 'mb-1.5 block text-sm font-medium text-[#0F2437]'

const champ =
  'h-11 w-full rounded-xl border border-[#D5DCE5] bg-white px-3.5 text-sm text-[#0F2437] outline-none transition duration-200 placeholder:text-[#94A3B8] hover:border-[#B8C4D1] focus:border-[#00678F] focus:ring-4 focus:ring-[#00678F]/15 disabled:bg-[#F3F5F8] disabled:text-[#94A3B8]'

const zoneTexte =
  'min-h-[100px] w-full resize-y rounded-xl border border-[#D5DCE5] bg-white px-3.5 py-2.5 text-sm text-[#0F2437] outline-none transition duration-200 placeholder:text-[#94A3B8] hover:border-[#B8C4D1] focus:border-[#00678F] focus:ring-4 focus:ring-[#00678F]/15'

const TONS_KPI = {
  bleu: {
    fond: 'from-[#0A5378] via-[#00678F] to-[#0A82B9]',
    ombre: 'shadow-[0_22px_38px_-22px_rgba(0,103,143,.8)]',
  },
  bleuMoyen: {
    fond: 'from-[#0A6C99] via-[#0A82B9] to-[#38BDF8]',
    ombre: 'shadow-[0_22px_38px_-22px_rgba(10,130,185,.8)]',
  },
  vert: {
    fond: 'from-[#2F6A1A] via-[#3F7D20] to-[#5B9A33]',
    ombre: 'shadow-[0_22px_38px_-22px_rgba(63,125,32,.8)]',
  },
  ambre: {
    fond: 'from-[#9A4A0A] via-[#B45309] to-[#D97706]',
    ombre: 'shadow-[0_22px_38px_-22px_rgba(180,83,9,.8)]',
  },
} as const

const AVATARS = [
  'bg-[#00678F]/10 text-[#00678F]',
  'bg-[#518929]/10 text-[#3F6F1F]',
  'bg-slate-500/10 text-slate-700',
  'bg-[#0A3D5C]/10 text-[#0A3D5C]',
  'bg-amber-500/10 text-amber-800',
]

const TITRES_VUES: Record<VueRH, { titre: string; description: string }> = {
  apercu: { titre: 'Vue d’ensemble', description: 'Suivi des décisions et des droits à congé' },
  decisions: { titre: 'Décisions', description: 'Consulter, rechercher et activer les soldes' },
  reports: { titre: 'Report des reliquats', description: 'Reporter les soldes d’une année vers la suivante' },
}

/* ------------------------------------------------------------------ */
/*  Utilitaires                                                        */
/* ------------------------------------------------------------------ */

function dateDuJour(): string {
  const maintenant = new Date()
  const annee = maintenant.getFullYear()
  const mois = String(maintenant.getMonth() + 1).padStart(2, '0')
  const jour = String(maintenant.getDate()).padStart(2, '0')
  return `${annee}-${mois}-${jour}`
}

function formulaireInitial(): FormulaireDecision {
  return {
    numero_decision: '',
    personnel: '',
    direction: '',
    budget: 'Budget Général',
    imputation_budgetaire: '',
    corps_grade: '',
    indice: '',
    annees_titre: String(new Date().getFullYear()),
    details_jours: '',
    date_demande_reference: '',
    date_emission: dateDuJour(),
    signataire: '',
    nature: 'SAISIE_MANUELLE',
  }
}

function messageErreur(erreur: unknown): string {
  const detail = erreur as {
    response?: { data?: unknown }
    message?: string
  }
  const donnees = detail?.response?.data
  if (typeof donnees === 'string') return donnees
  if (donnees && typeof donnees === 'object') {
    return Object.entries(donnees as Record<string, unknown>)
      .map(([champ, valeur]) => {
        const contenu = Array.isArray(valeur)
          ? valeur.join(', ')
          : typeof valeur === 'object'
            ? JSON.stringify(valeur)
            : String(valeur)
        return `${champ} : ${contenu}`
      })
      .join(' | ')
  }
  return detail?.message || 'Une erreur inattendue est survenue.'
}

function nomPersonnel(personnel?: PersonnelDecision): string {
  if (!personnel) return 'Agent non renseigné'
  return (
    personnel.nom_complet ||
    [personnel.nom, personnel.prenoms].filter(Boolean).join(' ') ||
    `IM ${personnel.im}`
  )
}

function initiales(nom: string): string {
  const lettres = nom
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((mot) => mot[0]?.toUpperCase())
    .join('')
  return lettres || '?'
}

function teinteAvatar(nom: string): string {
  const somme = [...nom].reduce((total, c) => total + c.charCodeAt(0), 0)
  return AVATARS[somme % AVATARS.length]
}

/* ------------------------------------------------------------------ */
/*  Composants locaux                                                  */
/* ------------------------------------------------------------------ */

function Avatar({ nom, className = 'h-9 w-9 text-xs' }: { nom: string; className?: string }) {
  return (
    <span
      aria-hidden="true"
      className={`grid shrink-0 place-items-center rounded-full font-bold ring-1 ring-inset ring-black/5 ${teinteAvatar(nom)} ${className}`}
    >
      {initiales(nom)}
    </span>
  )
}

function Bascule<T extends string>({
  nom,
  valeur,
  onChange,
  options,
}: {
  nom: string
  valeur: T
  onChange: (valeur: T) => void
  options: { valeur: T; libelle: string }[]
}) {
  const index = Math.max(0, options.findIndex((option) => option.valeur === valeur))
  return (
    <div
      role="group"
      aria-label={nom}
      className="relative inline-grid shrink-0 rounded-xl bg-[#E9EEF3] p-1"
      style={{ gridTemplateColumns: `repeat(${options.length}, minmax(0, 1fr))` }}
    >
      <span
        aria-hidden="true"
        className="absolute inset-y-1 left-1 rounded-lg bg-white shadow-[0_1px_2px_rgba(15,36,55,.1),0_2px_6px_-2px_rgba(15,36,55,.12)] transition-transform duration-300 ease-[cubic-bezier(.22,1,.36,1)]"
        style={{
          width: `calc((100% - 8px) / ${options.length})`,
          transform: `translateX(${index * 100}%)`,
        }}
      />
      {options.map((option) => (
        <button
          key={option.valeur}
          type="button"
          aria-pressed={option.valeur === valeur}
          onClick={() => onChange(option.valeur)}
          className={`relative z-10 whitespace-nowrap rounded-lg px-4 py-1.5 text-sm font-semibold transition-colors duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00678F]/50 ${
            option.valeur === valeur ? 'text-[#00678F]' : 'text-[#5B6B7C] hover:text-[#0F2437]'
          }`}
        >
          {option.libelle}
        </button>
      ))}
    </div>
  )
}

function GroupeFormulaire({
  icone,
  titre,
  tonChip,
  retard,
  children,
}: {
  icone: IconName
  titre: string
  tonChip: string
  retard: number
  children: ReactNode
}) {
  return (
    <fieldset
      className="rh-in min-w-0 rounded-2xl border border-[#E3E8EE] bg-white p-4 sm:p-5"
      style={delai(retard)}
    >
      <legend className="sr-only">{titre}</legend>
      <div className="mb-4 flex items-center gap-3">
        <span className={`grid h-9 w-9 place-items-center rounded-xl ${tonChip}`}>
          <Icon name={icone} className="h-[18px] w-[18px]" />
        </span>
        <h3 className="text-sm font-semibold text-[#0F2437]">{titre}</h3>
      </div>
      {children}
    </fieldset>
  )
}

function TuileKpi({
  libelle,
  valeur,
  note,
  part,
  icone,
  ton,
  retard,
}: {
  libelle: string
  valeur: number
  note: string
  part: number
  icone: IconName
  ton: keyof typeof TONS_KPI
  retard: number
}) {
  const affiche = useCompteur(valeur)
  const s = TONS_KPI[ton]
  const pct = Math.min(100, Math.max(0, part))

  return (
    <div
      className={`rh-in rh-sheen relative overflow-hidden rounded-[20px] bg-gradient-to-br p-4 text-white sm:p-5 ${s.fond} ${s.ombre}`}
      style={{ ...delai(retard), '--d': `${retard}ms` } as CSSProperties}
    >
      <svg
        aria-hidden="true"
        viewBox="0 0 200 200"
        className="pointer-events-none absolute -right-10 -top-12 h-40 w-40 text-white"
      >
        <g className="rh-orbit" fill="none" stroke="currentColor">
          <circle cx="100" cy="100" r="90" strokeOpacity=".12" />
          <circle cx="100" cy="100" r="64" strokeOpacity=".16" strokeDasharray="2 8" />
          <path d="M100 10 A90 90 0 0 1 190 100" strokeOpacity=".4" strokeWidth="2" strokeLinecap="round" />
        </g>
      </svg>
      <div className="relative flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-semibold text-white/85">{libelle}</p>
          <p className="men-serif mt-1.5 text-4xl leading-none tabular-nums">{affiche}</p>
        </div>
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-white/15 ring-1 ring-inset ring-white/25 backdrop-blur-sm">
          <Icon name={icone} className="h-4 w-4" />
        </span>
      </div>
      <div className="relative mt-4">
        <div className="mb-1 flex items-baseline justify-between text-[11px] text-white/85">
          <span>{note}</span>
          <span className="font-bold tabular-nums text-white">{Math.round(pct)}%</span>
        </div>
        <div className="h-1 overflow-hidden rounded-full bg-white/20">
          <div className="rh-bar h-full rounded-full bg-white" style={{ width: `${pct}%`, ...delai(retard + 350) }} />
        </div>
      </div>
    </div>
  )
}

function Panneau({
  titre,
  sousTitre,
  icone,
  accent,
  action,
  retard,
  className = '',
  children,
}: {
  titre: string
  sousTitre?: string
  icone: IconName
  accent: string
  action?: ReactNode
  retard: number
  className?: string
  children: ReactNode
}) {
  return (
    <section className={`rh-in relative flex min-w-0 flex-col overflow-hidden p-5 sm:p-6 ${carte} ${className}`} style={delai(retard)}>
      {/* Ligne d'accent supprimée */}
      <header className="mb-5 flex items-center justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl" style={{ backgroundColor: `${accent}1A`, color: accent }}>
            <Icon name={icone} className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <h2 className="text-base font-bold text-[#0F2437]">{titre}</h2>
            {sousTitre && <p className="text-xs text-[#5B6B7C]">{sousTitre}</p>}
          </div>
        </div>
        {action}
      </header>
      <div className="flex flex-1 flex-col justify-center">{children}</div>
    </section>
  )
}

function Anneau({
  ratio,
  centre,
  taille = 120,
  epaisseur = 12,
  couleur = '#518929',
}: {
  ratio: number
  centre: ReactNode
  taille?: number
  epaisseur?: number
  couleur?: string
}) {
  const r = (taille - epaisseur) / 2
  const c = 2 * Math.PI * r
  const o = c * (1 - Math.min(Math.max(ratio, 0), 1))
  return (
    <div className="relative shrink-0" style={{ width: taille, height: taille }}>
      <svg width={taille} height={taille} viewBox={`0 0 ${taille} ${taille}`} className="-rotate-90" role="img" aria-label={`Taux : ${Math.round(ratio * 100)} %`}>
        <circle cx={taille / 2} cy={taille / 2} r={r} fill="none" stroke="#EAEFF4" strokeWidth={epaisseur} />
        <circle className="rh-ring" cx={taille / 2} cy={taille / 2} r={r} fill="none" stroke={couleur} strokeWidth={epaisseur} strokeLinecap="round" strokeDasharray={c} strokeDashoffset={o} style={{ '--c': c, '--o': o } as CSSProperties} />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">{centre}</div>
    </div>
  )
}

function Courbe({ points }: { points: { libelle: string; valeur: number }[] }) {
  const [actif, setActif] = useState<number | null>(null)
  const L = 640
  const H = 230
  const m = { t: 22, r: 16, b: 30, l: 30 }
  const zL = L - m.l - m.r
  const zH = H - m.t - m.b
  const max = Math.max(3, ...points.map((p) => p.valeur))
  const plafond = Math.ceil(max / 3) * 3
  const graduations = [0, 1, 2, 3].map((i) => (plafond / 3) * i)

  const x = (i: number) => m.l + (points.length > 1 ? (i / (points.length - 1)) * zL : zL / 2)
  const y = (valeur: number) => m.t + zH - (valeur / plafond) * zH

  const chemin = points.reduce((c, point, i) => {
    if (i === 0) return `M ${x(0)} ${y(point.valeur)}`
    const px = x(i - 1)
    const py = y(points[i - 1].valeur)
    const milieu = (px + x(i)) / 2
    return `${c} C ${milieu} ${py} ${milieu} ${y(point.valeur)} ${x(i)} ${y(point.valeur)}`
  }, '')

  const base = m.t + zH
  const aire = points.length ? `${chemin} L ${x(points.length - 1)} ${base} L ${x(0)} ${base} Z` : ''
  const borne = (valeur: number, min: number, maxi: number) => Math.min(Math.max(valeur, min), maxi)

  return (
    <svg viewBox={`0 0 ${L} ${H}`} className="h-auto w-full" role="img" aria-label="Évolution" onMouseLeave={() => setActif(null)}>
      <defs>
        <linearGradient id="rh-aire" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#00678F" stopOpacity="0.18" />
          <stop offset="100%" stopColor="#00678F" stopOpacity="0" />
        </linearGradient>
      </defs>
      {graduations.map((valeur) => (
        <g key={valeur}>
          <line x1={m.l} x2={L - m.r} y1={y(valeur)} y2={y(valeur)} stroke="#E7ECF2" strokeDasharray="3 5" />
          <text x={m.l - 8} y={y(valeur) + 4} textAnchor="end" fill="#5B6B7C" fontSize="11">{valeur}</text>
        </g>
      ))}
      {actif !== null && <line x1={x(actif)} x2={x(actif)} y1={m.t} y2={base} stroke="#94A3B8" strokeOpacity="0.55" strokeDasharray="3 4" pointerEvents="none" />}
      {aire && <path className="rh-fade" d={aire} fill="url(#rh-aire)" style={delai(700)} />}
      {chemin && <path className="rh-draw" pathLength={1} d={chemin} fill="none" stroke="#00678F" strokeWidth="2.75" strokeLinecap="round" />}
      {points.map((point, i) => (
        <g key={`${point.libelle}-${i}`}>
          <text x={x(i)} y={H - 8} textAnchor="middle" fill={actif === i ? '#0F2437' : '#5B6B7C'} fontSize="11" fontWeight={actif === i ? 600 : 400} style={{ textTransform: 'capitalize' }}>{point.libelle}</text>
          <rect x={x(i) - zL / points.length / 2} y={m.t} width={zL / points.length} height={zH} fill="transparent" onMouseEnter={() => setActif(i)} />
          <circle className="rh-pop" cx={x(i)} cy={y(point.valeur)} r={actif === i ? 6 : 4} fill="#fff" stroke="#00678F" strokeWidth="2.5" style={{ animationDelay: `${900 + i * 90}ms`, transition: 'r .15s ease' }} />
        </g>
      ))}
      {actif !== null && (
        <g pointerEvents="none">
          <rect x={borne(x(actif) - 34, 0, L - 68)} y={Math.max(y(points[actif].valeur) - 40, 0)} width="68" height="26" rx="8" fill="#0A3D5C" />
          <text x={borne(x(actif), 34, L - 34)} y={Math.max(y(points[actif].valeur) - 22, 18)} textAnchor="middle" fill="#fff" fontSize="12" fontWeight="600">{points[actif].valeur}</text>
        </g>
      )}
    </svg>
  )
}

function BarresAnnee({ elements }: { elements: { libelle: string; valeur: number }[] }) {
  const max = Math.max(1, ...elements.map((e) => e.valeur))
  return (
    <ul className="space-y-4">
      {elements.map((e, i) => (
        <li key={e.libelle}>
          <div className="mb-1.5 flex items-baseline justify-between text-sm">
            <span className="font-semibold tabular-nums text-[#0F2437]">{e.libelle}</span>
            <span className="tabular-nums text-[#5B6B7C]">{e.valeur}</span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-[#EAEFF4]">
            <div className="rh-bar h-full rounded-full bg-[#0A82B9]" style={{ width: `${(e.valeur / max) * 100}%`, ...delai(300 + i * 110) }} />
          </div>
        </li>
      ))}
    </ul>
  )
}

function Statut({ valide }: { valide: boolean }) {
  return (
    <span className={`inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-semibold ${valide ? 'bg-[#518929]/10 text-[#3F6F1F]' : 'bg-amber-500/10 text-amber-700'}`}>
      <span className={`h-2 w-2 rounded-full ${valide ? 'bg-[#518929]' : 'rh-pulse bg-amber-500'}`} />
      {valide ? 'Valide' : 'À vérifier'}
    </span>
  )
}

/* ================================================================== */
/*  Page                                                               */
/* ================================================================== */

export function DecisionsRHPage() {
  const { utilisateur, chargement } = useAuth()

  const [vue, setVue] = useState<VueRH>('apercu')
  const [tiroirOuvert, setTiroirOuvert] = useState(false)
  const [modeSaisie, setModeSaisie] = useState<ModeSaisie>('manuel')

  const [decisions, setDecisions] = useState<DecisionConge[]>([])
  const [toutesDecisions, setToutesDecisions] = useState<DecisionConge[]>([])
  const [personnels, setPersonnels] = useState<PersonnelDecision[]>([])
  const [formulaire, setFormulaire] = useState<FormulaireDecision>(formulaireInitial)

  const [rechercheDecision, setRechercheDecision] = useState('')
  const [filtre, setFiltre] = useState<FiltreDecision>('toutes')
  const [recherchePersonnel, setRecherchePersonnel] = useState('')
  const [fichierScan, setFichierScan] = useState<File | null>(null)
  const [resultatScan, setResultatScan] = useState<ResultatScanDecision | null>(null)
  const [glisse, setGlisse] = useState(false)

  const [chargementListe, setChargementListe] = useState(true)
  const [chargementStats, setChargementStats] = useState(true)
  const [chargementScan, setChargementScan] = useState(false)
  const [enregistrement, setEnregistrement] = useState(false)
  const [actionEnCours, setActionEnCours] = useState<number | null>(null)
  const [reportEnCours, setReportEnCours] = useState(false)

  const [anneeSource, setAnneeSource] = useState(String(new Date().getFullYear() - 1))
  const [erreur, setErreur] = useState('')
  const [succes, setSucces] = useState('')

  const total = toutesDecisions.length
  const nombreValides = toutesDecisions.filter((d) => d.est_valide).length
  const nombreAVerifier = total - nombreValides
  const nombreOCR = toutesDecisions.filter((d) => d.nature === 'OCR').length
  const nombreManuel = total - nombreOCR
  const ratioValides = total ? nombreValides / total : 0
  const aTraiter = toutesDecisions.filter((d) => !d.est_valide)

  const pourcentageAffiche = useCompteur(Math.round(ratioValides * 100))

  async function chargerDecisions(recherche = rechercheDecision, statut = filtre) {
    setChargementListe(true)
    try {
      const resultat = await listerDecisions(recherche, statut)
      setDecisions(resultat.elements ?? [])
      setErreur('')
    } catch (e) {
      setErreur(`Impossible de charger les décisions. ${messageErreur(e)}`)
    } finally {
      setChargementListe(false)
    }
  }

  async function chargerStatistiques() {
    try {
      const resultat = await listerDecisions('', 'toutes')
      setToutesDecisions(resultat.elements ?? [])
    } catch (e) {
      setErreur(`Impossible de charger les statistiques. ${messageErreur(e)}`)
    } finally {
      setChargementStats(false)
    }
  }

  async function actualiser() {
    await Promise.all([chargerDecisions(), chargerStatistiques()])
  }

  async function chargerPersonnels(recherche = recherchePersonnel) {
    try {
      const resultat = await listerPersonnelsRH(recherche)
      setPersonnels(resultat.elements ?? [])
    } catch (e) {
      setErreur(`Impossible de charger la liste du personnel. ${messageErreur(e)}`)
    }
  }

  useEffect(() => {
    void chargerDecisions('', 'toutes')
    void chargerStatistiques()
    void chargerPersonnels('')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  if (chargement) {
    return (
      <div className="grid min-h-screen place-items-center bg-[#F3F5F8]">
        <span role="status" aria-label="Chargement" className="h-7 w-7 animate-spin rounded-full border-[3px] border-[#00678F]/15 border-t-[#00678F]" />
      </div>
    )
  }

  if (!utilisateur || utilisateur.role !== 'ROLE_RH') return <Navigate to="/app" replace />

  function modifierChamp(champ: keyof FormulaireDecision, valeur: string) {
    setFormulaire((precedent) => ({ ...precedent, [champ]: valeur }))
  }

  function selectionnerPersonnel(id: string) {
    const agent = personnels.find((personnel) => String(personnel.id_personnel) === id)
    setFormulaire((precedent) => ({
      ...precedent,
      personnel: id,
      direction: agent ? String(agent.direction) : precedent.direction,
      corps_grade: agent ? [agent.corps, agent.grade].filter(Boolean).join(' ') : precedent.corps_grade,
    }))
  }

  function viderChampFichier() {
    const input = document.getElementById('fichier-scan-decision') as HTMLInputElement | null
    if (input) input.value = ''
  }

  function reinitialiserFormulaire() {
    setFormulaire(formulaireInitial())
    setFichierScan(null)
    setResultatScan(null)
    setErreur('')
    setSucces('')
    viderChampFichier()
  }

  function changerMode(mode: ModeSaisie) {
    setModeSaisie(mode)
    if (mode === 'manuel' && !resultatScan) modifierChamp('nature', 'SAISIE_MANUELLE')
  }

  function ouvrirTiroir(mode: ModeSaisie) {
    setErreur('')
    setSucces('')
    changerMode(mode)
    setTiroirOuvert(true)
  }

  function fermerTiroir() {
    setTiroirOuvert(false)
  }

  function voirADeverifier() {
    setFiltre('non_validees')
    setVue('decisions')
    void chargerDecisions(rechercheDecision, 'non_validees')
  }

  async function traiterScan(fichier: File | null) {
    setFichierScan(fichier)
    setResultatScan(null)
    setErreur('')
    setSucces('')
    if (!fichier) return

    setChargementScan(true)
    try {
      const resultat = await scannerDecision(fichier)
      setResultatScan(resultat)
      const extrait = resultat.donnees_extraites
      const agent = resultat.agent

      if (agent) {
        setPersonnels((precedent) =>
          precedent.some((p) => p.id_personnel === agent.id_personnel) ? precedent : [agent, ...precedent],
        )
      }

      setFormulaire((precedent) => ({
        ...precedent,
        numero_decision: extrait.numero_decision || precedent.numero_decision,
        personnel: agent ? String(agent.id_personnel) : precedent.personnel,
        direction: agent ? String(agent.direction) : precedent.direction,
        corps_grade: agent ? [agent.corps, agent.grade].filter(Boolean).join(' ') : precedent.corps_grade,
        indice: extrait.indice !== null && extrait.indice !== undefined ? String(extrait.indice) : precedent.indice,
        annees_titre: extrait.annees?.length > 0 ? extrait.annees.join('-') : precedent.annees_titre,
        nature: extrait.source === 'OCR' ? 'OCR' : 'SAISIE_MANUELLE',
      }))

      setSucces(
        extrait.source === 'OCR'
          ? 'Scan analysé. Vérifiez chaque information avant l’enregistrement.'
          : 'Le texte n’a pas pu être extrait. Vous pouvez saisir les informations manuellement.',
      )
    } catch (e) {
      setErreur(`L’analyse du scan a échoué. Vous pouvez poursuivre en saisie manuelle. ${messageErreur(e)}`)
      setFormulaire((precedent) => ({ ...precedent, nature: 'SAISIE_MANUELLE' }))
    } finally {
      setChargementScan(false)
    }
  }

  function deposerFichier(evenement: DragEvent<HTMLLabelElement>) {
    evenement.preventDefault()
    setGlisse(false)
    if (chargementScan || enregistrement) return
    const fichier = evenement.dataTransfer.files?.[0]
    if (fichier) void traiterScan(fichier)
  }

  function retirerFichier() {
    viderChampFichier()
    void traiterScan(null)
  }

  async function soumettreDecision(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setErreur('')
    setSucces('')

    if (!formulaire.personnel || !formulaire.direction) {
      setErreur('Sélectionnez un agent dont la direction est renseignée.')
      return
    }
    if (!formulaire.numero_decision.trim()) {
      setErreur('Le numéro de décision est obligatoire.')
      return
    }
    if (!formulaire.annees_titre.trim()) {
      setErreur('L’année au titre du congé est obligatoire.')
      return
    }
    if (!formulaire.date_emission) {
      setErreur('La date d’émission est obligatoire.')
      return
    }

    const donnees: CreationDecision = {
      numero_decision: formulaire.numero_decision.trim(),
      personnel: Number(formulaire.personnel),
      direction: Number(formulaire.direction),
      budget: formulaire.budget.trim() || 'Budget Général',
      imputation_budgetaire: formulaire.imputation_budgetaire.trim(),
      corps_grade: formulaire.corps_grade.trim(),
      indice: formulaire.indice ? Number(formulaire.indice) : null,
      annees_titre: formulaire.annees_titre.trim(),
      details_jours: formulaire.details_jours.trim(),
      date_demande_reference: formulaire.date_demande_reference || null,
      date_emission: formulaire.date_emission,
      signataire: formulaire.signataire.trim(),
      nature: formulaire.nature,
    }

    setEnregistrement(true)
    try {
      const nouvelleDecision = await creerDecision(donnees, fichierScan)
      setFormulaire(formulaireInitial())
      setFichierScan(null)
      setResultatScan(null)
      viderChampFichier()
      setTiroirOuvert(false)
      setVue('decisions')
      setSucces(`La décision ${nouvelleDecision.numero_decision} a été enregistrée. Vérifiez son état avant d’activer les soldes.`)
      await actualiser()
    } catch (e) {
      setErreur(`L’enregistrement a échoué. ${messageErreur(e)}`)
    } finally {
      setEnregistrement(false)
    }
  }

  async function confirmerActivation(decision: DecisionConge) {
    const confirme = window.confirm(
      `Confirmer la validation de la décision ${decision.numero_decision} et l’initialisation des soldes ?`,
    )
    if (!confirme) return

    setErreur('')
    setSucces('')
    setActionEnCours(decision.id_decision)
    try {
      await activerDecision(decision.id_decision)
      setSucces(`La demande d’activation de la décision ${decision.numero_decision} a été exécutée.`)
      await actualiser()
    } catch (e) {
      setErreur(`L’activation a échoué. ${messageErreur(e)}`)
    } finally {
      setActionEnCours(null)
    }
  }

  async function executerReport(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setErreur('')
    setSucces('')
    const annee = Number(anneeSource)
    if (!Number.isInteger(annee) || annee < 1900 || annee >= new Date().getFullYear()) {
      setErreur('Saisissez une année antérieure à l’année en cours.')
      return
    }
    const confirme = window.confirm(`Confirmer le report des reliquats de ${annee} vers ${annee + 1} ?`)
    if (!confirme) return

    setReportEnCours(true)
    try {
      const resultat = await reporterReliquats(annee)
      setSucces(`${resultat.message} ${resultat.nombre_soldes_reportes} solde(s) reporté(s).`)
    } catch (e) {
      setErreur(`Le report a échoué. ${messageErreur(e)}`)
    } finally {
      setReportEnCours(false)
    }
  }

  function ajusterAnnee(variation: number) {
    const maximum = new Date().getFullYear() - 1
    const courante = Number(anneeSource) || maximum
    setAnneeSource(String(Math.min(maximum, Math.max(1900, courante + variation))))
  }

  function rechercherAgentAuClavier(evenement: KeyboardEvent<HTMLInputElement>) {
    if (evenement.key === 'Enter') {
      evenement.preventDefault()
      void chargerPersonnels()
    }
  }

  const agentSelectionne = personnels.find((personnel) => String(personnel.id_personnel) === formulaire.personnel)
  const part = (n: number) => (total ? (n / total) * 100 : 0)
  const valeurStat = (n: number) => (chargementStats ? 0 : n)
  const courbeMensuelle = decisionsParMois(toutesDecisions, 6)
  const repartitionAnnees = decisionsParAnnee(toutesDecisions)
  const anneeCibleValide = anneeSource !== '' && Number.isInteger(Number(anneeSource))
  const anneeCible = anneeCibleValide ? Number(anneeSource) + 1 : null

  const messages = (
    <>
      {erreur && <Message key={erreur} type="erreur" onClose={() => setErreur('')}>{erreur}</Message>}
      {succes && <Message key={succes} type="succes" onClose={() => setSucces('')}>{succes}</Message>}
    </>
  )

  return (
    <CoquilleRH
      vue={vue}
      onVue={setVue}
      badges={{ decisions: nombreAVerifier }}
      titre={TITRES_VUES[vue].titre}
      description={TITRES_VUES[vue].description}
      actions={
        <>
          {utilisateur.personnel?.service != null && (
            <Link to="/app/chef-service" className={`${btnContour} !h-9`}>
              <Icon name="building" className="h-4 w-4" />
              <span className="hidden sm:inline">
                Espace du service
                {utilisateur.personnel.service_libelle ? ` · ${utilisateur.personnel.service_libelle}` : ''}
              </span>
            </Link>
          )}
          <button type="button" onClick={() => void actualiser()} disabled={chargementListe || chargementStats} aria-label="Actualiser" title="Actualiser" className={`${btnContour} !px-3 !h-9`}>
            <Icon name="refresh" className={`h-4 w-4 ${chargementListe ? 'animate-spin' : ''}`} />
          </button>
          <button type="button" onClick={() => ouvrirTiroir('scan')} className={`${btnContour} !h-9`}>
            <Icon name="upload" className="h-4 w-4" />
            <span className="hidden sm:inline">Importer un scan</span>
          </button>
          <button type="button" onClick={() => ouvrirTiroir('manuel')} className={`${btnPrimaire} !h-9`}>
            <Icon name="plus" className="h-4 w-4" />
            <span className="hidden sm:inline">Saisie manuelle</span>
          </button>
        </>
      }
    >
      <style>{STYLES}</style>

      {!tiroirOuvert && messages}

      {vue === 'apercu' && (
        <>
          <div className="grid min-w-0 gap-4 lg:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)]">
            <section className="rh-in rh-sheen relative min-w-0 overflow-hidden rounded-[24px] bg-gradient-to-br from-[#0A3D5C] via-[#0A5378] to-[#00678F] p-5 text-white shadow-[0_28px_48px_-28px_rgba(10,61,92,.75)] sm:p-6">
              <svg aria-hidden="true" viewBox="0 0 400 400" className="pointer-events-none absolute -right-20 -top-24 h-[360px] w-[360px] text-white">
                <g className="rh-orbit" fill="none" stroke="currentColor" strokeLinecap="round">
                  <circle cx="200" cy="200" r="190" strokeOpacity=".07" />
                  <circle cx="200" cy="200" r="150" strokeOpacity=".09" strokeDasharray="2 10" />
                  <circle cx="200" cy="200" r="110" strokeOpacity=".12" />
                  <path d="M200 10 A190 190 0 0 1 390 200" strokeOpacity=".28" strokeWidth="2" />
                  <path d="M200 90 A110 110 0 0 1 310 200" strokeOpacity=".22" strokeWidth="2" />
                </g>
              </svg>
              <div aria-hidden="true" className="pointer-events-none absolute inset-0 opacity-[0.05] [background-image:linear-gradient(white_1px,transparent_1px),linear-gradient(90deg,white_1px,transparent_1px)] [background-size:36px_36px]" />
              <div className="relative flex h-full min-w-0 flex-col">
                <p className="inline-flex w-fit items-center gap-2 rounded-full border border-white/20 bg-white/10 px-2.5 py-1 text-[11px] font-medium text-white/90 backdrop-blur-sm">
                  <Icon name="shield" className="h-3.5 w-3.5" />
                  Suivi des droits à congé
                </p>
                <h2 className="men-serif mt-4 max-w-lg text-3xl font-normal leading-[1.1] sm:text-4xl">
                  {chargementStats
                    ? 'Chargement des données'
                    : nombreAVerifier > 0
                      ? `${nombreAVerifier} décision${nombreAVerifier > 1 ? 's' : ''} à vérifier`
                      : 'Tout est à jour'}
                </h2>
                <p className="mt-3 max-w-md text-xs leading-relaxed text-white/75">
                  {nombreAVerifier > 0
                    ? 'Contrôlez ces décisions puis activez les soldes des années concernées.'
                    : 'Toutes les décisions enregistrées sont validées.'}
                </p>
                <div className="mt-5 flex flex-wrap gap-3">
                  {nombreAVerifier > 0 && (
                    <button type="button" onClick={voirADeverifier} className="group inline-flex h-9 items-center gap-2 rounded-xl bg-white px-4 text-xs font-semibold text-[#00678F] shadow-[0_10px_24px_-12px_rgba(0,0,0,.4)] transition duration-200 hover:bg-[#F3F7FA] active:scale-[.98] focus:outline-none focus-visible:ring-4 focus-visible:ring-white/50">
                      Voir les décisions
                      <Icon name="arrow" className="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-x-1" />
                    </button>
                  )}
                  <button type="button" onClick={() => ouvrirTiroir('scan')} className="inline-flex h-9 items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-4 text-xs font-semibold text-white backdrop-blur-sm transition duration-200 hover:bg-white/20 active:scale-[.98] focus:outline-none focus-visible:ring-4 focus-visible:ring-white/50">
                    <Icon name="upload" className="h-3.5 w-3.5" />
                    Importer un scan
                  </button>
                </div>
                <div className="mt-auto pt-5">
                  <div className="mb-1.5 flex items-baseline justify-between text-[11px] text-white/70">
                    <span>Décisions validées</span>
                    <span className="tabular-nums">{valeurStat(nombreValides)} sur {valeurStat(total)}</span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-white/15">
                    <div className="rh-bar h-full rounded-full bg-white" style={{ width: `${Math.round(ratioValides * 100)}%`, ...delai(600) }} />
                  </div>
                </div>
              </div>
            </section>

            <section className={`rh-in flex min-w-0 flex-col justify-center gap-4 p-5 sm:flex-row sm:items-center ${carte}`} style={delai(120)}>
              <div className="mx-auto sm:mx-0">
                <Anneau ratio={ratioValides} centre={
                  <div>
                    <p className="men-serif text-4xl leading-none tabular-nums text-[#0F2437]">{pourcentageAffiche}%</p>
                    <p className="mt-1 text-[11px] font-medium text-[#5B6B7C]">validées</p>
                  </div>
                } />
              </div>
              <ul className="min-w-0 flex-1 divide-y divide-[#EEF1F5]">
                <li className="pb-3">
                  <div className="flex items-center gap-2 text-xs text-[#5B6B7C]">
                    <span className="h-2 w-2 rounded-full bg-[#518929]" />
                    Valides
                  </div>
                  <p className="men-serif mt-1 text-2xl tabular-nums text-[#0F2437]">{valeurStat(nombreValides)}</p>
                </li>
                <li className="pt-3">
                  <div className="flex items-center gap-2 text-xs text-[#5B6B7C]">
                    <span className="h-2 w-2 rounded-full bg-amber-500" />
                    À vérifier
                  </div>
                  <p className="men-serif mt-1 text-2xl tabular-nums text-[#0F2437]">{valeurStat(nombreAVerifier)}</p>
                </li>
              </ul>
            </section>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <TuileKpi libelle="Décisions" valeur={valeurStat(total)} note="Enregistrées au total" part={100} icone="file" ton="bleu" retard={160} />
            <TuileKpi libelle="Valides" valeur={valeurStat(nombreValides)} note="Soldes prêts à activer" part={part(nombreValides)} icone="check" ton="vert" retard={220} />
            <TuileKpi libelle="À vérifier" valeur={valeurStat(nombreAVerifier)} note="En attente de contrôle" part={part(nombreAVerifier)} icone="clock" ton="ambre" retard={280} />
            <TuileKpi libelle="Issues d’un scan" valeur={valeurStat(nombreOCR)} note="Reconnues automatiquement" part={part(nombreOCR)} icone="scan" ton="bleuMoyen" retard={340} />
          </div>

          <div className="grid min-w-0 gap-4 lg:grid-cols-3">
            <Panneau titre="Décisions émises" sousTitre="Évolution sur les 6 derniers mois" icone="calendar" accent="#00678F" retard={380} className="lg:col-span-2">
              <Courbe points={courbeMensuelle} />
            </Panneau>
            <Panneau
              titre="À traiter"
              sousTitre="Décisions à vérifier"
              icone="clock"
              accent="#F59E0B"
              retard={440}
              action={aTraiter.length > 0 ? (
                <button type="button" onClick={voirADeverifier} className="shrink-0 rounded-lg px-2.5 py-1 text-xs font-semibold text-[#00678F] transition hover:bg-[#00678F]/10 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00678F]/40">
                  Tout voir
                </button>
              ) : undefined}
            >
              {aTraiter.length === 0 ? (
                <div className="py-6 text-center">
                  <span className="rh-pop mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-[#518929]/10 text-[#3F6F1F]">
                    <Icon name="check" className="h-6 w-6" />
                  </span>
                  <p className="mt-3 text-sm text-[#5B6B7C]">Rien à vérifier</p>
                </div>
              ) : (
                <ul className="-mx-2 space-y-0.5">
                  {aTraiter.slice(0, 5).map((decision, i) => {
                    const nom = nomPersonnel(decision.personnel_detail)
                    return (
                      <li key={decision.id_decision} className="rh-in flex items-center gap-3 rounded-xl p-2 transition-colors hover:bg-[#F3F7FA]" style={delai(500 + i * 70)}>
                        <Avatar nom={nom} />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-semibold text-[#0F2437]">{decision.numero_decision}</p>
                          <p className="truncate text-xs text-[#5B6B7C]">{nom}</p>
                        </div>
                        <button type="button" onClick={() => void confirmerActivation(decision)} disabled={actionEnCours === decision.id_decision} className={btnActiver}>
                          {actionEnCours === decision.id_decision ? <Icon name="loader" className="h-3.5 w-3.5 animate-spin" /> : <Icon name="bolt" className="h-3.5 w-3.5" />}
                          Activer
                        </button>
                      </li>
                    )
                  })}
                </ul>
              )}
            </Panneau>
          </div>

          <div className="grid min-w-0 gap-4 lg:grid-cols-2">
            <Panneau titre="Par année au titre du congé" sousTitre="Les 5 années les plus récentes" icone="calendar" accent="#0A82B9" retard={500}>
              {repartitionAnnees.length > 0 ? <BarresAnnee elements={repartitionAnnees} /> : <p className="py-6 text-center text-sm text-[#94A3B8]">Aucune donnée</p>}
            </Panneau>
            <Panneau titre="Origine des données" sousTitre="Scan OCR ou saisie manuelle" icone="scan" accent="#518929" retard={560}>
              <div className="grid gap-4 sm:grid-cols-2">
                {[
                  { libelle: 'Scan (OCR)', valeur: nombreOCR, fond: 'border-[#E3E8EE] bg-[#F7F9FB]', barre: '#0A3D5C', icone: 'scan' as IconName },
                  { libelle: 'Saisie manuelle', valeur: nombreManuel, fond: 'border-[#D5E6EF] bg-[#F3F9FC]', barre: '#00678F', icone: 'edit' as IconName },
                ].map((bloc, i) => (
                  <div key={bloc.libelle} className={`rounded-2xl border p-4 ${bloc.fond}`}>
                    <div className="flex items-center gap-2 text-sm font-medium text-[#0F2437]">
                      <Icon name={bloc.icone} className="h-4 w-4" />
                      {bloc.libelle}
                    </div>
                    <p className="men-serif mt-3 text-3xl tabular-nums text-[#0F2437]">{valeurStat(bloc.valeur)}</p>
                    <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-white">
                      <div className="rh-bar h-full rounded-full" style={{ width: `${part(bloc.valeur)}%`, backgroundColor: bloc.barre, ...delai(700 + i * 120) }} />
                    </div>
                    <p className="mt-2 text-xs text-[#5B6B7C]">{Math.round(part(bloc.valeur))}% du total</p>
                  </div>
                ))}
              </div>
            </Panneau>
          </div>
        </>
      )}

      {vue === 'decisions' && (
        <section className={`rh-in min-w-0 overflow-hidden ${carte}`}>
          <div className="flex flex-col gap-4 border-b border-[#E3E8EE] p-4 sm:p-5 lg:flex-row lg:items-center lg:justify-between">
            <Bascule<FiltreDecision>
              nom="Filtrer les décisions"
              valeur={filtre}
              onChange={(valeur) => {
                setFiltre(valeur)
                void chargerDecisions(rechercheDecision, valeur)
              }}
              options={[
                { valeur: 'toutes', libelle: 'Toutes' },
                { valeur: 'valides', libelle: 'Valides' },
                { valeur: 'non_validees', libelle: 'À vérifier' },
              ]}
            />
            <form
              onSubmit={(e) => {
                e.preventDefault()
                void chargerDecisions(rechercheDecision, filtre)
              }}
              className="flex min-w-0 gap-2 lg:w-[26rem]"
            >
              <label className="group relative min-w-0 flex-1">
                <span className="sr-only">Rechercher</span>
                <Icon name="search" className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#94A3B8] transition-colors group-focus-within:text-[#00678F]" />
                <input value={rechercheDecision} onChange={(e) => setRechercheDecision(e.target.value)} placeholder="Numéro, IM ou nom" className={`${champ} pl-10`} />
              </label>
              <button type="submit" disabled={chargementListe} className={btnPrimaire}>Rechercher</button>
            </form>
          </div>

          {!chargementListe && (
            <p className="px-5 pt-4 text-xs text-[#5B6B7C] sm:px-6">
              <span className="font-semibold text-[#0F2437]">{decisions.length}</span> résultat{decisions.length > 1 ? 's' : ''}
            </p>
          )}

          {chargementListe ? (
            <div className="overflow-x-auto p-3" aria-busy="true">
              <table className="w-full min-w-[760px] border-collapse">
                <tbody className="divide-y divide-[#EEF1F5]">
                  {Array.from({ length: 4 }, (_, index) => (
                    <tr key={index} aria-hidden="true">
                      <td className="px-4 py-4"><span className="block h-3.5 w-32 animate-pulse rounded bg-[#E3E8EE]" /><span className="mt-2 block h-2.5 w-20 animate-pulse rounded bg-[#EEF1F5]" /></td>
                      <td className="px-3 py-4"><span className="block h-3.5 w-40 animate-pulse rounded bg-[#E3E8EE]" /></td>
                      <td className="px-3 py-4"><span className="block h-3.5 w-16 animate-pulse rounded bg-[#E3E8EE]" /></td>
                      <td className="px-3 py-4"><span className="block h-3.5 w-24 animate-pulse rounded bg-[#E3E8EE]" /></td>
                      <td className="px-3 py-4"><span className="block h-6 w-20 animate-pulse rounded-full bg-[#E3E8EE]" /></td>
                      <td className="px-4 py-4" />
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : decisions.length === 0 ? (
            <div className="px-6 py-20 text-center">
              <span className="rh-pop mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-[#00678F]/10 text-[#00678F] ring-8 ring-[#00678F]/5">
                <Icon name="file" className="h-8 w-8" />
              </span>
              <p className="men-serif mt-5 text-3xl text-[#0F2437]">Aucune décision</p>
              <p className="mt-1 text-sm text-[#5B6B7C]">Rien ne correspond pour le moment.</p>
              <button type="button" onClick={() => ouvrirTiroir('manuel')} className={`${btnPrimaire} mt-6`}>
                <Icon name="plus" className="h-4 w-4" /> Saisie manuelle
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px] border-collapse text-left text-sm">
                <thead>
                  <tr className="border-y border-[#E3E8EE] bg-[#F8FAFC] text-xs font-semibold text-[#5B6B7C]">
                    <th scope="col" className="px-6 py-3">Décision</th>
                    <th scope="col" className="px-4 py-3">Agent</th>
                    <th scope="col" className="px-4 py-3">Année(s)</th>
                    <th scope="col" className="px-4 py-3">Émission</th>
                    <th scope="col" className="px-4 py-3">Statut</th>
                    <th scope="col" className="px-6 py-3"><span className="sr-only">Action</span></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#EEF1F5]">
                  {decisions.map((decision, index) => {
                    const nom = nomPersonnel(decision.personnel_detail)
                    const estOCR = decision.nature === 'OCR'
                    return (
                      <tr key={decision.id_decision} className="rh-in group relative transition-colors duration-200 hover:bg-[#F3F7FA]" style={delai(Math.min(index, 10) * 45)}>
                        <td className="relative px-6 py-4">
                          <span aria-hidden="true" className="absolute inset-y-3 left-0 w-[3px] origin-center scale-y-0 rounded-r-full bg-[#00678F] transition-transform duration-300 group-hover:scale-y-100" />
                          <p className="font-semibold text-[#0F2437]">{decision.numero_decision}</p>
                          <span className={`mt-1 inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[11px] font-medium ${estOCR ? 'bg-[#00678F]/10 text-[#00678F]' : 'bg-slate-500/10 text-[#475569]'}`}>
                            {estOCR && <Icon name="scan" className="h-3 w-3" />}
                            {decision.nature_libelle || decision.nature || '—'}
                          </span>
                        </td>
                        <td className="px-4 py-4">
                          <div className="flex items-center gap-3">
                            <Avatar nom={nom} className="h-10 w-10 text-xs" />
                            <div className="min-w-0">
                              <p className="truncate font-medium text-[#0F2437]">{nom}</p>
                              <p className="mt-0.5 text-xs text-[#5B6B7C]">IM : {decision.personnel_detail?.im || '—'}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-4 font-medium tabular-nums text-[#0F2437]">{decision.annees_titre}</td>
                        <td className="px-4 py-4">
                          <span className="inline-flex items-center gap-1.5 text-[#0F2437]">
                            <Icon name="calendar" className="h-3.5 w-3.5 text-[#94A3B8]" />
                            {decision.date_emission || '—'}
                          </span>
                        </td>
                        <td className="px-4 py-4"><Statut valide={decision.est_valide} /></td>
                        <td className="px-6 py-4">
                          <div className="flex justify-end">
                            <button type="button" onClick={() => void confirmerActivation(decision)} disabled={actionEnCours === decision.id_decision} className={btnActiver}>
                              {actionEnCours === decision.id_decision ? <Icon name="loader" className="h-3.5 w-3.5 animate-spin" /> : <Icon name="bolt" className="h-3.5 w-3.5" />}
                              Activer les soldes
                            </button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
      )}

      {vue === 'reports' && (
        <section className={`rh-in mx-auto max-w-3xl p-6 sm:p-8 ${carte}`}>
          <div className="flex items-start gap-4">
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-[#00678F]/10 text-[#00678F]">
              <Icon name="refresh" className="h-6 w-6" />
            </span>
            <div>
              <h2 className="men-serif text-2xl text-[#0F2437]">Choisir l’année à reporter</h2>
              <p className="mt-1 text-sm text-[#5B6B7C]">Les reliquats de l’année source sont reportés vers l’année suivante.</p>
            </div>
          </div>
          <form onSubmit={executerReport} className="mt-8">
            <div className="grid items-center gap-4 sm:grid-cols-[1fr_auto_1fr]">
              <div className="rounded-2xl border border-[#E3E8EE] bg-[#F7F9FB] p-5 text-center">
                <p className="text-xs font-medium text-[#5B6B7C]">Année source</p>
                <div className="mt-3 flex items-center justify-center gap-2">
                  <button type="button" onClick={() => ajusterAnnee(-1)} aria-label="Année précédente" className="grid h-9 w-9 place-items-center rounded-full border border-[#D5DCE5] bg-white text-[#0F2437] transition hover:bg-[#F3F6F9] active:scale-90 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00678F]/50">
                    <Icon name="minus" className="h-4 w-4" />
                  </button>
                  <label className="relative">
                    <span className="sr-only">Année source</span>
                    <input id="annee_source" type="number" min="1900" max={new Date().getFullYear() - 1} required value={anneeSource} onChange={(e) => setAnneeSource(e.target.value)} className="men-serif w-32 rounded-md border-b-2 border-transparent bg-transparent text-center text-5xl leading-none tabular-nums text-[#0F2437] outline-none transition focus:border-[#00678F] [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none" />
                  </label>
                  <button type="button" onClick={() => ajusterAnnee(1)} aria-label="Année suivante" className="grid h-9 w-9 place-items-center rounded-full border border-[#D5DCE5] bg-white text-[#0F2437] transition hover:bg-[#F3F6F9] active:scale-90 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00678F]/50">
                    <Icon name="plus" className="h-4 w-4" />
                  </button>
                </div>
              </div>
              <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-[#00678F] text-white shadow-[0_10px_22px_-8px_rgba(0,103,143,.7)] sm:rotate-0 rotate-90">
                <Icon name="arrow" className="h-5 w-5" />
              </span>
              <div className="rounded-2xl border border-[#D5E6EF] bg-[#F3F9FC] p-5 text-center">
                <p className="text-xs font-medium text-[#00678F]">Année cible</p>
                <p key={anneeCible ?? 'vide'} aria-live="polite" className="rh-pop men-serif mt-3 text-5xl leading-[1.1] tabular-nums text-[#00678F]">{anneeCible ?? '—'}</p>
              </div>
            </div>
            <button type="submit" disabled={reportEnCours} className={`${btnPrimaire} mt-8 w-full`}>
              {reportEnCours ? <Icon name="loader" className="h-4 w-4 animate-spin" /> : <Icon name="refresh" className="h-4 w-4" />}
              {reportEnCours ? 'Report en cours' : 'Reporter les reliquats'}
            </button>
          </form>
        </section>
      )}

      <Tiroir
        ouvert={tiroirOuvert}
        onFermer={fermerTiroir}
        titre="Nouvelle décision"
        sousTitre={modeSaisie === 'scan' ? 'Le scan est analysé, puis vous vérifiez les informations.' : 'Renseignez la décision à la main.'}
        pied={
          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:items-center sm:justify-between">
            <button type="button" onClick={reinitialiserFormulaire} className={btnContour}>
              <Icon name="refresh" className="h-4 w-4" /> Réinitialiser
            </button>
            <div className="flex gap-2">
              <button type="button" onClick={fermerTiroir} className={`${btnContour} flex-1 sm:flex-none`}>Annuler</button>
              <button type="submit" form="formulaire-decision" disabled={enregistrement || chargementScan} className={`${btnPrimaire} flex-1 sm:flex-none`}>
                {enregistrement ? <Icon name="loader" className="h-4 w-4 animate-spin" /> : <Icon name="check" className="h-4 w-4" />}
                {enregistrement ? 'Enregistrement' : 'Enregistrer'}
              </button>
            </div>
          </div>
        }
      >
        <div className="space-y-5">
          {tiroirOuvert && messages}
          <Bascule<ModeSaisie>
            nom="Mode de saisie"
            valeur={modeSaisie}
            onChange={changerMode}
            options={[
              { valeur: 'scan', libelle: 'Importer un scan' },
              { valeur: 'manuel', libelle: 'Saisie manuelle' },
            ]}
          />

          {modeSaisie === 'scan' && (
            <div className="space-y-3">
              <label
                htmlFor="fichier-scan-decision"
                onDragOver={(evenement) => { evenement.preventDefault(); setGlisse(true) }}
                onDragLeave={() => setGlisse(false)}
                onDrop={deposerFichier}
                className={`group relative flex cursor-pointer flex-col items-center justify-center gap-3 overflow-hidden rounded-2xl border-2 border-dashed px-6 py-10 text-center transition duration-300 focus-within:ring-4 focus-within:ring-[#00678F]/15 ${glisse ? 'scale-[1.01] border-[#00678F] bg-[#00678F]/[0.06]' : 'border-[#C5D1DE] bg-white hover:border-[#00678F] hover:bg-[#F7FAFC]'} ${chargementScan || enregistrement ? 'pointer-events-none opacity-80' : ''}`}
              >
                <span className={`grid h-14 w-14 place-items-center rounded-2xl bg-[#00678F]/10 text-[#00678F] transition-transform duration-300 ${glisse ? '-translate-y-1 scale-110' : 'group-hover:-translate-y-1'}`}>
                  <Icon name={chargementScan ? 'scan' : 'upload'} className="h-7 w-7" />
                </span>
                <span className="text-sm font-semibold text-[#0F2437]">{chargementScan ? 'Analyse en cours' : 'Déposer un scan ou parcourir'}</span>
                <span className="text-xs text-[#5B6B7C]">PDF, PNG, JPG ou TIFF</span>
                <input id="fichier-scan-decision" type="file" accept=".pdf,.png,.jpg,.jpeg,.tif,.tiff" onChange={(e) => void traiterScan(e.target.files?.[0] ?? null)} disabled={chargementScan || enregistrement} className="sr-only" />
                {chargementScan && (
                  <span aria-hidden="true" className="absolute inset-x-0 bottom-0 h-1 overflow-hidden bg-[#00678F]/10">
                    <span className="men-indet block h-full w-2/5 rounded-full bg-[#00678F]" />
                  </span>
                )}
              </label>

              {fichierScan && (
                <div className="rh-pop flex items-center gap-3 rounded-xl border border-[#E3E8EE] bg-white px-3.5 py-2.5">
                  <span className="grid h-9 w-9 place-items-center rounded-lg bg-[#00678F]/10 text-[#00678F]">
                    <Icon name="file" className="h-[18px] w-[18px]" />
                  </span>
                  <span className="min-w-0 flex-1 truncate text-sm font-medium text-[#0F2437]">{fichierScan.name}</span>
                  <button type="button" onClick={retirerFichier} disabled={chargementScan || enregistrement} className={btnIcone}><Icon name="close" className="h-4 w-4" /></button>
                </div>
              )}

              {resultatScan && (
                <div className="rh-pop space-y-3 rounded-2xl border border-[#E3E8EE] bg-white p-4">
                  <span className="inline-flex items-center gap-1.5 rounded-md bg-[#00678F]/10 px-2.5 py-1.5 text-xs font-semibold text-[#00678F]">
                    <Icon name="scan" className="h-3.5 w-3.5" />
                    {resultatScan.nature || 'Saisie manuelle'}
                  </span>
                  {resultatScan.agent ? (
                    <div className="flex items-center gap-3 rounded-xl border border-[#DCE9D2] bg-[#F5F9F1] px-3.5 py-3 text-sm text-[#3F6F1F]">
                      <Icon name="check" className="h-4 w-4 shrink-0" />
                      <span className="min-w-0"><strong className="font-semibold">{nomPersonnel(resultatScan.agent)}</strong><span className="opacity-80"> · IM {resultatScan.agent.im}</span></span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-3 rounded-xl border border-[#F3E4BF] bg-[#FFFAF0] px-3.5 py-3 text-sm text-amber-800">
                      <Icon name="alert" className="h-4 w-4 shrink-0" /> Aucun agent identifié.
                    </div>
                  )}
                  {resultatScan.donnees_extraites.texte_brut && (
                    <details className="group text-sm">
                      <summary className="flex cursor-pointer list-none items-center gap-2 font-medium text-[#0F2437] [&::-webkit-details-marker]:hidden">
                        <Icon name="right" className="h-4 w-4 transition-transform duration-200 group-open:rotate-90" />
                        Texte détecté
                      </summary>
                      <pre className="mt-3 max-h-56 overflow-auto whitespace-pre-wrap rounded-xl bg-[#F3F5F8] p-3 text-xs text-[#0F2437]">{resultatScan.donnees_extraites.texte_brut}</pre>
                    </details>
                  )}
                </div>
              )}
            </div>
          )}

          <form id="formulaire-decision" onSubmit={soumettreDecision} className="space-y-4">
            <GroupeFormulaire icone="file" titre="Décision" tonChip="bg-[#00678F]/10 text-[#00678F]" retard={0}>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <div className="group">
                  <label htmlFor="numero_decision" className={etiquette}>Numéro</label>
                  <input id="numero_decision" required value={formulaire.numero_decision} onChange={(e) => modifierChamp('numero_decision', e.target.value)} className={champ} />
                </div>
                <div className="group">
                  <label htmlFor="date_emission" className={etiquette}>Date d’émission</label>
                  <input id="date_emission" type="date" required value={formulaire.date_emission} onChange={(e) => modifierChamp('date_emission', e.target.value)} className={champ} />
                </div>
                <div className="group">
                  <label htmlFor="annees_titre" className={etiquette}>Année(s) au titre du congé</label>
                  <input id="annees_titre" required placeholder="2026 ou 2025-2026" value={formulaire.annees_titre} onChange={(e) => modifierChamp('annees_titre', e.target.value)} className={champ} />
                </div>
              </div>
            </GroupeFormulaire>

            <GroupeFormulaire icone="user" titre="Agent" tonChip="bg-[#0A82B9]/10 text-[#0A82B9]" retard={70}>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="group">
                  <label htmlFor="recherche_personnel" className={etiquette}>Rechercher</label>
                  <div className="flex gap-2">
                    <div className="relative min-w-0 flex-1">
                      <Icon name="search" className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#94A3B8] transition-colors group-focus-within:text-[#00678F]" />
                      <input id="recherche_personnel" value={recherchePersonnel} onChange={(e) => setRecherchePersonnel(e.target.value)} onKeyDown={rechercherAgentAuClavier} placeholder="Nom, prénom ou IM" className={`${champ} pl-10`} />
                    </div>
                    <button type="button" onClick={() => void chargerPersonnels()} className={`${btnContour} !h-11 !px-3`}><Icon name="search" className="h-4 w-4" /></button>
                  </div>
                </div>
                <div className="group">
                  <label htmlFor="personnel" className={etiquette}>Agent concerné</label>
                  <select id="personnel" required value={formulaire.personnel} onChange={(e) => selectionnerPersonnel(e.target.value)} className={champ}>
                    <option value="">Sélectionner un agent</option>
                    {personnels.map((personnel) => (
                      <option key={personnel.id_personnel} value={personnel.id_personnel}>{nomPersonnel(personnel)} — IM {personnel.im}</option>
                    ))}
                  </select>
                  {agentSelectionne && (
                    <p className="rh-pop mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[#5B6B7C]">
                      <span className="inline-flex items-center gap-1.5"><Icon name="building" className="h-3.5 w-3.5" />{agentSelectionne.direction_libelle || formulaire.direction || 'Non renseignée'}</span>
                      {agentSelectionne.statut && <span className="rounded-md bg-[#00678F]/10 px-2 py-0.5 font-medium text-[#00678F]">{agentSelectionne.statut}</span>}
                    </p>
                  )}
                </div>
              </div>
            </GroupeFormulaire>

            <GroupeFormulaire icone="wallet" titre="Budget et grade" tonChip="bg-[#0A3D5C]/10 text-[#0A3D5C]" retard={140}>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="group"><label htmlFor="budget" className={etiquette}>Budget</label><input id="budget" value={formulaire.budget} onChange={(e) => modifierChamp('budget', e.target.value)} className={champ} /></div>
                <div className="group"><label htmlFor="imputation_budgetaire" className={etiquette}>Imputation budgétaire</label><input id="imputation_budgetaire" value={formulaire.imputation_budgetaire} onChange={(e) => modifierChamp('imputation_budgetaire', e.target.value)} className={champ} /></div>
                <div className="group"><label htmlFor="corps_grade" className={etiquette}>Corps / grade</label><input id="corps_grade" value={formulaire.corps_grade} onChange={(e) => modifierChamp('corps_grade', e.target.value)} className={champ} /></div>
                <div className="group"><label htmlFor="indice" className={etiquette}>Indice</label><input id="indice" type="number" min="0" value={formulaire.indice} onChange={(e) => modifierChamp('indice', e.target.value)} className={champ} /></div>
              </div>
            </GroupeFormulaire>

            <GroupeFormulaire icone="list" titre="Compléments" tonChip="bg-slate-500/10 text-[#475569]" retard={210}>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="group"><label htmlFor="date_demande_reference" className={etiquette}>Date de demande de référence</label><input id="date_demande_reference" type="date" value={formulaire.date_demande_reference} onChange={(e) => modifierChamp('date_demande_reference', e.target.value)} className={champ} /></div>
                <div className="group"><label htmlFor="signataire" className={etiquette}>Signataire</label><input id="signataire" value={formulaire.signataire} onChange={(e) => modifierChamp('signataire', e.target.value)} className={champ} /></div>
                <div className="group sm:col-span-2"><label htmlFor="details_jours" className={etiquette}>Détails des jours</label><textarea id="details_jours" rows={3} value={formulaire.details_jours} onChange={(e) => modifierChamp('details_jours', e.target.value)} className={zoneTexte} /></div>
              </div>
            </GroupeFormulaire>
          </form>
        </div>
      </Tiroir>
    </CoquilleRH>
  )
}