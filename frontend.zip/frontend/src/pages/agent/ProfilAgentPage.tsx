import { useRef, useState, type CSSProperties, type KeyboardEvent, type ReactNode } from 'react'
import { Navigate, Link } from 'react-router'
import { useAuth } from '../../contexts/useAuth'
import { Icon, type IconName } from '../../components/men/ui'
import { delai } from '../../components/men/ui-outils'

const STYLES = `
@import url('https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Newsreader:opsz,wght@6..72,400;6..72,500;6..72,600&display=swap');

.prof-root{font-family:'Manrope',ui-sans-serif,system-ui,-apple-system,'Segoe UI',sans-serif;font-feature-settings:'tnum' 0}
.prof-root .men-serif{font-family:'Newsreader',Georgia,'Times New Roman',serif;font-weight:500;letter-spacing:-.015em}
.prof-root .tabular-nums{font-variant-numeric:tabular-nums}

@keyframes pr-rise{from{opacity:0;transform:translate3d(0,14px,0)}to{opacity:1;transform:none}}
@keyframes pr-row{from{opacity:0;transform:translate3d(-8px,0,0)}to{opacity:1;transform:none}}
@keyframes pr-panel{from{opacity:0;transform:translate3d(0,8px,0)}to{opacity:1;transform:none}}
@keyframes pr-ring{from{opacity:0;transform:scale(.82)}to{opacity:1;transform:none}}
@keyframes pr-bar{from{transform:scaleX(0)}to{transform:scaleX(1)}}
@keyframes pr-pop{0%{opacity:0;transform:scale(.92)}100%{opacity:1;transform:none}}
@keyframes pr-orbit{to{transform:rotate(360deg)}}
@keyframes pr-sheen{from{transform:translateX(-120%)}to{transform:translateX(280%)}}

.pr-rise{animation:pr-rise .65s cubic-bezier(.22,1,.36,1) var(--d,0ms) backwards}
.pr-row{animation:pr-row .45s cubic-bezier(.22,1,.36,1) var(--d,0ms) backwards}
.pr-panel{animation:pr-panel .4s cubic-bezier(.22,1,.36,1) backwards}
.pr-ring{animation:pr-ring .8s cubic-bezier(.22,1,.36,1) 250ms backwards}
.pr-bar{transform-origin:left center;animation:pr-bar .9s cubic-bezier(.22,1,.36,1) var(--d,0ms) backwards}
.pr-pop{animation:pr-pop .45s cubic-bezier(.22,1,.36,1) backwards}
.pr-orbit{animation:pr-orbit 90s linear infinite;transform-origin:center}
.pr-sheen::after{content:"";position:absolute;inset:0;width:36%;pointer-events:none;
  background:linear-gradient(100deg,transparent,rgba(255,255,255,.18),transparent);
  animation:pr-sheen 1.5s cubic-bezier(.4,0,.2,1) var(--d,600ms) 1 backwards}

@media (prefers-reduced-motion:reduce){
  .pr-rise,.pr-row,.pr-panel,.pr-ring,.pr-bar,.pr-pop,.pr-orbit,.pr-sheen::after{animation:none!important}
}
`

const carte =
  'rounded-[20px] border border-[#E3E8EE] bg-white shadow-[0_1px_2px_rgba(15,36,55,0.04),0_10px_28px_-18px_rgba(15,36,55,0.14)]'

function dateLisible(date: string | null | undefined): string {
  if (!date) return ''
  const valeur = new Date(date)
  if (Number.isNaN(valeur.getTime())) return ''
  return new Intl.DateTimeFormat('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' }).format(valeur)
}

function initiales(nom: string): string {
  const lettres = nom
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((mot) => mot[0]?.toUpperCase())
    .join('')
  return lettres || '?'
}

function Section({
  icone,
  titre,
  description,
  children,
  retard = 0,
}: {
  icone: IconName
  titre: string
  description?: string
  children: ReactNode
  retard?: number
}) {
  return (
    <section className={`pr-row relative overflow-hidden ${carte}`} style={delai(retard)}>
      <header className="flex items-center gap-3 border-b border-[#E3E8EE] bg-[#F8FAFC] px-5 py-4 sm:px-6">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#00678F]/10 text-[#00678F]">
          <Icon name={icone} className="h-5 w-5" />
        </span>
        <div className="min-w-0">
          <h2 className="text-base font-bold text-[#0F2437]">{titre}</h2>
          {description && <p className="text-xs text-[#5B6B7C]">{description}</p>}
        </div>
      </header>
      <dl className="divide-y divide-[#EEF1F5] px-2 py-1 sm:px-3">{children}</dl>
    </section>
  )
}

function Ligne({
  libelle,
  valeur,
  retard,
}: {
  libelle: string
  valeur: string | number | null | undefined
  retard: number
}) {
  const vide = valeur === null || valeur === undefined || valeur === ''
  return (
    <div
      className="pr-row flex flex-col gap-0.5 rounded-lg px-3 py-3.5 transition-colors duration-200 hover:bg-[#F3F7FA] sm:flex-row sm:items-center sm:justify-between sm:gap-6"
      style={delai(retard)}
    >
      <dt className="text-[13px] text-[#5B6B7C]">{libelle}</dt>
      <dd
        className={`break-words text-sm sm:text-right ${
          vide ? 'font-normal italic text-[#94A3B8]' : 'font-semibold text-[#0F2437]'
        }`}
      >
        {vide ? 'Non renseigné' : String(valeur)}
      </dd>
    </div>
  )
}

const TONS_KPI = {
  bleu: {
    fond: 'from-[#0A5378] via-[#00678F] to-[#0A82B9]',
    ombre: 'shadow-[0_22px_38px_-22px_rgba(0,103,143,.8)]',
  },
  vert: {
    fond: 'from-[#2F6A1A] via-[#3F7D20] to-[#5B9A33]',
    ombre: 'shadow-[0_22px_38px_-22px_rgba(63,125,32,.8)]',
  },
  ambre: {
    fond: 'from-[#9A4A0A] via-[#B45309] to-[#D97706]',
    ombre: 'shadow-[0_22px_38px_-22px_rgba(180,83,9,.8)]',
  },
} as const

function Synthese({
  icone,
  libelle,
  valeur,
  ton,
  retard,
}: {
  icone: IconName
  libelle: string
  valeur: string
  ton: keyof typeof TONS_KPI
  retard: number
}) {
  const s = TONS_KPI[ton]
  return (
    <div
      className={`pr-rise pr-sheen relative overflow-hidden rounded-[20px] bg-gradient-to-br p-5 text-white sm:p-6 ${s.fond} ${s.ombre}`}
      style={{ ...delai(retard), '--d': `${retard}ms` } as CSSProperties}
    >
      <svg
        aria-hidden="true"
        viewBox="0 0 200 200"
        className="pointer-events-none absolute -right-12 -top-14 h-48 w-48 text-white"
      >
        <g className="pr-orbit" fill="none" stroke="currentColor">
          <circle cx="100" cy="100" r="90" strokeOpacity=".12" />
          <circle cx="100" cy="100" r="64" strokeOpacity=".16" strokeDasharray="2 8" />
          <path d="M100 10 A90 90 0 0 1 190 100" strokeOpacity=".4" strokeWidth="2" strokeLinecap="round" />
        </g>
      </svg>
      <div className="relative flex items-center gap-3.5">
        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-white/15 ring-1 ring-inset ring-white/25 backdrop-blur-sm">
          <Icon name={icone} className="h-5 w-5" />
        </span>
        <div className="min-w-0">
          <p className="text-xs font-semibold text-white/85">{libelle}</p>
          <p className="mt-0.5 truncate text-sm font-bold" title={valeur}>
            {valeur}
          </p>
        </div>
      </div>
    </div>
  )
}

type Onglet = 'infos' | 'pro'

const ONGLETS: { id: Onglet; libelle: string }[] = [
  { id: 'infos', libelle: 'Informations' },
  { id: 'pro', libelle: 'Parcours professionnel' },
]

export function ProfilAgentPage() {
  const { utilisateur, chargement } = useAuth()
  const [ongletActif, setOngletActif] = useState<Onglet>('infos')
  const refsOnglets = useRef<Record<Onglet, HTMLButtonElement | null>>({ infos: null, pro: null })

  if (chargement) {
    return (
      <div className="grid min-h-screen place-items-center bg-[#F3F5F8]">
        <style>{STYLES}</style>
        <div className="pr-rise flex flex-col items-center gap-4" role="status" aria-live="polite">
          <span className="h-9 w-9 animate-spin rounded-full border-[3px] border-[#00678F]/15 border-t-[#00678F]" />
          <p className="text-sm text-[#5B6B7C]">Chargement de votre profil…</p>
        </div>
      </div>
    )
  }

  if (!utilisateur) return <Navigate to="/connexion" replace />
  if (utilisateur.role !== 'ROLE_AGENT') return <Navigate to="/app" replace />

  const personnel = utilisateur.personnel

  if (!personnel) {
    return (
      <div className="grid min-h-screen place-items-center bg-[#F3F5F8] p-6">
        <style>{STYLES}</style>
        <section className={`pr-rise max-w-md p-8 text-center ${carte}`}>
          <span className="pr-pop mx-auto grid h-14 w-14 place-items-center rounded-full bg-amber-50 text-amber-700 ring-8 ring-amber-50/60">
            <Icon name="alert" className="h-7 w-7" />
          </span>
          <h1 className="men-serif mt-6 text-2xl text-[#0F2437]">Profil indisponible</h1>
          <p className="mt-3 text-sm leading-relaxed text-[#5B6B7C]">
            Aucun dossier du personnel n’est associé à ce compte. Contactez le service des ressources humaines pour
            vérifier votre rattachement.
          </p>
        </section>
      </div>
    )
  }

  const nomComplet = personnel.nom_complet || `${personnel.prenoms} ${personnel.nom}`.trim()
  const corpsGrade = personnel.corps || personnel.grade || '—'

  const surTouche = (e: KeyboardEvent<HTMLButtonElement>) => {
    const ordre = ONGLETS.map((o) => o.id)
    const i = ordre.indexOf(ongletActif)
    let cible: Onglet | null = null
    if (e.key === 'ArrowRight') cible = ordre[(i + 1) % ordre.length]
    if (e.key === 'ArrowLeft') cible = ordre[(i - 1 + ordre.length) % ordre.length]
    if (e.key === 'Home') cible = ordre[0]
    if (e.key === 'End') cible = ordre[ordre.length - 1]
    if (cible) {
      e.preventDefault()
      setOngletActif(cible)
      refsOnglets.current[cible]?.focus()
    }
  }

  const indexActif = ONGLETS.findIndex((o) => o.id === ongletActif)

  return (
    <div className="prof-root min-h-screen bg-[#F3F5F8] text-[#0F2437]">
      <style>{STYLES}</style>

      <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        
        {/* ---- LIENS VERS LES AUTRES PAGES ---- */}
        <div className="pr-rise mb-6 flex flex-wrap items-center gap-3" style={delai(50)}>
          {/* Liens corrigés avec les URL exactes de App.tsx */}
          <Link 
            to="/app/agent/soldes" 
            className="inline-flex h-10 items-center gap-2 rounded-xl bg-[#00678F] px-5 text-sm font-semibold text-white shadow-[0_1px_2px_rgba(0,103,143,.3),0_8px_16px_-8px_rgba(0,103,143,.55)] transition duration-200 hover:bg-[#005A7D] hover:shadow-none active:scale-[.98]"
          >
            <Icon name="calendar" className="h-4 w-4" /> Mes soldes
          </Link>
          <Link 
            to="/app/agent/mes-demandes" 
            className="inline-flex h-10 items-center gap-2 rounded-xl bg-[#00678F] px-5 text-sm font-semibold text-white shadow-[0_1px_2px_rgba(0,103,143,.3),0_8px_16px_-8px_rgba(0,103,143,.55)] transition duration-200 hover:bg-[#005A7D] hover:shadow-none active:scale-[.98]"
          >
            <Icon name="file" className="h-4 w-4" /> Mes demandes
          </Link>
          <Link 
            to="/app/agent/nouvelle-demande" 
            className="inline-flex h-10 items-center gap-2 rounded-xl bg-[#00678F] px-5 text-sm font-semibold text-white shadow-[0_1px_2px_rgba(0,103,143,.3),0_8px_16px_-8px_rgba(0,103,143,.55)] transition duration-200 hover:bg-[#005A7D] hover:shadow-none active:scale-[.98]"
          >
            <Icon name="plus" className="h-4 w-4" /> Nouvelle demande
          </Link>
          <Link 
            to="/app/agent/historique" 
            className="inline-flex h-10 items-center gap-2 rounded-xl bg-[#00678F] px-5 text-sm font-semibold text-white shadow-[0_1px_2px_rgba(0,103,143,.3),0_8px_16px_-8px_rgba(0,103,143,.55)] transition duration-200 hover:bg-[#005A7D] hover:shadow-none active:scale-[.98]"
          >
            <Icon name="clock" className="h-4 w-4" /> Historique
          </Link>
        </div>

        {/* ---- EN-TÊTE ---- */}
        <header className="pr-rise pr-sheen relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0A3D5C] via-[#0A5378] to-[#00678F] shadow-[0_24px_48px_-24px_rgba(10,61,92,0.55)]">
          <svg aria-hidden="true" viewBox="0 0 400 400" className="pointer-events-none absolute -right-24 -top-28 h-[420px] w-[420px] text-white">
            <g className="pr-orbit" fill="none" stroke="currentColor" strokeLinecap="round">
              <circle cx="200" cy="200" r="190" strokeOpacity=".07" strokeWidth="1" />
              <circle cx="200" cy="200" r="150" strokeOpacity=".09" strokeWidth="1" strokeDasharray="2 10" />
              <circle cx="200" cy="200" r="110" strokeOpacity=".12" strokeWidth="1" />
              <path d="M200 10 A190 190 0 0 1 390 200" strokeOpacity=".28" strokeWidth="2" />
              <path d="M200 90 A110 110 0 0 1 310 200" strokeOpacity=".22" strokeWidth="2" />
            </g>
          </svg>
          <div aria-hidden="true" className="pointer-events-none absolute inset-0 opacity-[0.06] [background-image:linear-gradient(white_1px,transparent_1px),linear-gradient(90deg,white_1px,transparent_1px)] [background-size:36px_36px]" />

          <div className="relative flex flex-col items-center gap-6 px-6 py-9 text-center sm:flex-row sm:items-center sm:gap-8 sm:px-10 sm:py-10 sm:text-left">
            <div className="pr-ring relative shrink-0">
              <span aria-hidden="true" className="absolute -inset-2 rounded-full border border-white/25" />
              <span className="men-serif grid h-28 w-28 place-items-center rounded-full bg-white text-4xl text-[#0A3D5C] shadow-[0_10px_30px_-8px_rgba(0,0,0,0.45)] ring-4 ring-white/20 sm:h-32 sm:w-32 sm:text-5xl">
                {initiales(nomComplet || utilisateur.username)}
              </span>
            </div>

            <div className="min-w-0 flex-1">
              <h1 className="men-serif text-3xl leading-tight text-white sm:text-[2.5rem]">{nomComplet}</h1>
              <p className="mt-2 text-sm text-white/75">
                Immatricule&nbsp;: <span className="font-semibold text-white">{personnel.im}</span>
              </p>

              <div className="mt-4 flex flex-wrap items-center justify-center gap-2 sm:justify-start">
                <span className="inline-flex items-center gap-1.5 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-medium text-white backdrop-blur-sm">
                  <Icon name="shield" className="h-3.5 w-3.5" />
                  {utilisateur.role_libelle || 'Agent'}
                </span>
                {personnel.statut && (
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-medium text-white backdrop-blur-sm">
                    <span className="relative flex h-1.5 w-1.5">
                      <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#8FD14F] opacity-50 motion-reduce:animate-none" />
                      <span className="relative h-1.5 w-1.5 rounded-full bg-[#8FD14F]" />
                    </span>
                    {personnel.statut}
                  </span>
                )}
              </div>
            </div>
          </div>
        </header>

        <div className="mt-5 grid gap-4 sm:grid-cols-3">
          <Synthese icone="building" libelle="Direction" valeur={personnel.direction_libelle || 'Non renseignée'} ton="bleu" retard={120} />
          <Synthese icone="users" libelle="Service" valeur={personnel.service_libelle || 'Non renseigné'} ton="vert" retard={190} />
          <Synthese icone="shield" libelle="Corps / Grade" valeur={corpsGrade} ton="ambre" retard={260} />
        </div>

        <div className="pr-rise mt-8 border-b border-[#DCE2E9]" style={delai(340)}>
          <div role="tablist" aria-label="Sections du profil" className="relative inline-flex">
            {ONGLETS.map((o) => {
              const actif = o.id === ongletActif
              return (
                <button
                  key={o.id}
                  ref={(el) => {
                    refsOnglets.current[o.id] = el
                  }}
                  id={`onglet-${o.id}`}
                  role="tab"
                  type="button"
                  aria-selected={actif}
                  aria-controls={`panneau-${o.id}`}
                  tabIndex={actif ? 0 : -1}
                  onClick={() => setOngletActif(o.id)}
                  onKeyDown={surTouche}
                  className={`relative rounded-t-lg px-5 py-3 text-sm font-semibold transition-colors duration-200 focus:outline-none focus-visible:ring-4 focus-visible:ring-[#00678F]/25 ${
                    actif ? 'text-[#00678F]' : 'text-[#5B6B7C] hover:text-[#0F2437]'
                  }`}
                >
                  {o.libelle}
                </button>
              )
            })}
            <span
              aria-hidden="true"
              className="absolute -bottom-px left-0 h-[3px] rounded-full bg-[#00678F] transition-transform duration-300 ease-[cubic-bezier(.22,1,.36,1)]"
              style={{
                width: `${100 / ONGLETS.length}%`,
                transform: `translateX(${indexActif * 100}%)`,
              }}
            />
          </div>
        </div>

        <div className="mt-6 min-h-[320px]">
          {ongletActif === 'infos' && (
            <div
              key="infos"
              id="panneau-infos"
              role="tabpanel"
              aria-labelledby="onglet-infos"
              className="pr-panel grid items-start gap-5 md:grid-cols-2"
            >
              <Section icone="user" titre="Informations personnelles" description="État civil de l’agent">
                <Ligne libelle="Nom" valeur={personnel.nom} retard={40} />
                <Ligne libelle="Prénoms" valeur={personnel.prenoms} retard={90} />
                <Ligne libelle="Matricule (IM)" valeur={personnel.im} retard={140} />
                <Ligne libelle="CIN" valeur={personnel.cin} retard={190} />
                <Ligne libelle="Sexe" valeur={personnel.sexe} retard={240} />
                <Ligne libelle="Date de naissance" valeur={dateLisible(personnel.date_naissance)} retard={290} />
              </Section>

              <Section icone="key" titre="Coordonnées et compte" description="Contact et accès à la plateforme" retard={80}>
                <Ligne libelle="Téléphone" valeur={personnel.telephone} retard={120} />
                <Ligne libelle="E-mail" valeur={personnel.email || utilisateur.email} retard={170} />
                <Ligne libelle="Identifiant" valeur={utilisateur.username} retard={220} />
                <Ligne libelle="Dernière connexion" valeur={dateLisible(utilisateur.last_login)} retard={270} />
              </Section>
            </div>
          )}

          {ongletActif === 'pro' && (
            <div
              key="pro"
              id="panneau-pro"
              role="tabpanel"
              aria-labelledby="onglet-pro"
              className="pr-panel mx-auto max-w-3xl"
            >
              <Section icone="building" titre="Affectations et carrière" description="Position administrative actuelle">
                <Ligne libelle="Direction" valeur={personnel.direction_libelle} retard={40} />
                <Ligne libelle="Service" valeur={personnel.service_libelle} retard={90} />
                <Ligne libelle="Corps" valeur={personnel.corps} retard={140} />
                <Ligne libelle="Grade" valeur={personnel.grade} retard={190} />
                <Ligne libelle="Statut" valeur={personnel.statut} retard={240} />
                <Ligne libelle="Matricule (IM)" valeur={personnel.im} retard={290} />
              </Section>
            </div>
          )}
        </div>

        <aside
          className="pr-rise mt-10 flex items-start gap-3 rounded-[20px] border border-[#E3E8EE] bg-white/70 px-4 py-3.5 text-xs leading-relaxed text-[#5B6B7C] shadow-[0_1px_2px_rgba(15,36,55,0.04)]"
          style={delai(500)}
        >
          <Icon name="shield" className="mt-0.5 h-4 w-4 shrink-0 text-[#00678F]" />
          <p>
            Ces informations proviennent du dossier enregistré dans le système MEN. Pour toute correction ou mise à
            jour, contactez le service des ressources humaines.
          </p>
        </aside>
      </div>
    </div>
  )
}

export default ProfilAgentPage