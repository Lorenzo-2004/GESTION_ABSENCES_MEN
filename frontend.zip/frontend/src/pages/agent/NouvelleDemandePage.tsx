import { useEffect, useRef, useState } from 'react'
import type { ChangeEvent, FormEvent, ReactNode } from 'react'
import { isAxiosError } from 'axios'
import { Link, Navigate, useSearchParams } from 'react-router'

import { useAuth } from '../../contexts/useAuth'
import {
  creerDemandeConge,
  type TypeAbsence,
} from '../../services/nouvelleDemandeService'
import {
  listerPersonnelsDuService,
  type PersonnelEquipe,
} from '../../services/chefServiceService'
import { Icon, Message, type IconName } from '../../components/men/ui'
import { delai } from '../../components/men/ui-outils'
import {
  CoquilleAgent,
  CoquilleService,
  type VueAgent,
} from '../../components/men/miseEnPageRH'

const TYPES_ABSENCE: { valeur: TypeAbsence; libelle: string }[] = [
  { valeur: 'CONGE_ANNUEL', libelle: 'Congé annuel' },
  { valeur: 'PERMISSION', libelle: "Permission d’absence" },
  { valeur: 'AUTORISATION', libelle: 'Autorisation / faveur' },
  { valeur: 'MISSION', libelle: 'Ordre de mission' },
  { valeur: 'MATERNITE', libelle: 'Congé de maternité' },
  { valeur: 'PATERNITE', libelle: 'Congé de paternité' },
  { valeur: 'REPOS_SANITAIRE', libelle: 'Repos sanitaire' },
]

const TYPES_MOTIF_OBLIGATOIRE: TypeAbsence[] = ['PERMISSION', 'AUTORISATION']
const TYPES_JUSTIFICATIF_OBLIGATOIRE: TypeAbsence[] = ['MISSION', 'REPOS_SANITAIRE', 'MATERNITE', 'PATERNITE']

const EXTENSIONS_AUTORISEES = ['.pdf', '.jpg', '.jpeg', '.png', '.tif', '.tiff']
const TAILLE_MAXIMALE = 5 * 1024 * 1024

/* ------------------------------------------------------------------ */
/*  Animations                                                         */
/* ------------------------------------------------------------------ */

const STYLES = `
@keyframes rh-in{from{opacity:0;transform:translate3d(0,14px,0)}to{opacity:1;transform:none}}
@keyframes rh-draw{from{stroke-dashoffset:1}to{stroke-dashoffset:0}}
@keyframes rh-bar{from{transform:scaleX(0)}to{transform:scaleX(1)}}
@keyframes rh-ring{from{stroke-dashoffset:var(--c)}to{stroke-dashoffset:var(--o)}}
@keyframes rh-pulse{0%{box-shadow:0 0 0 0 rgba(217,138,11,.45)}100%{box-shadow:0 0 0 7px rgba(217,138,11,0)}}
@keyframes rh-pop{0%{opacity:0;transform:scale(.92)}100%{opacity:1;transform:none}}
@keyframes rh-fade{from{opacity:0}to{opacity:1}}
@keyframes rh-orbit{to{transform:rotate(360deg)}}
@keyframes rh-sheen{from{transform:translateX(-120%)}to{transform:translateX(280%)}}

.rh-in{animation:rh-in .6s cubic-bezier(.22,1,.36,1) var(--d,0ms) backwards}
.rh-draw{stroke-dasharray:1;animation:rh-draw 1.5s cubic-bezier(.4,0,.2,1) var(--d,150ms) backwards}
.rh-bar{transform-origin:left center;animation:rh-bar .9s cubic-bezier(.22,1,.36,1) var(--d,0ms) backwards}
.rh-ring{animation:rh-ring 1.3s cubic-bezier(.22,1,.36,1) var(--d,300ms) backwards}
.rh-pulse{animation:rh-pulse 1.8s ease-out infinite}
.rh-pop{animation:rh-pop .45s cubic-bezier(.22,1,.36,1) backwards}
.rh-fade{animation:rh-fade .7s ease-out var(--d,0ms) backwards}
.rh-orbit{transform-origin:center;animation:rh-orbit 80s linear infinite}
.rh-sheen::after{content:"";position:absolute;inset:0;width:36%;pointer-events:none;
  background:linear-gradient(100deg,transparent,rgba(255,255,255,.18),transparent);
  animation:rh-sheen 1.5s cubic-bezier(.4,0,.2,1) var(--d,600ms) 1 backwards}

.men-serif{font-family:var(--font-serif,Georgia,'Times New Roman',serif);font-weight:500;letter-spacing:-.01em}

@media (prefers-reduced-motion:reduce){
  .rh-in,.rh-draw,.rh-bar,.rh-ring,.rh-pulse,.rh-pop,.rh-fade,.rh-orbit,.rh-sheen::after{animation:none!important}
  .rh-draw{stroke-dasharray:none}
}
`

/* ------------------------------------------------------------------ */
/*  Styles partagés                                                    */
/* ------------------------------------------------------------------ */

const carte =
  'rounded-[20px] border border-[#E3E8EE] bg-white shadow-[0_1px_2px_rgba(15,36,55,0.04),0_10px_28px_-18px_rgba(15,36,55,0.14)]'

const btnPrimaire =
  'inline-flex h-10 items-center justify-center gap-2 rounded-xl bg-[#00678F] px-4 text-sm font-semibold text-white shadow-[0_1px_2px_rgba(0,103,143,.3),0_8px_16px_-8px_rgba(0,103,143,.55)] transition duration-200 hover:bg-[#005A7D] active:scale-[.98] focus:outline-none focus-visible:ring-4 focus-visible:ring-[#00678F]/25 disabled:pointer-events-none disabled:opacity-60'

const btnContour =
  'inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-[#D5DCE5] bg-white px-4 text-sm font-semibold text-[#0F2437] transition duration-200 hover:border-[#C0CBD7] hover:bg-[#F3F6F9] active:scale-[.98] focus:outline-none focus-visible:ring-4 focus-visible:ring-[#00678F]/15 disabled:pointer-events-none disabled:opacity-60'

const champ =
  'h-11 w-full rounded-xl border border-[#D5DCE5] bg-white px-3.5 text-sm text-[#0F2437] outline-none transition duration-200 placeholder:text-[#94A3B8] hover:border-[#B8C4D1] focus:border-[#00678F] focus:ring-4 focus:ring-[#00678F]/15 disabled:bg-[#F3F5F8] disabled:text-[#94A3B8]'

const zoneTexte =
  'min-h-[100px] w-full resize-y rounded-xl border border-[#D5DCE5] bg-white px-3.5 py-2.5 text-sm text-[#0F2437] outline-none transition duration-200 placeholder:text-[#94A3B8] hover:border-[#B8C4D1] focus:border-[#00678F] focus:ring-4 focus:ring-[#00678F]/15'

const etiquette = 'mb-1.5 block text-sm font-medium text-[#0F2437]'

const TONS = {
  bleu: { chip: 'bg-[#00678F]/10 text-[#00678F]', barre: '#00678F' },
  vert: { chip: 'bg-[#518929]/10 text-[#3F6F1F]', barre: '#518929' },
  ardoise: { chip: 'bg-slate-500/10 text-[#475569]', barre: '#94A3B8' },
} as const

interface FormulaireDemande {
  type_absence: TypeAbsence
  motif: string
  date_debut: string
  date_fin: string
  lieu_jouissance: string
}

/* ------------------------------------------------------------------ */
/*  Utilitaires                                                        */
/* ------------------------------------------------------------------ */

function joursCalendaires(debut: string, fin: string): number | null {
  if (!debut || !fin) return null
  const dateDebut = new Date(`${debut}T00:00:00Z`).getTime()
  const dateFin = new Date(`${fin}T00:00:00Z`).getTime()
  if (Number.isNaN(dateDebut) || Number.isNaN(dateFin) || dateFin < dateDebut) return null
  return Math.floor((dateFin - dateDebut) / 86400000) + 1
}

function messageErreur(erreur: unknown): string {
  if (!isAxiosError(erreur)) return 'Une erreur inattendue est survenue.'
  const statutHTTP = erreur.response?.status
  const donnees = erreur.response?.data

  if (statutHTTP === 401) return 'Votre session a expiré. Reconnectez-vous avant de réessayer.'
  if (statutHTTP === 403) return 'Vous n’êtes pas autorisé à soumettre cette demande.'
  if (typeof donnees?.detail === 'string') return donnees.detail

  const erreurs = donnees?.erreurs
  if (erreurs && typeof erreurs === 'object') {
    const messages = Object.entries(erreurs as Record<string, unknown>).flatMap(([champErreur, valeur]) => {
      const liste = Array.isArray(valeur) ? valeur : [valeur]
      return liste.filter((item) => typeof item === 'string').map((item) => `${champErreur} : ${item}`)
    })
    if (messages.length > 0) return messages.join(' ')
  }

  if (!erreur.response) return 'Impossible de joindre le serveur. Vérifiez que Django fonctionne.'
  return 'La demande n’a pas pu être enregistrée. Vérifiez les informations saisies.'
}

function initialiserFormulaire(): FormulaireDemande {
  return { type_absence: 'CONGE_ANNUEL', motif: '', date_debut: '', date_fin: '', lieu_jouissance: '' }
}

/* ------------------------------------------------------------------ */
/*  Composants locaux                                                  */
/* ------------------------------------------------------------------ */

function CoquilleDemandeRole({
  estChefService, vueAgent, onVueAgent, titre, description, actions, children,
}: {
  estChefService: boolean; vueAgent: VueAgent; onVueAgent: (vue: VueAgent) => void; titre: string; description: string; actions: ReactNode; children: ReactNode
}) {
  if (estChefService) {
    return (
      <CoquilleService vue="nouvelle-demande" onVue={() => undefined} titre={titre} description={description} actions={actions}>
        {children}
      </CoquilleService>
    )
  }
  return (
    <CoquilleAgent vue={vueAgent} onVue={onVueAgent} titre={titre} description={description} actions={actions}>
      {children}
    </CoquilleAgent>
  )
}

function GroupeFormulaire({ icone, titre, ton = 'bleu', retard, children }: {
  icone: IconName
  titre: string
  ton?: keyof typeof TONS
  retard: number
  children: ReactNode
}) {
  return (
    <fieldset className={`rh-in min-w-0 overflow-hidden ${carte}`} style={delai(retard)}>
      <header className="flex items-center gap-3 border-b border-[#E3E8EE] bg-[#F8FAFC] px-5 py-3">
        <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg ${TONS[ton].chip}`}>
          <Icon name={icone} className="h-4 w-4" />
        </span>
        <span className="text-sm font-bold text-[#0F2437]">{titre}</span>
      </header>
      <div className="p-4 sm:p-5">{children}</div>
    </fieldset>
  )
}

function TuileKpi({ libelle, valeur, note, icone, accent, retard }: {
  libelle: string
  valeur: string
  note: string
  icone: IconName
  accent: string
  retard: number
}) {
  return (
    <div className={`rh-in flex flex-col p-5 sm:p-6 ${carte}`} style={delai(retard)}>
      <header className="mb-3 flex items-center gap-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl" style={{ backgroundColor: `${accent}1A`, color: accent }}>
          <Icon name={icone} className="h-5 w-5" />
        </span>
        <h2 className="text-sm font-bold text-[#0F2437]">{libelle}</h2>
      </header>
      <p className="men-serif text-4xl leading-none tabular-nums text-[#0F2437]">{valeur}</p>
      <p className="mt-2 text-xs text-[#5B6B7C]">{note}</p>
    </div>
  )
}

/* ================================================================== */
/*  Page                                                               */
/* ================================================================== */

export function NouvelleDemandePage() {
  const { utilisateur, chargement } = useAuth()
  const [searchParams] = useSearchParams()
  const personnelCibleId = Number(searchParams.get('personnel') || 0)
  const estChefService = utilisateur?.role === 'ROLE_CHEF_SERVICE'
  const serviceId = utilisateur?.personnel?.service ?? null
  const [vue, setVue] = useState<VueAgent>('nouvelle-demande')

  const [formulaire, setFormulaire] = useState<FormulaireDemande>(initialiserFormulaire)
  const [fichier, setFichier] = useState<File | null>(null)
  const [erreur, setErreur] = useState('')
  const [succes, setSucces] = useState('')
  const [envoiEnCours, setEnvoiEnCours] = useState(false)
  const [personnelCible, setPersonnelCible] = useState<PersonnelEquipe | null>(null)
  const [chargementPersonnelCible, setChargementPersonnelCible] = useState(false)

  const referenceFichier = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (!estChefService || personnelCibleId <= 0) {
      setPersonnelCible(null)
      setChargementPersonnelCible(false)
      return
    }
    if (serviceId === null) {
      setPersonnelCible(null)
      setChargementPersonnelCible(false)
      setErreur('Votre compte n’est associé à aucun service.')
      return
    }
    let actif = true
    setChargementPersonnelCible(true)
    setPersonnelCible(null)
    setErreur('')

    void listerPersonnelsDuService(serviceId)
      .then((personnels) => {
        if (!actif) return
        const cible = personnels.find((personnel) => personnel.id_personnel === personnelCibleId)
        if (!cible) {
          setPersonnelCible(null)
          setErreur('Ce personnel n’appartient pas à votre service ou n’est pas disponible.')
          return
        }
        setPersonnelCible(cible)
      })
      .catch((cause) => {
        if (actif) { setPersonnelCible(null); setErreur(messageErreur(cause)) }
      })
      .finally(() => { if (actif) setChargementPersonnelCible(false) })

    return () => { actif = false }
  }, [estChefService, personnelCibleId, serviceId])

  if (chargement) {
    return (
      <div className="grid min-h-screen place-items-center bg-[#F3F5F8]">
        <span role="status" aria-label="Chargement" className="h-7 w-7 animate-spin rounded-full border-[3px] border-[#00678F]/15 border-t-[#00678F]" />
      </div>
    )
  }

  if (!utilisateur) return <Navigate to="/connexion" replace />
  if (utilisateur.role !== 'ROLE_AGENT' && !estChefService) return <Navigate to="/app" replace />

  const demandePourUnAgent = estChefService && personnelCibleId > 0
  const nombreJours = joursCalendaires(formulaire.date_debut, formulaire.date_fin)
  const motifObligatoire = TYPES_MOTIF_OBLIGATOIRE.includes(formulaire.type_absence)
  const justificatifObligatoire = TYPES_JUSTIFICATIF_OBLIGATOIRE.includes(formulaire.type_absence)

  function modifierChamp<K extends keyof FormulaireDemande>(cle: K, valeur: FormulaireDemande[K]) {
    setFormulaire((precedent) => ({ ...precedent, [cle]: valeur }))
    setErreur('')
    setSucces('')
  }

  function selectionnerFichier(evenement: ChangeEvent<HTMLInputElement>) {
    const selection = evenement.target.files?.[0] ?? null
    setErreur('')
    setSucces('')
    if (!selection) { setFichier(null); return }

    const extension = selection.name.toLowerCase().slice(selection.name.lastIndexOf('.'))
    if (!EXTENSIONS_AUTORISEES.includes(extension)) {
      setFichier(null); evenement.target.value = ''
      setErreur('Formats autorisés : PDF, JPG, JPEG, PNG, TIF et TIFF.')
      return
    }
    if (selection.size > TAILLE_MAXIMALE) {
      setFichier(null); evenement.target.value = ''
      setErreur('Le justificatif ne doit pas dépasser 5 Mo.')
      return
    }
    setFichier(selection)
  }

  async function soumettre(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setErreur('')
    setSucces('')

    if (demandePourUnAgent && (chargementPersonnelCible || !personnelCible)) {
      setErreur('Vérifiez le personnel concerné avant d’enregistrer la demande.')
      return
    }
    if (!formulaire.date_debut || !formulaire.date_fin || nombreJoursInvalide()) {
      setErreur('Vérifiez les dates de début et de fin.')
      return
    }
    if (motifObligatoire && !formulaire.motif.trim()) {
      setErreur('Le motif est obligatoire pour ce type de demande.')
      return
    }
    if (justificatifObligatoire && !fichier) {
      setErreur('Un justificatif est obligatoire pour ce type d’absence.')
      return
    }

    setEnvoiEnCours(true)
    try {
      const resultat = await creerDemandeConge({
        ...formulaire,
        ...(demandePourUnAgent && personnelCible ? { personnel: personnelCible.id_personnel } : {}),
        motif: formulaire.motif.trim(),
        lieu_jouissance: formulaire.lieu_jouissance.trim(),
        fichier_justificatif: fichier,
      })

      const reference = resultat.numero_enregistrement || `Demande #${resultat.id_demande}`
      const sujetDemande = demandePourUnAgent && personnelCible ? `La demande pour ${personnelCible.nom_complet}` : 'Votre demande'
      setSucces(`${sujetDemande} ${reference} a été enregistrée. Statut : ${resultat.statut_libelle || 'En attente'}.`)

      setFormulaire(initialiserFormulaire())
      setFichier(null)
      if (referenceFichier.current) referenceFichier.current.value = ''
    } catch (cause) {
      setErreur(messageErreur(cause))
    } finally {
      setEnvoiEnCours(false)
    }
  }

  function nombreJoursInvalide(): boolean {
    if (!formulaire.date_debut || !formulaire.date_fin) return true
    const debut = new Date(`${formulaire.date_debut}T00:00:00Z`)
    const fin = new Date(`${formulaire.date_fin}T00:00:00Z`)
    return Number.isNaN(debut.getTime()) || Number.isNaN(fin.getTime()) || fin < debut
  }

  return (
    <CoquilleDemandeRole
      estChefService={estChefService}
      vueAgent={vue}
      onVueAgent={setVue}
      titre={
        estChefService
          ? demandePourUnAgent && personnelCible
            ? `Demande pour ${personnelCible.nom_complet}`
            : 'Nouvelle demande'
          : 'Nouvelle demande de congé'
      }
      description={
        estChefService
          ? demandePourUnAgent
            ? 'Saisie d’une demande pour un membre de votre service'
            : 'Demande personnelle transmise directement à la direction'
          : 'Remplissez le formulaire officiel de demande d’absence'
      }
      actions={
        <Link to={estChefService ? '/app/chef-service' : '/app/agent/mes-demandes'} className={`${btnContour} !h-9`}>
          <Icon name="left" className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">{estChefService ? 'Retour au service' : 'Mes demandes'}</span>
        </Link>
      }
    >
      <style>{STYLES}</style>

      <div className="mx-auto max-w-4xl space-y-5">
        {erreur && <Message key={erreur} type="erreur" onClose={() => setErreur('')}><span className="text-xs">{erreur}</span></Message>}
        {succes && (
          <Message key={succes} type="succes" onClose={() => setSucces('')}>
            <span className="text-xs">{succes}</span>
            <Link to={estChefService ? '/app/chef-service/planning' : '/app/agent/mes-demandes'} className="mt-2 flex items-center gap-1 text-xs font-semibold underline">
              <Icon name="right" className="h-3 w-3" />
              {estChefService ? 'Consulter le planning' : 'Mes demandes'}
            </Link>
          </Message>
        )}

        <div className="grid min-w-0 gap-4 lg:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)]">
          <section className="rh-in rh-sheen relative min-w-0 overflow-hidden rounded-[24px] bg-gradient-to-br from-[#0A3D5C] via-[#0A5378] to-[#00678F] p-6 text-white shadow-[0_20px_38px_-20px_rgba(10,61,92,.75)] sm:p-8">
            <svg aria-hidden="true" viewBox="0 0 400 400" className="pointer-events-none absolute -right-24 -top-28 h-[420px] w-[420px] text-white">
              <g className="rh-orbit" fill="none" stroke="currentColor" strokeLinecap="round">
                <circle cx="200" cy="200" r="190" strokeOpacity=".07" />
                <circle cx="200" cy="200" r="150" strokeOpacity=".09" strokeDasharray="2 10" />
                <circle cx="200" cy="200" r="110" strokeOpacity=".12" />
                <path d="M200 10 A190 190 0 0 1 390 200" strokeOpacity=".28" strokeWidth="2" />
                <path d="M200 90 A110 110 0 0 1 310 200" strokeOpacity=".22" strokeWidth="2" />
              </g>
            </svg>
            <div aria-hidden="true" className="pointer-events-none absolute inset-0 opacity-[0.05] [background-image:linear-gradient(white_1px,transparent_1px),linear-gradient(90deg,white_1px,transparent_1px)] [background-size:36px_36px]" />

            <div className="relative flex h-full min-w-0 flex-col">
              <p className="inline-flex w-fit items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-medium text-white/90 backdrop-blur-sm">
                <Icon name="file" className="h-3.5 w-3.5" />
                {estChefService ? 'Espace Chef de service' : 'Espace Agent'}
              </p>
              <h2 className="men-serif mt-5 max-w-lg text-3xl font-normal leading-[1.1] sm:text-4xl">
                {demandePourUnAgent && personnelCible ? `Demande pour ${personnelCible.nom_complet}` : 'Nouvelle demande de congé'}
              </h2>
              <p className="mt-4 max-w-md text-sm leading-relaxed text-white/75">
                {demandePourUnAgent
                  ? 'Préparez la demande d’absence pour le personnel sélectionné.'
                  : estChefService
                    ? 'Votre demande personnelle sera transmise directement au Directeur.'
                    : 'Renseignez les informations utiles puis soumettez la demande.'}
              </p>
            </div>
          </section>

          <TuileKpi
            libelle="Durée estimée"
            valeur={nombreJours === null ? '—' : String(nombreJours)}
            note={nombreJours === null ? 'Complétez les dates' : `jour${nombreJours > 1 ? 's' : ''} calendaires`}
            icone="calendar"
            accent="#00678F"
            retard={120}
          />
        </div>

        {demandePourUnAgent && (
          <section className={`rh-in overflow-hidden ${carte}`} style={delai(180)}>
            <header className="flex items-center gap-3 border-b border-[#E3E8EE] bg-[#F8FAFC] px-5 py-3">
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-[#00678F]/10 text-[#00678F]">
                <Icon name="user" className="h-4 w-4" />
              </span>
              <span className="text-sm font-bold text-[#0F2437]">Personnel concerné</span>
            </header>
            <div className="flex items-center gap-3 p-4">
              {chargementPersonnelCible ? (
                <p role="status" className="text-xs font-medium text-[#5B6B7C]">Chargement du personnel…</p>
              ) : personnelCible ? (
                <>
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[#00678F]/10 text-xs font-bold text-[#00678F]">
                    {personnelCible.nom_complet?.split(/\s+/).slice(0, 2).map((m) => m[0]?.toUpperCase()).join('') || '?'}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-[#0F2437]">{personnelCible.nom_complet}</p>
                    <p className="mt-0.5 text-xs text-[#5B6B7C]">IM : {personnelCible.im} · {personnelCible.service_libelle || 'Votre service'}</p>
                  </div>
                </>
              ) : (
                <p role="alert" className="text-xs font-semibold text-rose-600">Le personnel ne peut pas être chargé.</p>
              )}
            </div>
          </section>
        )}

        <form onSubmit={soumettre} className="space-y-4">
          <GroupeFormulaire icone="calendar" titre="Type et dates" ton="bleu" retard={240}>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div className="group md:col-span-2">
                <label htmlFor="type_absence" className={etiquette}>Type d’absence *</label>
                <select
                  id="type_absence"
                  required
                  value={formulaire.type_absence}
                  onChange={(event) => modifierChamp('type_absence', event.target.value as TypeAbsence)}
                  className={champ}
                >
                  {TYPES_ABSENCE.map((type) => (
                    <option key={type.valeur} value={type.valeur}>{type.libelle}</option>
                  ))}
                </select>
              </div>

              <div className="group">
                <label htmlFor="date_debut" className={etiquette}>Date de début *</label>
                <input
                  id="date_debut"
                  type="date"
                  required
                  value={formulaire.date_debut}
                  onChange={(event) => modifierChamp('date_debut', event.target.value)}
                  className={champ}
                />
              </div>

              <div className="group">
                <label htmlFor="date_fin" className={etiquette}>Date de fin *</label>
                <input
                  id="date_fin"
                  type="date"
                  required
                  min={formulaire.date_debut || undefined}
                  value={formulaire.date_fin}
                  onChange={(event) => modifierChamp('date_fin', event.target.value)}
                  className={champ}
                />
              </div>

              <div className="flex items-center justify-between rounded-xl border border-[#E3E8EE] bg-[#F7F9FB] px-4 py-3 md:col-span-2">
                <p className="text-xs font-medium text-[#5B6B7C]">Durée estimée</p>
                <p className="text-sm font-semibold text-[#00678F]">
                  {nombreJours === null ? '—' : `${nombreJours} jour${nombreJours > 1 ? 's' : ''}`}
                </p>
              </div>
            </div>
          </GroupeFormulaire>

          <GroupeFormulaire icone="list" titre="Motif et lieu" ton="vert" retard={300}>
            <div className="grid grid-cols-1 gap-4">
              <div className="group">
                <label htmlFor="motif" className={etiquette}>
                  Motif {motifObligatoire ? '*' : <span className="text-[#94A3B8]">(facultatif)</span>}
                </label>
                <textarea
                  id="motif"
                  rows={4}
                  required={motifObligatoire}
                  value={formulaire.motif}
                  onChange={(event) => modifierChamp('motif', event.target.value)}
                  placeholder={motifObligatoire ? 'Expliquez le motif de votre demande…' : 'Précisions complémentaires…'}
                  className={zoneTexte}
                />
                {motifObligatoire && (
                  <p className="mt-1.5 text-xs font-medium text-[#3F6F1F]">Obligatoire pour une permission ou une autorisation.</p>
                )}
              </div>

              <div className="group">
                <label htmlFor="lieu_jouissance" className={etiquette}>Lieu de jouissance</label>
                <input
                  id="lieu_jouissance"
                  type="text"
                  maxLength={200}
                  value={formulaire.lieu_jouissance}
                  onChange={(event) => modifierChamp('lieu_jouissance', event.target.value)}
                  placeholder="Lieu où le congé sera passé, si applicable"
                  className={champ}
                />
              </div>
            </div>
          </GroupeFormulaire>

          <GroupeFormulaire icone="upload" titre="Justificatif" ton="ardoise" retard={360}>
            <div className="group">
              <label htmlFor="fichier_justificatif" className={etiquette}>
                Fichier joint {justificatifObligatoire ? '*' : <span className="text-[#94A3B8]">(facultatif)</span>}
              </label>
              <input
                ref={referenceFichier}
                id="fichier_justificatif"
                type="file"
                accept=".pdf,.jpg,.jpeg,.png,.tif,.tiff"
                required={justificatifObligatoire}
                onChange={selectionnerFichier}
                className="block w-full cursor-pointer rounded-xl border border-[#D5DCE5] bg-white px-3 py-2 text-sm text-[#0F2437] file:mr-3 file:rounded-lg file:border-0 file:bg-[#00678F]/10 file:px-3 file:py-1.5 file:text-xs file:font-semibold file:text-[#00678F] file:transition hover:file:bg-[#00678F]/20 focus:outline-none focus-visible:ring-4 focus-visible:ring-[#00678F]/15"
              />
              <p className="mt-1.5 text-xs font-medium text-[#5B6B7C]">
                Formats acceptés : PDF, JPG, PNG, TIF · 5 Mo max.
              </p>

              {fichier && (
                <div className="rh-pop mt-3 flex items-center gap-2 rounded-xl border border-[#DCE9D2] bg-[#F5F9F1] px-3 py-2 text-xs font-semibold text-[#3F6F1F]">
                  <Icon name="check" className="h-4 w-4 shrink-0" />
                  <span className="break-all">{fichier.name}</span>
                </div>
              )}
            </div>
          </GroupeFormulaire>

          <div className="rh-in flex flex-col-reverse items-center gap-3 pt-4 sm:flex-row sm:justify-end" style={delai(420)}>
            <Link to={estChefService ? '/app/chef-service' : '/app/agent/mes-demandes'} className={`${btnContour} w-full sm:w-auto`}>
              <Icon name="close" className="h-4 w-4" /> Annuler
            </Link>
            <button
              type="submit"
              disabled={envoiEnCours || chargementPersonnelCible || (demandePourUnAgent && !personnelCible)}
              className={`${btnPrimaire} w-full sm:w-auto`}
            >
              {envoiEnCours ? <Icon name="loader" className="h-4 w-4 animate-spin" /> : <Icon name="check" className="h-4 w-4" />}
              {envoiEnCours ? 'Envoi en cours…' : demandePourUnAgent ? 'Soumettre pour l’agent' : 'Soumettre la demande'}
            </button>
          </div>
        </form>
      </div>
    </CoquilleDemandeRole>
  )
}

export default NouvelleDemandePage