import { isAxiosError } from 'axios'
import {
  useCallback,
  useEffect,
  useMemo,
  useState,
  type FormEvent,
  type ReactNode,
} from 'react'
import { Navigate } from 'react-router'

import { useAuth } from '../../contexts/useAuth'
import {
  enregistrerAvisDirecteur,
  listerDemandesEnAttenteDirection,
  type AvisDirecteur,
  type DemandeDirection,
  type ValidationDemande,
} from '../../services/directeurService'
import { Icon, Message, type IconName } from '../../components/men/ui'
import { delai, useCompteur } from '../../components/men/ui-outils'
import {
  CoquilleDirecteur,
  Tiroir,
  type VueDirecteur,
} from '../../components/men/miseEnPageRH'

const TITRES_VUES: Record<VueDirecteur, { titre: string; description: string }> = {
  apercu: { titre: 'Vue d’ensemble', description: 'Suivi des validations de la direction' },
  demandes: { titre: 'Décisions à rendre', description: 'Demandes qui attendent votre avis définitif' },
}

/* ------------------------------------------------------------------ */
/*  Animations                                                         */
/* ------------------------------------------------------------------ */

const STYLES = `
@keyframes rh-in{from{opacity:0;transform:translate3d(0,14px,0)}to{opacity:1;transform:none}}
@keyframes rh-draw{from{stroke-dashoffset:1}to{stroke-dashoffset:0}}
@keyframes rh-bar{from{transform:scaleX(0)}to{transform:scaleX(1)}}
@keyframes rh-ring{from{stroke-dashoffset:var(--c)}to{stroke-dashoffset:var(--o)}}
@keyframes rh-pulse{0%{box-shadow:0 0 0 0 rgba(217,138,11,.45)}100%{box-shadow:0 0 0 7px rgba(217,138,11,0)}}
@keyframes rh-pop{0%{opacity:0;transform:scale(.92)}100%{opacity:1;transform:none}}
@keyframes rh-fade{from{opacity:0}to{opacity:1}}
@keyframes rh-orbit{to{transform:rotate(360deg)}}
@keyframes rh-sheen{from{transform:translateX(-120%)}to{transform:translateX(280%)}}

.rh-in{animation:rh-in .6s cubic-bezier(.22,1,.36,1) var(--d,0ms) backwards}
.rh-draw{stroke-dasharray:1;animation:rh-draw 1.5s cubic-bezier(.4,0,.2,1) var(--d,150ms) backwards}
.rh-bar{transform-origin:left center;animation:rh-bar .9s cubic-bezier(.22,1,.36,1) var(--d,0ms) backwards}
.rh-ring{animation:rh-ring 1.3s cubic-bezier(.22,1,.36,1) var(--d,300ms) backwards}
.rh-pulse{animation:rh-pulse 1.8s ease-out infinite}
.rh-pop{animation:rh-pop .45s cubic-bezier(.22,1,.36,1) backwards}
.rh-fade{animation:rh-fade .7s ease-out var(--d,0ms) backwards}
.rh-orbit{transform-origin:center;animation:rh-orbit 80s linear infinite}
.rh-sheen::after{content:"";position:absolute;inset:0;width:36%;pointer-events:none;
  background:linear-gradient(100deg,transparent,rgba(255,255,255,.18),transparent);
  animation:rh-sheen 1.5s cubic-bezier(.4,0,.2,1) var(--d,600ms) 1 backwards}

.men-serif{font-family:var(--font-serif,Georgia,'Times New Roman',serif);font-weight:500;letter-spacing:-.01em}

@media (prefers-reduced-motion:reduce){
  .rh-in,.rh-draw,.rh-bar,.rh-ring,.rh-pulse,.rh-pop,.rh-fade,.rh-orbit,.rh-sheen::after{animation:none!important}
  .rh-draw{stroke-dasharray:none}
}
`

/* ------------------------------------------------------------------ */
/*  Styles partagés                                                    */
/* ------------------------------------------------------------------ */

const carte =
  'rounded-[20px] border border-[#E3E8EE] bg-white shadow-[0_1px_2px_rgba(15,36,55,0.04),0_10px_28px_-18px_rgba(15,36,55,0.14)]'

const btnPrimaire =
  'inline-flex h-10 items-center justify-center gap-2 rounded-xl bg-[#00678F] px-4 text-sm font-semibold text-white shadow-[0_1px_2px_rgba(0,103,143,.3),0_8px_16px_-8px_rgba(0,103,143,.55)] transition duration-200 hover:bg-[#005A7D] active:scale-[.98] focus:outline-none focus-visible:ring-4 focus-visible:ring-[#00678F]/25 disabled:pointer-events-none disabled:opacity-60'

const btnContour =
  'inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-[#D5DCE5] bg-white px-4 text-sm font-semibold text-[#0F2437] transition duration-200 hover:border-[#C0CBD7] hover:bg-[#F3F6F9] active:scale-[.98] focus:outline-none focus-visible:ring-4 focus-visible:ring-[#00678F]/15 disabled:pointer-events-none disabled:opacity-60'

const btnIcone =
  'grid h-9 w-9 place-items-center rounded-lg text-[#5B6B7C] transition-colors hover:bg-[#00678F]/10 hover:text-[#00678F] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00678F]/40 disabled:opacity-50'

const champ =
  'h-11 w-full rounded-xl border border-[#D5DCE5] bg-white px-3.5 text-sm text-[#0F2437] outline-none transition duration-200 placeholder:text-[#94A3B8] hover:border-[#B8C4D1] focus:border-[#00678F] focus:ring-4 focus:ring-[#00678F]/15 disabled:bg-[#F3F5F8] disabled:text-[#94A3B8]'

const zoneTexte =
  'min-h-[100px] w-full resize-y rounded-xl border border-[#D5DCE5] bg-white px-3.5 py-2.5 text-sm text-[#0F2437] outline-none transition duration-200 placeholder:text-[#94A3B8] hover:border-[#B8C4D1] focus:border-[#00678F] focus:ring-4 focus:ring-[#00678F]/15'

const TONS_KPI = {
  bleu: {
    fond: 'from-[#0A5378] via-[#00678F] to-[#0A82B9]',
    ombre: 'shadow-[0_22px_38px_-22px_rgba(0,103,143,.8)]',
  },
  vert: {
    fond: 'from-[#2F6A1A] via-[#3F7D20] to-[#5B9A33]',
    ombre: 'shadow-[0_22px_38px_-22px_rgba(63,125,32,.8)]',
  },
  ambre: {
    fond: 'from-[#9A4A0A] via-[#B45309] to-[#D97706]',
    ombre: 'shadow-[0_22px_38px_-22px_rgba(180,83,9,.8)]',
  },
} as const

const AVATARS = [
  'bg-[#00678F]/10 text-[#00678F]',
  'bg-[#518929]/10 text-[#3F6F1F]',
  'bg-slate-500/10 text-slate-700',
  'bg-[#0A3D5C]/10 text-[#0A3D5C]',
  'bg-amber-500/10 text-amber-800',
]

/* ------------------------------------------------------------------ */
/*  Utilitaires                                                        */
/* ------------------------------------------------------------------ */

function dateLisible(date?: string | null): string {
  if (!date) return '—'
  const valeur = new Date(`${date.slice(0, 10)}T12:00:00`)
  if (Number.isNaN(valeur.getTime())) return '—'
  return new Intl.DateTimeFormat('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' }).format(valeur)
}

function nomPersonnel(demande: DemandeDirection): string {
  const personnel = demande.personnel_detail
  if (personnel?.nom_complet) return personnel.nom_complet
  const nom = `${personnel?.prenoms ?? ''} ${personnel?.nom ?? ''}`.trim()
  return nom || `Personnel #${demande.personnel}`
}

function initiales(nom: string): string {
  const lettres = nom.split(/\s+/).filter(Boolean).slice(0, 2).map((m) => m[0]?.toUpperCase()).join('')
  return lettres || '?'
}

function teinteAvatar(nom: string): string {
  const somme = [...nom].reduce((total, c) => total + c.charCodeAt(0), 0)
  return AVATARS[somme % AVATARS.length]
}

function messageErreur(erreur: unknown): string {
  if (isAxiosError(erreur)) {
    if (erreur.response?.status === 401) return 'Votre session a expiré. Veuillez vous reconnecter.'
    if (erreur.response?.status === 403) return 'Vous ne disposez pas des autorisations nécessaires.'
    if (!erreur.response) return 'Le serveur est injoignable. Vérifiez votre connexion.'

    const data = erreur.response.data as
      | { detail?: unknown; observation?: unknown; avis?: unknown; non_field_errors?: unknown }
      | undefined

    for (const cle of ['detail', 'observation', 'avis', 'non_field_errors'] as const) {
      const valeur = data?.[cle]
      if (typeof valeur === 'string' && valeur.trim()) return valeur
      if (Array.isArray(valeur)) {
        const texte = valeur.filter((v) => typeof v === 'string').join(' ')
        if (texte) return texte
      }
    }
    if (erreur.response.status === 400) return 'La demande ne peut pas être traitée. Vérifiez son état.'
  }
  return 'Une erreur inattendue est survenue.'
}

function classeStatut(statut: string): string {
  switch (statut) {
    case 'EN_ATTENTE': return 'bg-amber-500/10 text-amber-700'
    case 'APPROUVE_CS': return 'bg-[#0A82B9]/10 text-[#0A82B9]'
    case 'VALIDE_DIR': return 'bg-[#518929]/10 text-[#3F6F1F]'
    case 'REJETE': return 'bg-rose-500/10 text-rose-700'
    default: return 'bg-slate-500/10 text-[#475569]'
  }
}

function libelleStatut(statut: string): string {
  switch (statut) {
    case 'APPROUVE_CS': return 'Visa chef'
    case 'EN_ATTENTE': return 'En attente'
    case 'VALIDE_DIR': return 'Validée'
    case 'REJETE': return 'Rejetée'
    default: return statut.replaceAll('_', ' ')
  }
}

/* ------------------------------------------------------------------ */
/*  Composants locaux                                                  */
/* ------------------------------------------------------------------ */

function Avatar({ nom, className = 'h-10 w-10 text-xs' }: { nom: string; className?: string }) {
  return (
    <span aria-hidden="true" className={`grid shrink-0 place-items-center rounded-full font-bold ring-1 ring-inset ring-black/5 ${teinteAvatar(nom)} ${className}`}>
      {initiales(nom)}
    </span>
  )
}

function BadgeStatut({ statut }: { statut: string }) {
  return (
    <span className={`inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-semibold ${classeStatut(statut)}`}>
      <span className={`h-2 w-2 rounded-full ${statut === 'VALIDE_DIR' ? 'bg-[#518929]' : statut === 'REJETE' ? 'bg-rose-500' : statut === 'APPROUVE_CS' ? 'bg-[#0A82B9]' : 'rh-pulse bg-amber-500'}`} />
      {libelleStatut(statut)}
    </span>
  )
}

function TuileKpi({ libelle, valeur, note, part, icone, ton, retard }: {
  libelle: string
  valeur: number
  note: string
  part: number
  icone: IconName
  ton: keyof typeof TONS_KPI
  retard: number
}) {
  const affiche = useCompteur(valeur)
  const s = TONS_KPI[ton]
  const pct = Math.min(100, Math.max(0, part))

  return (
    <div
      className={`rh-in rh-sheen relative overflow-hidden rounded-[20px] bg-gradient-to-br p-4 text-white sm:p-5 ${s.fond} ${s.ombre}`}
      style={{ ...delai(retard), '--d': `${retard}ms` } as React.CSSProperties}
    >
      <svg aria-hidden="true" viewBox="0 0 200 200" className="pointer-events-none absolute -right-10 -top-12 h-40 w-40 text-white">
        <g className="rh-orbit" fill="none" stroke="currentColor">
          <circle cx="100" cy="100" r="90" strokeOpacity=".12" />
          <circle cx="100" cy="100" r="64" strokeOpacity=".16" strokeDasharray="2 8" />
          <path d="M100 10 A90 90 0 0 1 190 100" strokeOpacity=".4" strokeWidth="2" strokeLinecap="round" />
        </g>
      </svg>

      <div className="relative flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-semibold text-white/85">{libelle}</p>
          <p className="men-serif mt-1.5 text-4xl leading-none tabular-nums">{affiche}</p>
        </div>
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-white/15 ring-1 ring-inset ring-white/25 backdrop-blur-sm">
          <Icon name={icone} className="h-4 w-4" />
        </span>
      </div>

      <div className="relative mt-4">
        <div className="mb-1 flex items-baseline justify-between text-[11px] text-white/85">
          <span>{note}</span>
          <span className="font-bold tabular-nums text-white">{Math.round(pct)}%</span>
        </div>
        <div className="h-1 overflow-hidden rounded-full bg-white/20">
          <div className="rh-bar h-full rounded-full bg-white" style={{ width: `${pct}%`, ...delai(retard + 350) }} />
        </div>
      </div>
    </div>
  )
}

function Panneau({ titre, sousTitre, icone, accent, retard, children }: {
  titre: string
  sousTitre?: string
  icone: IconName
  accent: string
  retard: number
  children: ReactNode
}) {
  return (
    <section className={`rh-in relative flex min-w-0 flex-col overflow-hidden p-5 sm:p-6 ${carte}`} style={delai(retard)}>
      {/* Ligne d'accent supprimée */}
      <header className="mb-5 flex items-center gap-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl" style={{ backgroundColor: `${accent}1A`, color: accent }}>
          <Icon name={icone} className="h-5 w-5" />
        </span>
        <div className="min-w-0">
          <h2 className="text-base font-bold text-[#0F2437]">{titre}</h2>
          {sousTitre && <p className="text-xs text-[#5B6B7C]">{sousTitre}</p>}
        </div>
      </header>
      <div className="flex flex-1 flex-col justify-center">{children}</div>
    </section>
  )
}

function Anneau({ ratio, centre, taille = 120, epaisseur = 12, couleur = '#518929' }: {
  ratio: number
  centre: ReactNode
  taille?: number
  epaisseur?: number
  couleur?: string
}) {
  const r = (taille - epaisseur) / 2
  const c = 2 * Math.PI * r
  const o = c * (1 - Math.min(Math.max(ratio, 0), 1))
  return (
    <div className="relative shrink-0" style={{ width: taille, height: taille }}>
      <svg width={taille} height={taille} viewBox={`0 0 ${taille} ${taille}`} className="-rotate-90" role="img" aria-label={`Taux : ${Math.round(ratio * 100)} %`}>
        <circle cx={taille / 2} cy={taille / 2} r={r} fill="none" stroke="#EAEFF4" strokeWidth={epaisseur} />
        <circle className="rh-ring" cx={taille / 2} cy={taille / 2} r={r} fill="none" stroke={couleur} strokeWidth={epaisseur} strokeLinecap="round" strokeDasharray={c} strokeDashoffset={o} style={{ '--c': c, '--o': o } as React.CSSProperties} />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">{centre}</div>
    </div>
  )
}

function HistoriqueAvis({ validations }: { validations: ValidationDemande[] }) {
  if (validations.length === 0) {
    return <p className="rounded-xl border border-[#E3E8EE] bg-[#F7F9FB] px-4 py-4 text-sm text-[#5B6B7C]">Aucun avis enregistré pour le moment.</p>
  }
  return (
    <ol className="space-y-3 border-l-2 border-[#E3E8EE] pl-4">
      {validations.map((validation) => (
        <li key={validation.id_validation} className="relative">
          <span className="absolute -left-[22px] top-3 grid h-3 w-3 place-items-center rounded-full bg-[#00678F] shadow-sm" />
          <div className="rounded-xl border border-[#E3E8EE] bg-white p-3.5">
            <p className="text-sm font-semibold text-[#0F2437]">
              {validation.niveau_libelle || validation.niveau} · {validation.avis_libelle || validation.avis}
            </p>
            {validation.observation && (
              <p className="mt-1.5 whitespace-pre-wrap rounded-md bg-[#F3F5F8] p-2.5 text-xs leading-5 text-[#3B4864]">{validation.observation}</p>
            )}
            <p className="mt-2 text-xs text-[#94A3B8]">{dateLisible(validation.date_action)}</p>
          </div>
        </li>
      ))}
    </ol>
  )
}

/* ================================================================== */
/*  Page                                                               */
/* ================================================================== */

export function DashboardDirecteurPage() {
  const { utilisateur, chargement } = useAuth()
  const [vue, setVue] = useState<VueDirecteur>('apercu')

  const [demandes, setDemandes] = useState<DemandeDirection[]>([])
  const [recherche, setRecherche] = useState('')
  const [chargementDonnees, setChargementDonnees] = useState(true)
  const [erreur, setErreur] = useState('')

  const [tiroirOuvert, setTiroirOuvert] = useState(false)
  const [selection, setSelection] = useState<number | null>(null)
  const [avis, setAvis] = useState<AvisDirecteur>('FAVORABLE')
  const [observation, setObservation] = useState('')
  const [erreurAction, setErreurAction] = useState('')
  const [messageSucces, setMessageSucces] = useState('')
  const [enregistrement, setEnregistrement] = useState(false)

  const chargerDemandes = useCallback(async () => {
    setChargementDonnees(true)
    setErreur('')
    try {
      const resultats = await listerDemandesEnAttenteDirection()
      setDemandes(resultats)
      setSelection((precedente) =>
        precedente !== null && resultats.some((d) => d.id_demande === precedente)
          ? precedente
          : resultats[0]?.id_demande ?? null,
      )
    } catch (cause) {
      setErreur(messageErreur(cause))
    } finally {
      setChargementDonnees(false)
    }
  }, [])

  useEffect(() => {
    if (chargement || !utilisateur || utilisateur.role !== 'ROLE_DIRECTEUR') return
    void chargerDemandes()
  }, [chargement, utilisateur, chargerDemandes])

  const demandesFiltrees = useMemo(() => {
    const terme = recherche.trim().toLocaleLowerCase('fr')
    if (!terme) return demandes
    return demandes.filter((demande) => {
      const nomDemandeur = nomPersonnel(demande).toLocaleLowerCase('fr')
      const numero = demande.numero_enregistrement?.toLocaleLowerCase('fr') ?? ''
      const type = demande.type_absence_libelle.toLocaleLowerCase('fr')
      const motif = demande.motif.toLocaleLowerCase('fr')
      return (
        nomDemandeur.includes(terme) ||
        numero.includes(terme) ||
        type.includes(terme) ||
        motif.includes(terme) ||
        String(demande.personnel).includes(terme)
      )
    })
  }, [demandes, recherche])

  const demandeSelectionnee = demandes.find((demande) => demande.id_demande === selection) ?? null

  function ouvrirTiroir(demande: DemandeDirection) {
    setSelection(demande.id_demande)
    setAvis('FAVORABLE')
    setObservation('')
    setErreurAction('')
    setTiroirOuvert(true)
  }

  async function traiterDemande() {
    if (!demandeSelectionnee || enregistrement) return
    setEnregistrement(true)
    setErreurAction('')
    setMessageSucces('')
    try {
      await enregistrerAvisDirecteur(demandeSelectionnee.id_demande, avis, observation)
      setMessageSucces(avis === 'FAVORABLE' ? 'La demande a été validée par la direction.' : 'La demande a été rejetée.')
      setTiroirOuvert(false)
      setObservation('')
      await chargerDemandes()
    } catch (cause) {
      setErreurAction(messageErreur(cause))
    } finally {
      setEnregistrement(false)
    }
  }

  if (chargement) {
    return (
      <div className="grid min-h-screen place-items-center bg-[#F3F5F8]">
        <span role="status" aria-label="Chargement" className="h-7 w-7 animate-spin rounded-full border-[3px] border-[#00678F]/15 border-t-[#00678F]" />
      </div>
    )
  }

  if (!utilisateur) return <Navigate to="/connexion" replace />
  if (utilisateur.role !== 'ROLE_DIRECTEUR') return <Navigate to="/app" replace />

  const nom = utilisateur.personnel?.nom_complet || `${utilisateur.personnel?.prenoms ?? ''} ${utilisateur.personnel?.nom ?? ''}`.trim()
  const direction = utilisateur.personnel?.direction_libelle || 'Direction'
  const valeurStat = (valeur: number) => (chargementDonnees ? 0 : valeur)
  const nombreAvecVisaChef = demandes.filter((d) => d.statut_demande === 'APPROUVE_CS').length
  const nombreDeposeesDirectement = demandes.filter((d) => d.statut_demande === 'EN_ATTENTE').length
  const total = demandes.length
  const part = (n: number) => (total ? (n / total) * 100 : 0)
  const ratioVisaChef = total ? nombreAvecVisaChef / total : 0
  const pourcentageAffiche = useCompteur(Math.round(ratioVisaChef * 100))

  return (
    <CoquilleDirecteur
      vue={vue}
      onVue={setVue}
      badges={{ demandes: demandes.length }}
      titre={TITRES_VUES[vue].titre}
      description={TITRES_VUES[vue].description}
      actions={
        <button
          type="button"
          onClick={() => { setMessageSucces(''); void chargerDemandes() }}
          disabled={chargementDonnees}
          aria-label="Actualiser"
          title="Actualiser"
          className={`${btnContour} !px-3 !h-9`}
        >
          <Icon name="refresh" className={`h-4 w-4 ${chargementDonnees ? 'animate-spin' : ''}`} />
        </button>
      }
    >
      <style>{STYLES}</style>

      {!tiroirOuvert && messageSucces && (
        <Message type="succes" onClose={() => setMessageSucces('')}>{messageSucces}</Message>
      )}
      {!tiroirOuvert && erreur && (
        <Message type="erreur" onClose={() => setErreur('')}>
          {erreur}
          <button type="button" onClick={() => void chargerDemandes()} className="mt-2 block text-sm font-semibold underline-offset-2">Réessayer</button>
        </Message>
      )}

      {vue === 'apercu' && (
        <>
          {/* Bandeau d'accueil - Ajusté */}
          <div className="grid min-w-0 gap-4 lg:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)]">
            <section className="rh-in rh-sheen relative min-w-0 overflow-hidden rounded-[24px] bg-gradient-to-br from-[#0A3D5C] via-[#0A5378] to-[#00678F] p-5 text-white shadow-[0_28px_48px_-28px_rgba(10,61,92,.75)] sm:p-6">
              <svg aria-hidden="true" viewBox="0 0 400 400" className="pointer-events-none absolute -right-20 -top-24 h-[360px] w-[360px] text-white">
                <g className="rh-orbit" fill="none" stroke="currentColor" strokeLinecap="round">
                  <circle cx="200" cy="200" r="190" strokeOpacity=".07" />
                  <circle cx="200" cy="200" r="150" strokeOpacity=".09" strokeDasharray="2 10" />
                  <circle cx="200" cy="200" r="110" strokeOpacity=".12" />
                  <path d="M200 10 A190 190 0 0 1 390 200" strokeOpacity=".28" strokeWidth="2" />
                  <path d="M200 90 A110 110 0 0 1 310 200" strokeOpacity=".22" strokeWidth="2" />
                </g>
              </svg>
              <div aria-hidden="true" className="pointer-events-none absolute inset-0 opacity-[0.05] [background-image:linear-gradient(white_1px,transparent_1px),linear-gradient(90deg,white_1px,transparent_1px)] [background-size:36px_36px]" />

              <div className="relative flex h-full min-w-0 flex-col">
                <p className="inline-flex w-fit items-center gap-2 rounded-full border border-white/20 bg-white/10 px-2.5 py-1 text-[11px] font-medium text-white/90 backdrop-blur-sm">
                  <Icon name="shield" className="h-3.5 w-3.5" />
                  {direction} · Direction
                </p>
                <h2 className="men-serif mt-4 max-w-lg text-3xl font-normal leading-[1.1] sm:text-4xl">
                  {chargementDonnees
                    ? 'Chargement des dossiers'
                    : demandes.length > 0
                      ? `${demandes.length} décision${demandes.length > 1 ? 's' : ''} à rendre`
                      : 'Aucun dossier en attente'}
                </h2>
                <p className="mt-3 max-w-md text-xs leading-relaxed text-white/75">
                  {demandes.length > 0
                    ? `Bonjour ${nom || 'Monsieur/Madame le Directeur'}, ${demandes.length} demande${demandes.length > 1 ? 's' : ''} attendent votre avis définitif.`
                    : `Bonjour ${nom || 'Monsieur/Madame le Directeur'}, tous les dossiers ont été traités.`}
                </p>
                <div className="mt-5 flex flex-wrap gap-3">
                  {demandes.length > 0 && (
                    <button type="button" onClick={() => setVue('demandes')} className="group inline-flex h-9 items-center gap-2 rounded-xl bg-white px-4 text-xs font-semibold text-[#00678F] shadow-[0_10px_24px_-12px_rgba(0,0,0,.4)] transition duration-200 hover:bg-[#F3F7FA] active:scale-[.98] focus:outline-none focus-visible:ring-4 focus-visible:ring-white/50">
                      Décider maintenant
                      <Icon name="arrow" className="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-x-1" />
                    </button>
                  )}
                </div>
                <div className="mt-auto pt-5">
                  <div className="mb-1.5 flex items-baseline justify-between text-[11px] text-white/70">
                    <span>Demandes avec visa du chef</span>
                    <span className="tabular-nums">{valeurStat(nombreAvecVisaChef)} sur {valeurStat(total)}</span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-white/15">
                    <div className="rh-bar h-full rounded-full bg-white" style={{ width: `${Math.round(ratioVisaChef * 100)}%`, ...delai(600) }} />
                  </div>
                </div>
              </div>
            </section>

            <section className={`rh-in flex min-w-0 flex-col justify-center gap-4 p-5 sm:flex-row sm:items-center ${carte}`} style={delai(120)}>
              <div className="mx-auto sm:mx-0">
                <Anneau ratio={ratioVisaChef} centre={
                  <div>
                    <p className="men-serif text-4xl leading-none tabular-nums text-[#0F2437]">{pourcentageAffiche}%</p>
                    <p className="mt-1 text-[11px] font-medium text-[#5B6B7C]">visa chef</p>
                  </div>
                } />
              </div>
              <ul className="min-w-0 flex-1 divide-y divide-[#EEF1F5]">
                <li className="pb-3">
                  <div className="flex items-center gap-2 text-xs text-[#5B6B7C]">
                    <span className="h-2 w-2 rounded-full bg-[#0A82B9]" />
                    Avec visa chef
                  </div>
                  <p className="men-serif mt-1 text-2xl tabular-nums text-[#0F2437]">{valeurStat(nombreAvecVisaChef)}</p>
                </li>
                <li className="pt-3">
                  <div className="flex items-center gap-2 text-xs text-[#5B6B7C]">
                    <span className="h-2 w-2 rounded-full bg-amber-500" />
                    Déposées directement
                  </div>
                  <p className="men-serif mt-1 text-2xl tabular-nums text-[#0F2437]">{valeurStat(nombreDeposeesDirectement)}</p>
                </li>
              </ul>
            </section>
          </div>

          {/* Tuiles KPI en dégradé - Ajustées */}
          <div className="grid gap-4 sm:grid-cols-3">
            <TuileKpi
              libelle="Demandes à décider"
              valeur={valeurStat(total)}
              note="En attente d’un avis"
              part={100}
              icone="clock"
              ton="ambre"
              retard={160}
            />
            <TuileKpi
              libelle="Visas chef obtenus"
              valeur={valeurStat(nombreAvecVisaChef)}
              note="Prêtes pour décision"
              part={part(nombreAvecVisaChef)}
              icone="check"
              ton="vert"
              retard={220}
            />
            <TuileKpi
              libelle="Déposées directement"
              valeur={valeurStat(nombreDeposeesDirectement)}
              note="Sans passage par le chef"
              part={part(nombreDeposeesDirectement)}
              icone="file"
              ton="bleu"
              retard={280}
            />
          </div>

          {/* Dernières demandes */}
          <Panneau
            titre="Dernières demandes"
            sousTitre="Les dossiers en attente de votre décision"
            icone="clock"
            accent="#00678F"
            retard={340}
          >
            {chargementDonnees ? (
              <div className="flex min-h-32 items-center justify-center">
                <span role="status" aria-label="Chargement" className="h-6 w-6 animate-spin rounded-full border-2 border-[#00678F]/20 border-t-[#00678F]" />
              </div>
            ) : demandes.length === 0 ? (
              <div className="py-6 text-center">
                <span className="rh-pop mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-[#518929]/10 text-[#3F6F1F]">
                  <Icon name="check" className="h-6 w-6" />
                </span>
                <p className="mt-3 text-sm text-[#5B6B7C]">Rien à examiner</p>
              </div>
            ) : (
              <ul className="-mx-2 space-y-0.5">
                {demandes.slice(0, 5).map((demande, i) => (
                  <li key={demande.id_demande} className="rh-in" style={delai(400 + i * 70)}>
                    <button type="button" onClick={() => ouvrirTiroir(demande)} className="flex w-full items-center gap-3 rounded-xl p-2 text-left transition-colors hover:bg-[#F3F7FA]">
                      <Avatar nom={nomPersonnel(demande)} />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold text-[#0F2437]">{nomPersonnel(demande)}</p>
                        <p className="truncate text-xs text-[#5B6B7C]">
                          {demande.type_absence_libelle || demande.type_absence} · {demande.nombre_jours} j
                        </p>
                      </div>
                      <span className="hidden shrink-0 text-xs text-[#5B6B7C] sm:inline">{dateLisible(demande.date_debut)}</span>
                      <Icon name="right" className="h-4 w-4 shrink-0 text-[#94A3B8]" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </Panneau>
        </>
      )}

      {vue === 'demandes' && (
        <section className={`rh-in min-w-0 overflow-hidden ${carte}`}>
          <div className="flex flex-col gap-4 border-b border-[#E3E8EE] p-4 sm:p-5 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h2 className="text-base font-semibold text-[#0F2437]">Dossiers à examiner</h2>
              <p className="mt-0.5 text-xs text-[#5B6B7C]">
                {chargementDonnees ? 'Chargement…' : `${demandesFiltrees.length} résultat${demandesFiltrees.length > 1 ? 's' : ''} · ${total} au total`}
              </p>
            </div>
            <label className="group relative w-full lg:w-[26rem]">
              <span className="sr-only">Rechercher</span>
              <Icon name="search" className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#94A3B8] transition-colors group-focus-within:text-[#00678F]" />
              <input type="search" value={recherche} onChange={(event) => setRecherche(event.target.value)} placeholder="Nom, numéro, type ou motif" className={`${champ} pl-10`} />
            </label>
          </div>

          {chargementDonnees ? (
            <div className="grid min-h-48 place-items-center">
              <span role="status" className="h-6 w-6 animate-spin rounded-full border-2 border-[#00678F]/20 border-t-[#00678F]" />
            </div>
          ) : demandesFiltrees.length === 0 ? (
            <div className="px-6 py-20 text-center">
              <span className="rh-pop mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-[#00678F]/10 text-[#00678F] ring-8 ring-[#00678F]/5">
                <Icon name="check" className="h-8 w-8" />
              </span>
              <p className="men-serif mt-5 text-3xl text-[#0F2437]">Aucune demande</p>
              <p className="mt-1 text-sm text-[#5B6B7C]">
                {recherche ? 'Aucun dossier ne correspond.' : 'Tous les dossiers ont été traités.'}
              </p>
            </div>
          ) : (
            <>
              <div className="divide-y divide-[#EEF1F5] md:hidden">
                {demandesFiltrees.map((demande) => (
                  <article key={demande.id_demande} className="space-y-3 p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex min-w-0 items-center gap-2.5">
                        <Avatar nom={nomPersonnel(demande)} className="h-9 w-9 text-xs" />
                        <div className="min-w-0">
                          <p className="truncate text-sm font-semibold text-[#0F2437]">{nomPersonnel(demande)}</p>
                          <p className="break-all text-xs text-[#5B6B7C]">{demande.numero_enregistrement || `#${demande.id_demande}`}</p>
                        </div>
                      </div>
                      <span className="max-w-[45%] shrink-0"><BadgeStatut statut={demande.statut_demande} /></span>
                    </div>
                    <dl className="grid grid-cols-2 gap-2 text-xs">
                      <div><dt className="text-[#94A3B8]">Type</dt><dd className="mt-0.5 text-[#3B4864]">{demande.type_absence_libelle || demande.type_absence}</dd></div>
                      <div><dt className="text-[#94A3B8]">Durée</dt><dd className="mt-0.5 text-[#3B4864]">{demande.nombre_jours} j</dd></div>
                      <div><dt className="text-[#94A3B8]">Début</dt><dd className="mt-0.5 text-[#3B4864]">{dateLisible(demande.date_debut)}</dd></div>
                      <div><dt className="text-[#94A3B8]">Fin</dt><dd className="mt-0.5 text-[#3B4864]">{dateLisible(demande.date_fin)}</dd></div>
                    </dl>
                    <button type="button" onClick={() => ouvrirTiroir(demande)} className={`${btnPrimaire} w-full`}>
                      <Icon name="edit" className="h-4 w-4" /> Décider
                    </button>
                  </article>
                ))}
              </div>

              <div className="hidden overflow-x-auto md:block">
                <table className="w-full min-w-[760px] border-collapse text-left text-sm">
                  <thead>
                    <tr className="border-y border-[#E3E8EE] bg-[#F8FAFC] text-xs font-semibold text-[#5B6B7C]">
                      <th scope="col" className="px-6 py-3">Demandeur</th>
                      <th scope="col" className="px-4 py-3">Type</th>
                      <th scope="col" className="px-4 py-3">Période</th>
                      <th scope="col" className="px-4 py-3">Durée</th>
                      <th scope="col" className="px-4 py-3">État</th>
                      <th scope="col" className="px-6 py-3"><span className="sr-only">Action</span></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#EEF1F5]">
                    {demandesFiltrees.map((demande, index) => (
                      <tr key={demande.id_demande} className="rh-in group relative transition-colors hover:bg-[#F3F7FA]" style={delai(Math.min(index, 10) * 40)}>
                        <td className="relative px-6 py-4">
                          <span aria-hidden="true" className="absolute inset-y-3 left-0 w-[3px] origin-center scale-y-0 rounded-r-full bg-[#00678F] transition-transform duration-300 group-hover:scale-y-100" />
                          <div className="flex items-center gap-3">
                            <Avatar nom={nomPersonnel(demande)} className="h-10 w-10 text-xs" />
                            <div className="min-w-0">
                              <p className="truncate font-semibold text-[#0F2437]">{nomPersonnel(demande)}</p>
                              <p className="mt-0.5 truncate text-xs text-[#5B6B7C]">
                                {demande.numero_enregistrement ? `N° ${demande.numero_enregistrement}` : `#${demande.id_demande}`}
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-4 text-[#0F2437]">{demande.type_absence_libelle || demande.type_absence}</td>
                        <td className="px-4 py-4 text-[#0F2437]">
                          <p>{dateLisible(demande.date_debut)}</p>
                          <p className="mt-0.5 text-xs text-[#5B6B7C]">au {dateLisible(demande.date_fin)}</p>
                        </td>
                        <td className="px-4 py-4 font-semibold tabular-nums text-[#0F2437]">{demande.nombre_jours} j</td>
                        <td className="px-4 py-4"><BadgeStatut statut={demande.statut_demande} /></td>
                        <td className="px-6 py-4">
                          <div className="flex justify-end">
                            <button type="button" onClick={() => ouvrirTiroir(demande)} className={btnPrimaire}>
                              <Icon name="edit" className="h-4 w-4" />
                              <span className="hidden lg:inline">Décider</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </section>
      )}

      <Tiroir
        ouvert={tiroirOuvert}
        onFermer={() => setTiroirOuvert(false)}
        titre="Décision de la direction"
        sousTitre={demandeSelectionnee ? nomPersonnel(demandeSelectionnee) : 'Consultez le dossier puis enregistrez votre avis.'}
        pied={
          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:items-center sm:justify-between">
            <button type="button" onClick={() => setTiroirOuvert(false)} disabled={enregistrement} className={`${btnContour} flex-1 sm:flex-none`}>Annuler</button>
            <button type="button" onClick={() => void traiterDemande()} disabled={enregistrement || chargementDonnees} className={`${btnPrimaire} flex-1 sm:flex-none`}>
              {enregistrement ? <Icon name="loader" className="h-4 w-4 animate-spin" /> : <Icon name={avis === 'FAVORABLE' ? 'check' : 'alert'} className="h-4 w-4" />}
              {enregistrement ? 'Enregistrement…' : avis === 'FAVORABLE' ? 'Valider la demande' : 'Rejeter la demande'}
            </button>
          </div>
        }
      >
        {demandeSelectionnee ? (
          <div className="min-w-0 space-y-5">
            <div className="flex min-w-0 items-start gap-3 rounded-2xl border border-[#E3E8EE] bg-white p-4">
              <Avatar nom={nomPersonnel(demandeSelectionnee)} className="h-12 w-12 text-sm" />
              <div className="min-w-0 flex-1">
                <h3 className="text-base font-semibold text-[#0F2437]">{nomPersonnel(demandeSelectionnee)}</h3>
                <p className="mt-0.5 text-xs text-[#5B6B7C]">
                  {demandeSelectionnee.numero_enregistrement ? `N° ${demandeSelectionnee.numero_enregistrement}` : `#${demandeSelectionnee.id_demande}`}
                </p>
                <div className="mt-2"><BadgeStatut statut={demandeSelectionnee.statut_demande} /></div>
              </div>
            </div>

            <div className="rounded-2xl border border-[#E3E8EE] bg-white p-4">
              <dl className="space-y-4 text-sm">
                <div>
                  <dt className="text-xs font-semibold uppercase tracking-wide text-[#94A3B8]">Type d’absence</dt>
                  <dd className="mt-1 font-medium text-[#0F2437]">{demandeSelectionnee.type_absence_libelle || demandeSelectionnee.type_absence}</dd>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <dt className="text-xs font-semibold uppercase tracking-wide text-[#94A3B8]">Début</dt>
                    <dd className="mt-1 font-medium text-[#0F2437]">{dateLisible(demandeSelectionnee.date_debut)}</dd>
                  </div>
                  <div>
                    <dt className="text-xs font-semibold uppercase tracking-wide text-[#94A3B8]">Fin</dt>
                    <dd className="mt-1 font-medium text-[#0F2437]">{dateLisible(demandeSelectionnee.date_fin)}</dd>
                  </div>
                </div>
                <div>
                  <dt className="text-xs font-semibold uppercase tracking-wide text-[#94A3B8]">Durée</dt>
                  <dd className="mt-1 font-medium text-[#0F2437]">{demandeSelectionnee.nombre_jours} jour(s)</dd>
                </div>
                {demandeSelectionnee.annee_titre && (
                  <div>
                    <dt className="text-xs font-semibold uppercase tracking-wide text-[#94A3B8]">Année au titre du congé</dt>
                    <dd className="mt-1 font-medium text-[#0F2437]">{demandeSelectionnee.annee_titre}</dd>
                  </div>
                )}
                <div>
                  <dt className="text-xs font-semibold uppercase tracking-wide text-[#94A3B8]">Lieu de jouissance</dt>
                  <dd className="mt-1 text-[#3B4864]">{demandeSelectionnee.lieu_jouissance || 'Non renseigné'}</dd>
                </div>
                <div>
                  <dt className="text-xs font-semibold uppercase tracking-wide text-[#94A3B8]">Motif</dt>
                  <dd className="mt-1 whitespace-pre-wrap leading-relaxed text-[#3B4864]">{demandeSelectionnee.motif || 'Aucun motif renseigné.'}</dd>
                </div>
                {demandeSelectionnee.justificatif_url && (
                  <div>
                    <dt className="text-xs font-semibold uppercase tracking-wide text-[#94A3B8]">Justificatif</dt>
                    <dd className="mt-1">
                      <a href={demandeSelectionnee.justificatif_url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 font-semibold text-[#00678F] hover:text-[#005A7D]">
                        <Icon name="file" className="h-4 w-4" /> Consulter le justificatif
                      </a>
                    </dd>
                  </div>
                )}
              </dl>
            </div>

            <div>
              <h3 className="mb-3 text-sm font-semibold text-[#0F2437]">Historique des avis</h3>
              <HistoriqueAvis validations={demandeSelectionnee.validations ?? []} />
            </div>

            <form onSubmit={(event) => { event.preventDefault(); void traiterDemande() }} className="space-y-4">
              <fieldset disabled={enregistrement || chargementDonnees} className="min-w-0">
                <legend className="mb-2.5 flex w-full items-center gap-2 text-xs font-semibold uppercase tracking-[0.1em] text-[#00678F]">
                  <span className="grid h-6 w-6 place-items-center rounded-md bg-[#00678F]/10">
                    <Icon name="edit" className="h-3.5 w-3.5" />
                  </span>
                  Votre avis
                </legend>
                <div className="grid grid-cols-1 gap-3 rounded-xl border border-[#E3E8EE] bg-white p-3 sm:grid-cols-2 sm:p-4">
                  <label className={`flex cursor-pointer items-center gap-2 rounded-lg border p-3 text-sm font-semibold transition ${avis === 'FAVORABLE' ? 'border-[#518929]/40 bg-[#518929]/10 text-[#3F6F1F]' : 'border-[#E3E8EE] text-[#5B6B7C] hover:bg-[#F8FAFC]'}`}>
                    <input type="radio" name="avis-directeur" value="FAVORABLE" checked={avis === 'FAVORABLE'} onChange={() => setAvis('FAVORABLE')} className="accent-[#518929]" />
                    Favorable
                  </label>
                  <label className={`flex cursor-pointer items-center gap-2 rounded-lg border p-3 text-sm font-semibold transition ${avis === 'DEFAVORABLE' ? 'border-rose-400 bg-rose-50 text-rose-800' : 'border-[#E3E8EE] text-[#5B6B7C] hover:bg-[#F8FAFC]'}`}>
                    <input type="radio" name="avis-directeur" value="DEFAVORABLE" checked={avis === 'DEFAVORABLE'} onChange={() => setAvis('DEFAVORABLE')} className="accent-rose-600" />
                    Défavorable
                  </label>
                </div>
              </fieldset>

              <div>
                <label htmlFor="observation-directeur" className="mb-1.5 block text-sm font-medium text-[#0F2437]">Observation</label>
                <textarea id="observation-directeur" value={observation} onChange={(event) => setObservation(event.target.value)} rows={4} disabled={enregistrement} placeholder="Précisez votre décision ou son motif…" className={zoneTexte} />
                <p className="mt-1.5 text-xs text-[#94A3B8]">Certaines catégories d’absence exigent une observation motivée.</p>
              </div>

              {erreurAction && <Message type="erreur">{erreurAction}</Message>}
            </form>
          </div>
        ) : (
          <div className="py-12 text-center">
            <span className="rh-pop mx-auto grid h-12 w-12 place-items-center rounded-full bg-[#00678F]/10 text-[#00678F]">
              <Icon name="file" className="h-6 w-6" />
            </span>
            <p className="men-serif mt-3 text-2xl text-[#0F2437]">Détail de la demande</p>
            <p className="mt-2 text-sm text-[#5B6B7C]">Sélectionnez une demande dans la liste pour commencer.</p>
          </div>
        )}
      </Tiroir>
    </CoquilleDirecteur>
  )
}

export default DashboardDirecteurPage