import { useCallback, useEffect, useState } from 'react'
import { isAxiosError } from 'axios'
import { Navigate } from 'react-router'

import { useAuth } from '../../contexts/useAuth'
import {
  listerDemandesEnAttenteService,
  listerPersonnelsDuService,
  listerPlanningService,
  type AbsencePlanning,
  type DemandeEnAttente,
  type PersonnelEquipe,
} from '../../services/chefServiceService'
import { Icon, Message, type IconName } from '../../components/men/ui'
import { delai, useCompteur } from '../../components/men/ui-outils'
import {
  CoquilleService,
  type VueService,
} from '../../components/men/miseEnPageRH'

const TITRES_VUES: Record<VueService, { titre: string; description: string }> = {
  apercu: { titre: 'Vue d’ensemble', description: 'Suivi global des demandes et du service' },
  demandes: { titre: 'Demandes à examiner', description: 'Demandes en attente de visa' },
  personnels: { titre: 'Mon équipe', description: 'Agents rattachés à votre service' },
  planning: { titre: 'Planning', description: 'Calendrier des absences du service' },
  'nouvelle-demande': { titre: 'Nouvelle demande', description: 'Déposer une demande personnelle' },
}

const LIBELLES_STATUT: Record<string, string> = {
  EN_ATTENTE: 'En attente',
  APPROUVE_CS: 'Approuvé',
  VALIDE_DIR: 'Validé',
  REJETE: 'Rejeté',
}

const COULEUR_STATUT: Record<string, string> = {
  EN_ATTENTE: '#F59E0B',
  APPROUVE_CS: '#0A82B9',
  VALIDE_DIR: '#518929',
  REJETE: '#F43F5E',
}

/* ------------------------------------------------------------------ */
/*  Animations                                                         */
/* ------------------------------------------------------------------ */

const STYLES = `
@keyframes rh-in{from{opacity:0;transform:translate3d(0,14px,0)}to{opacity:1;transform:none}}
@keyframes rh-draw{from{stroke-dashoffset:1}to{stroke-dashoffset:0}}
@keyframes rh-bar{from{transform:scaleX(0)}to{transform:scaleX(1)}}
@keyframes rh-ring{from{stroke-dashoffset:var(--c)}to{stroke-dashoffset:var(--o)}}
@keyframes rh-pulse{0%{box-shadow:0 0 0 0 rgba(217,138,11,.45)}100%{box-shadow:0 0 0 7px rgba(217,138,11,0)}}
@keyframes rh-pop{0%{opacity:0;transform:scale(.92)}100%{opacity:1;transform:none}}
@keyframes rh-fade{from{opacity:0}to{opacity:1}}
@keyframes rh-orbit{to{transform:rotate(360deg)}}
@keyframes rh-sheen{from{transform:translateX(-120%)}to{transform:translateX(280%)}}

.rh-in{animation:rh-in .6s cubic-bezier(.22,1,.36,1) var(--d,0ms) backwards}
.rh-draw{stroke-dasharray:1;animation:rh-draw 1.5s cubic-bezier(.4,0,.2,1) var(--d,150ms) backwards}
.rh-bar{transform-origin:left center;animation:rh-bar .9s cubic-bezier(.22,1,.36,1) var(--d,0ms) backwards}
.rh-ring{animation:rh-ring 1.3s cubic-bezier(.22,1,.36,1) var(--d,300ms) backwards}
.rh-pulse{animation:rh-pulse 1.8s ease-out infinite}
.rh-pop{animation:rh-pop .45s cubic-bezier(.22,1,.36,1) backwards}
.rh-fade{animation:rh-fade .7s ease-out var(--d,0ms) backwards}
.rh-orbit{transform-origin:center;animation:rh-orbit 80s linear infinite}
.rh-sheen::after{content:"";position:absolute;inset:0;width:36%;pointer-events:none;
  background:linear-gradient(100deg,transparent,rgba(255,255,255,.18),transparent);
  animation:rh-sheen 1.5s cubic-bezier(.4,0,.2,1) var(--d,600ms) 1 backwards}

.men-serif{font-family:var(--font-serif,Georgia,'Times New Roman',serif);font-weight:500;letter-spacing:-.01em}

@media (prefers-reduced-motion:reduce){
  .rh-in,.rh-draw,.rh-bar,.rh-ring,.rh-pulse,.rh-pop,.rh-fade,.rh-orbit,.rh-sheen::after{animation:none!important}
  .rh-draw{stroke-dasharray:none}
}
`

/* ------------------------------------------------------------------ */
/*  Styles partagés                                                    */
/* ------------------------------------------------------------------ */

const carte =
  'rounded-[20px] border border-[#E3E8EE] bg-white shadow-[0_1px_2px_rgba(15,36,55,0.04),0_10px_28px_-18px_rgba(15,36,55,0.14)]'

const btnPrimaire =
  'inline-flex h-10 items-center justify-center gap-2 rounded-xl bg-[#00678F] px-4 text-sm font-semibold text-white shadow-[0_1px_2px_rgba(0,103,143,.3),0_8px_16px_-8px_rgba(0,103,143,.55)] transition duration-200 hover:bg-[#005A7D] active:scale-[.98] focus:outline-none focus-visible:ring-4 focus-visible:ring-[#00678F]/25 disabled:pointer-events-none disabled:opacity-60'

const btnContour =
  'inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-[#D5DCE5] bg-white px-4 text-sm font-semibold text-[#0F2437] transition duration-200 hover:border-[#C0CBD7] hover:bg-[#F3F6F9] active:scale-[.98] focus:outline-none focus-visible:ring-4 focus-visible:ring-[#00678F]/15 disabled:pointer-events-none disabled:opacity-60'

const champ =
  'h-11 w-full rounded-xl border border-[#D5DCE5] bg-white px-3.5 text-sm text-[#0F2437] outline-none transition duration-200 placeholder:text-[#94A3B8] hover:border-[#B8C4D1] focus:border-[#00678F] focus:ring-4 focus:ring-[#00678F]/15 disabled:bg-[#F3F5F8] disabled:text-[#94A3B8]'

const TONS_KPI = {
  bleu: {
    fond: 'from-[#0A5378] via-[#00678F] to-[#0A82B9]',
    ombre: 'shadow-[0_22px_38px_-22px_rgba(0,103,143,.8)]',
  },
  bleuMoyen: {
    fond: 'from-[#0A6C99] via-[#0A82B9] to-[#38BDF8]',
    ombre: 'shadow-[0_22px_38px_-22px_rgba(10,130,185,.8)]',
  },
  vert: {
    fond: 'from-[#2F6A1A] via-[#3F7D20] to-[#5B9A33]',
    ombre: 'shadow-[0_22px_38px_-22px_rgba(63,125,32,.8)]',
  },
  ambre: {
    fond: 'from-[#9A4A0A] via-[#B45309] to-[#D97706]',
    ombre: 'shadow-[0_22px_38px_-22px_rgba(180,83,9,.8)]',
  },
} as const

const AVATARS = [
  'bg-[#00678F]/10 text-[#00678F]',
  'bg-[#518929]/10 text-[#3F6F1F]',
  'bg-slate-500/10 text-slate-700',
  'bg-[#0A3D5C]/10 text-[#0A3D5C]',
  'bg-amber-500/10 text-amber-800',
]

/* ------------------------------------------------------------------ */
/*  Utilitaires                                                        */
/* ------------------------------------------------------------------ */

function dateISO(date: Date): string {
  const annee = date.getFullYear()
  const mois = String(date.getMonth() + 1).padStart(2, '0')
  const jour = String(date.getDate()).padStart(2, '0')
  return `${annee}-${mois}-${jour}`
}

function dateLisible(date: string): string {
  if (!date) return '—'
  const valeur = new Date(`${date.slice(0, 10)}T12:00:00`)
  if (Number.isNaN(valeur.getTime())) return '—'
  return new Intl.DateTimeFormat('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' }).format(valeur)
}

function erreurAPI(erreur: unknown): string {
  if (isAxiosError(erreur)) {
    if (erreur.response?.status === 401) return 'Votre session a expiré.'
    if (erreur.response?.status === 403) return 'Autorisations insuffisantes.'
    if (!erreur.response) return 'Le serveur est injoignable.'
    const detail = erreur.response.data?.detail
    if (typeof detail === 'string') return detail
  }
  return 'Impossible de charger ces informations.'
}

function classeStatut(statut: string): string {
  switch (statut) {
    case 'EN_ATTENTE': return 'bg-amber-500/10 text-amber-700'
    case 'APPROUVE_CS': return 'bg-[#0A82B9]/10 text-[#0A82B9]'
    case 'VALIDE_DIR': return 'bg-[#518929]/10 text-[#3F6F1F]'
    case 'REJETE': return 'bg-rose-500/10 text-rose-700'
    default: return 'bg-slate-500/10 text-[#475569]'
  }
}

function libelleStatut(statut: string): string {
  return LIBELLES_STATUT[statut] ?? statut.replaceAll('_', ' ')
}

function nomAgent(personnel: PersonnelEquipe): string {
  return personnel.nom_complet || `${personnel.prenoms} ${personnel.nom}`
}

function initiales(nom: string): string {
  const lettres = nom.split(/\s+/).filter(Boolean).slice(0, 2).map((m) => m[0]?.toUpperCase()).join('')
  return lettres || '?'
}

function teinteAvatar(nom: string): string {
  const somme = [...nom].reduce((total, c) => total + c.charCodeAt(0), 0)
  return AVATARS[somme % AVATARS.length]
}

/* ------------------------------------------------------------------ */
/*  Composants locaux                                                  */
/* ------------------------------------------------------------------ */

function Avatar({ nom, className = 'h-9 w-9 text-[10px]' }: { nom: string; className?: string }) {
  return (
    <span aria-hidden="true" className={`grid shrink-0 place-items-center rounded-full font-bold ring-1 ring-inset ring-black/5 ${teinteAvatar(nom)} ${className}`}>
      {initiales(nom)}
    </span>
  )
}

function BadgeStatut({ statut }: { statut: string }) {
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${classeStatut(statut)}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${statut === 'VALIDE_DIR' ? 'bg-[#518929]' : statut === 'REJETE' ? 'bg-rose-500' : statut === 'APPROUVE_CS' ? 'bg-[#0A82B9]' : 'rh-pulse bg-amber-500'}`} />
      {libelleStatut(statut)}
    </span>
  )
}

function TuileKpi({ libelle, valeur, note, part, icone, ton, retard }: {
  libelle: string
  valeur: number
  note: string
  part: number
  icone: IconName
  ton: keyof typeof TONS_KPI
  retard: number
}) {
  const affiche = useCompteur(valeur)
  const s = TONS_KPI[ton]
  const pct = Math.min(100, Math.max(0, part))

  return (
    <div
      className={`rh-in rh-sheen relative overflow-hidden rounded-[20px] bg-gradient-to-br p-4 text-white sm:p-5 ${s.fond} ${s.ombre}`}
      style={{ ...delai(retard), '--d': `${retard}ms` } as React.CSSProperties}
    >
      <svg aria-hidden="true" viewBox="0 0 200 200" className="pointer-events-none absolute -right-10 -top-12 h-40 w-40 text-white">
        <g className="rh-orbit" fill="none" stroke="currentColor">
          <circle cx="100" cy="100" r="90" strokeOpacity=".12" />
          <circle cx="100" cy="100" r="64" strokeOpacity=".16" strokeDasharray="2 8" />
          <path d="M100 10 A90 90 0 0 1 190 100" strokeOpacity=".4" strokeWidth="2" strokeLinecap="round" />
        </g>
      </svg>
      <div className="relative flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-semibold text-white/85">{libelle}</p>
          <p className="men-serif mt-1.5 text-4xl leading-none tabular-nums">{affiche}</p>
        </div>
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-white/15 ring-1 ring-inset ring-white/25 backdrop-blur-sm">
          <Icon name={icone} className="h-4 w-4" />
        </span>
      </div>
      <div className="relative mt-4">
        <div className="mb-1 flex items-baseline justify-between text-[11px] text-white/85">
          <span>{note}</span>
          <span className="font-bold tabular-nums text-white">{Math.round(pct)}%</span>
        </div>
        <div className="h-1 overflow-hidden rounded-full bg-white/20">
          <div className="rh-bar h-full rounded-full bg-white" style={{ width: `${pct}%`, ...delai(retard + 350) }} />
        </div>
      </div>
    </div>
  )
}

function Panneau({ titre, sousTitre, icone, accent, action, retard, className = '', children }: {
  titre: string
  sousTitre?: string
  icone: IconName
  accent: string
  action?: React.ReactNode
  retard: number
  className?: string
  children: React.ReactNode
}) {
  return (
    <section className={`rh-in relative flex min-w-0 flex-col overflow-hidden p-4 sm:p-5 ${carte} ${className}`} style={delai(retard)}>
      <header className="mb-4 flex items-center justify-between gap-3">
        <div className="flex min-w-0 items-center gap-2.5">
          <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg" style={{ backgroundColor: `${accent}1A`, color: accent }}>
            <Icon name={icone} className="h-4 w-4" />
          </span>
          <div className="min-w-0">
            <h2 className="text-sm font-bold text-[#0F2437]">{titre}</h2>
            {sousTitre && <p className="text-[11px] text-[#5B6B7C]">{sousTitre}</p>}
          </div>
        </div>
        {action}
      </header>
      <div className="flex flex-1 flex-col justify-center">{children}</div>
    </section>
  )
}

function Donut({ segments, taille = 110, epaisseur = 12, centre }: {
  segments: { libelle: string; valeur: number; couleur: string }[]
  taille?: number
  epaisseur?: number
  centre?: React.ReactNode
}) {
  const total = segments.reduce((s, seg) => s + seg.valeur, 0) || 1
  const r = (taille - epaisseur) / 2
  const c = 2 * Math.PI * r
  let offset = 0

  return (
    <div className="relative shrink-0" style={{ width: taille, height: taille }}>
      <svg width={taille} height={taille} viewBox={`0 0 ${taille} ${taille}`} className="-rotate-90 drop-shadow-sm">
        <circle cx={taille / 2} cy={taille / 2} r={r} fill="none" stroke="#EAEFF4" strokeWidth={epaisseur} />
        {segments.map((seg, i) => {
          const dash = (seg.valeur / total) * c
          const el = (
            <circle
              key={i}
              className="rh-ring"
              cx={taille / 2}
              cy={taille / 2}
              r={r}
              fill="none"
              stroke={seg.couleur}
              strokeWidth={epaisseur}
              strokeLinecap="round"
              strokeDasharray={c}
              strokeDashoffset={c - dash}
              style={{ '--c': c, '--o': offset, transform: `rotate(${(offset / c) * 360}deg)`, transformOrigin: 'center' } as React.CSSProperties}
            />
          )
          offset += dash
          return el
        })}
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">{centre}</div>
    </div>
  )
}

function Legende({ segments }: { segments: { libelle: string; valeur: number; couleur: string }[] }) {
  const total = segments.reduce((s, seg) => s + seg.valeur, 0) || 1
  return (
    <ul className="min-w-0 flex-1 space-y-2">
      {segments.map((seg, i) => (
        <li key={i} className="flex items-center justify-between gap-2 text-[11px]">
          <span className="flex min-w-0 items-center gap-1.5 font-medium text-[#0F2437]">
            <span className="h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: seg.couleur }} />
            <span className="truncate">{seg.libelle}</span>
          </span>
          <span className="shrink-0 font-semibold tabular-nums text-[#0F2437]">
            {seg.valeur}
            <span className="ml-1 text-[#94A3B8]">{Math.round((seg.valeur / total) * 100)}%</span>
          </span>
        </li>
      ))}
    </ul>
  )
}

/* ------------------------------------------------------------------ */
/*  Mini-calendrier                                                    */
/* ------------------------------------------------------------------ */

const JOURS_SEMAINE = ['L', 'M', 'M', 'J', 'V', 'S', 'D']

function MiniCalendrier({ absences }: { absences: AbsencePlanning[] }) {
  const aujourdhui = dateISO(new Date())
  const [mois, setMois] = useState(() => {
    const maintenant = new Date()
    return new Date(maintenant.getFullYear(), maintenant.getMonth(), 1)
  })
  const [jourChoisi, setJourChoisi] = useState<string>(aujourdhui)

  const decalage = (mois.getDay() + 6) % 7
  const nombreJours = new Date(mois.getFullYear(), mois.getMonth() + 1, 0).getDate()
  const cases: (number | null)[] = [
    ...Array.from({ length: decalage }, () => null),
    ...Array.from({ length: nombreJours }, (_, index) => index + 1),
  ]

  function absentsDu(iso: string): AbsencePlanning[] {
    return absences.filter((a) => a.date_debut.slice(0, 10) <= iso && a.date_fin.slice(0, 10) >= iso)
  }

  function changerMois(variation: number) {
    setMois((precedent) => new Date(precedent.getFullYear(), precedent.getMonth() + variation, 1))
  }

  const libelleMois = new Intl.DateTimeFormat('fr-FR', { month: 'long', year: 'numeric' }).format(mois)
  const absentsChoisis = absentsDu(jourChoisi)

  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <button type="button" onClick={() => changerMois(-1)} aria-label="Mois précédent" className="grid h-7 w-7 place-items-center rounded-lg border border-[#D5DCE5] bg-white text-[#0F2437] transition hover:bg-[#F3F6F9] active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00678F]/40">
          <Icon name="left" className="h-3.5 w-3.5" />
        </button>
        <p className="text-xs font-semibold capitalize text-[#0F2437]">{libelleMois}</p>
        <button type="button" onClick={() => changerMois(1)} aria-label="Mois suivant" className="grid h-7 w-7 place-items-center rounded-lg border border-[#D5DCE5] bg-white text-[#0F2437] transition hover:bg-[#F3F6F9] active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00678F]/40">
          <Icon name="right" className="h-3.5 w-3.5" />
        </button>
      </div>

      <div className="grid grid-cols-7 gap-1 text-center">
        {JOURS_SEMAINE.map((lettre, index) => (
          <span key={index} className="py-1 text-[9px] font-semibold uppercase text-[#94A3B8]">{lettre}</span>
        ))}
        {cases.map((jour, index) => {
          if (jour === null) return <span key={`vide-${index}`} />
          const iso = dateISO(new Date(mois.getFullYear(), mois.getMonth(), jour))
          const nombre = absentsDu(iso).length
          const estChoisi = iso === jourChoisi
          const estAujourdhui = iso === aujourdhui

          return (
            <button
              key={iso}
              type="button"
              onClick={() => setJourChoisi(iso)}
              className={`relative mx-auto grid h-7 w-7 place-items-center rounded-lg text-[11px] font-medium tabular-nums transition focus:outline-none ${
                nombre >= 2
                  ? 'bg-[#00678F] font-semibold text-white shadow-sm'
                  : nombre === 1
                    ? 'bg-[#00678F]/10 font-semibold text-[#00678F]'
                    : 'text-[#3B4864] hover:bg-[#F3F6F9]'
              } ${estChoisi ? 'ring-2 ring-[#00678F] ring-offset-1 ring-offset-white' : ''} ${
                estAujourdhui && nombre === 0 ? 'border border-[#00678F]/40' : ''
              }`}
            >
              {jour}
              {nombre > 0 && (
                <span className={`absolute -bottom-0.5 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full ${nombre >= 2 ? 'bg-white' : 'bg-[#00678F]'}`} />
              )}
            </button>
          )
        })}
      </div>

      <div className="mt-3 rounded-xl border border-[#E3E8EE] bg-[#F7F9FB] p-3">
        <p className="text-[11px] font-semibold text-[#0F2437]">Absents le {dateLisible(jourChoisi)}</p>
        {absentsChoisis.length === 0 ? (
          <p className="mt-1 text-[11px] text-[#5B6B7C]">Personne d’absent ce jour.</p>
        ) : (
          <ul className="mt-2 space-y-1.5">
            {absentsChoisis.map((absence) => (
              <li key={absence.id_demande} className="flex items-center gap-2 text-[11px]">
                <Avatar nom={absence.personnel_nom} className="h-5 w-5 text-[8px]" />
                <span className="min-w-0 flex-1 truncate font-medium text-[#0F2437]">{absence.personnel_nom}</span>
                <span className="shrink-0 text-[10px] text-[#5B6B7C]">{absence.type_absence_libelle || absence.type_absence}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}

/* ================================================================== */
/*  Page                                                               */
/* ================================================================== */

export function DashboardChefServicePage() {
  const { utilisateur, chargement } = useAuth()
  const serviceId = utilisateur?.personnel?.service ?? null
  const [vue, setVue] = useState<VueService>('apercu')

  const [personnels, setPersonnels] = useState<PersonnelEquipe[]>([])
  const [demandes, setDemandes] = useState<DemandeEnAttente[]>([])
  const [planning, setPlanning] = useState<AbsencePlanning[]>([])
  const [rechercheEquipe, setRechercheEquipe] = useState('')

  const [erreurPersonnel, setErreurPersonnel] = useState('')
  const [erreurDemandes, setErreurDemandes] = useState('')
  const [erreurPlanning, setErreurPlanning] = useState('')
  const [chargementDonnees, setChargementDonnees] = useState(true)

  const chargerDashboard = useCallback(async () => {
    if (!serviceId) { setChargementDonnees(false); return }

    const maintenant = new Date()
    const debutPeriode = new Date(maintenant.getFullYear(), maintenant.getMonth(), 1)
    const finPeriode = new Date(maintenant)
    finPeriode.setDate(finPeriode.getDate() + 30)

    const debut = dateISO(debutPeriode)
    const fin = dateISO(finPeriode)

    const [resultatPersonnel, resultatDemandes, resultatPlanning] = await Promise.allSettled([
      listerPersonnelsDuService(serviceId),
      listerDemandesEnAttenteService(),
      listerPlanningService(debut, fin),
    ])

    if (resultatPersonnel.status === 'fulfilled') {
      setPersonnels(resultatPersonnel.value)
      setErreurPersonnel('')
    } else {
      setPersonnels([])
      setErreurPersonnel(erreurAPI(resultatPersonnel.reason))
    }

    if (resultatDemandes.status === 'fulfilled') {
      setDemandes(resultatDemandes.value)
      setErreurDemandes('')
    } else {
      setDemandes([])
      setErreurDemandes(erreurAPI(resultatDemandes.reason))
    }

    if (resultatPlanning.status === 'fulfilled') {
      setPlanning(resultatPlanning.value)
      setErreurPlanning('')
    } else {
      setPlanning([])
      setErreurPlanning(erreurAPI(resultatPlanning.reason))
    }

    setChargementDonnees(false)
  }, [serviceId])

  useEffect(() => {
    if (chargement || !utilisateur || !['ROLE_CHEF_SERVICE', 'ROLE_RH'].includes(utilisateur.role) || !serviceId) return
    void chargerDashboard()
  }, [chargement, utilisateur, serviceId, chargerDashboard])

  if (chargement) {
    return (
      <div className="grid min-h-screen place-items-center bg-[#F3F5F8]">
        <span role="status" aria-label="Chargement" className="h-7 w-7 animate-spin rounded-full border-[3px] border-[#00678F]/15 border-t-[#00678F]" />
      </div>
    )
  }

  if (!utilisateur) return <Navigate to="/connexion" replace />
  if (utilisateur.role !== 'ROLE_CHEF_SERVICE' && utilisateur.role !== 'ROLE_RH') return <Navigate to="/app" replace />

  const nom = utilisateur.personnel?.nom_complet || `${utilisateur.personnel?.prenoms ?? ''} ${utilisateur.personnel?.nom ?? ''}`.trim()
  const service = utilisateur.personnel?.service_libelle || 'Service non renseigné'

  if (!serviceId) {
    return (
      <div className="grid min-h-screen place-items-center bg-[#F3F5F8] p-6">
        <section className={`max-w-lg p-8 text-center ${carte}`}>
          <span className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-amber-500/10 text-amber-700">
            <Icon name="alert" className="h-7 w-7" />
          </span>
          <h1 className="men-serif mt-5 text-2xl font-normal text-[#0F2437]">Aucun service associé</h1>
          <p className="mt-2 text-sm text-[#5B6B7C]">Votre compte n’est rattaché à aucun service. Contactez l’administrateur.</p>
        </section>
      </div>
    )
  }

  const valeur = (n: number) => (chargementDonnees ? 0 : n)

  const parStatut = Object.entries(
    planning.reduce<Record<string, number>>((acc, absence) => {
      acc[absence.statut_demande] = (acc[absence.statut_demande] ?? 0) + 1
      return acc
    }, {}),
  ).map(([statut, nombre]) => ({
    libelle: libelleStatut(statut),
    valeur: nombre,
    couleur: COULEUR_STATUT[statut] ?? '#94A3B8',
  }))

  const equipeFiltree = personnels.filter((personnel) => {
    const requete = rechercheEquipe.trim().toLowerCase()
    if (!requete) return true
    return nomAgent(personnel).toLowerCase().includes(requete) || String(personnel.im).toLowerCase().includes(requete)
  })

  const planningTrie = planning.slice().sort((a, b) => a.date_debut.localeCompare(b.date_debut))
  const total = planning.length || 1
  const part = (n: number) => Math.round((n / total) * 100)
  const ratioValides = planning.length ? planning.filter((a) => a.statut_demande === 'VALIDE_DIR').length / planning.length : 0
  const pourcentageAffiche = useCompteur(Math.round(ratioValides * 100))

  const tableauDemandes = (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[700px] border-collapse text-left text-sm">
        <thead>
          <tr className="border-y border-[#E3E8EE] bg-[#F8FAFC] text-xs font-semibold text-[#5B6B7C]">
            <th scope="col" className="px-4 py-2.5">Personnel</th>
            <th scope="col" className="px-3 py-2.5">Type</th>
            <th scope="col" className="px-3 py-2.5">Période</th>
            <th scope="col" className="px-3 py-2.5">Durée</th>
            <th scope="col" className="px-4 py-2.5">État</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#EEF1F5]">
          {demandes.map((demande) => {
            const nomPersonnel = demande.personnel_detail?.nom_complet || `Personnel #${demande.personnel}`
            return (
              <tr key={demande.id_demande} className="rh-in group relative transition-colors duration-200 hover:bg-[#F3F7FA]">
                <td className="relative px-4 py-3">
                  <span className="absolute inset-y-2 left-0 w-[3px] scale-y-0 rounded-r-full bg-[#00678F] transition-transform duration-300 group-hover:scale-y-100" />
                  <div className="flex items-center gap-2.5">
                    <Avatar nom={nomPersonnel} className="h-8 w-8 text-[10px]" />
                    <div className="min-w-0">
                      <p className="truncate font-semibold text-[#0F2437]">{nomPersonnel}</p>
                      {demande.personnel_detail?.im && <p className="mt-0.5 text-[11px] text-[#5B6B7C]">IM : {demande.personnel_detail.im}</p>}
                    </div>
                  </div>
                </td>
                <td className="px-3 py-3 text-[#0F2437]">{demande.type_absence_libelle || demande.type_absence}</td>
                <td className="px-3 py-3 text-[#0F2437]">
                  <p className="text-sm">{dateLisible(demande.date_debut)}</p>
                  <p className="mt-0.5 text-[11px] text-[#5B6B7C]">au {dateLisible(demande.date_fin)}</p>
                </td>
                <td className="px-3 py-3 font-semibold tabular-nums text-[#0F2437]">{demande.nombre_jours} j</td>
                <td className="px-4 py-3"><BadgeStatut statut={demande.statut_demande} /></td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )

  const aucuneDemande = (
    <div className="px-4 py-14 text-center">
      <span className="rh-pop mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-[#518929]/10 text-[#3F6F1F] ring-8 ring-[#518929]/5">
        <Icon name="check" className="h-6 w-6" />
      </span>
      <p className="men-serif mt-4 text-2xl text-[#0F2437]">Aucune demande en attente</p>
    </div>
  )

  const listeAbsences = planningTrie.length === 0 && !erreurPlanning ? (
    <p className="rounded-xl border border-[#E3E8EE] bg-[#F7F9FB] px-4 py-6 text-center text-xs text-[#5B6B7C]">
      Aucune absence prévue sur cette période.
    </p>
  ) : (
    <div className="space-y-2.5">
      {planningTrie.map((absence) => (
        <article key={absence.id_demande} className="rounded-xl border border-[#E3E8EE] bg-white p-3 transition-colors hover:bg-[#FAFBFD]">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
            <div className="flex items-center gap-2.5">
              <Avatar nom={absence.personnel_nom} className="h-8 w-8 text-[10px]" />
              <div>
                <h3 className="text-xs font-semibold text-[#0F2437]">{absence.personnel_nom}</h3>
                <p className="mt-0.5 text-[11px] text-[#5B6B7C]">{absence.type_absence_libelle || absence.type_absence}</p>
              </div>
            </div>
            <BadgeStatut statut={absence.statut_demande} />
          </div>
          <p className="mt-2 inline-flex items-center gap-1.5 text-[11px] text-[#5B6B7C]">
            <Icon name="calendar" className="h-3.5 w-3.5" />
            {dateLisible(absence.date_debut)} <span>au</span> {dateLisible(absence.date_fin)}
            <span className="mx-1">·</span> {absence.nombre_jours} jour(s)
          </p>
        </article>
      ))}
    </div>
  )

  return (
    <CoquilleService
      vue={vue}
      onVue={setVue}
      badges={{ demandes: demandes.length }}
      titre={TITRES_VUES[vue].titre}
      description={TITRES_VUES[vue].description}
      actions={
        <button
          type="button"
          onClick={() => { setChargementDonnees(true); void chargerDashboard() }}
          disabled={chargementDonnees}
          className={`${btnContour} !px-3 !h-9`}
          aria-label="Actualiser"
        >
          <Icon name="refresh" className={`h-4 w-4 ${chargementDonnees ? 'animate-spin' : ''}`} />
          <span className="hidden sm:inline">Actualiser</span>
        </button>
      }
    >
      <style>{STYLES}</style>

      {vue === 'apercu' && (
        <>
          {[erreurDemandes, erreurPersonnel, erreurPlanning].filter(Boolean).map((message) => (
            <Message key={message} type="erreur"><span className="text-xs">{message}</span></Message>
          ))}

          <div className="grid min-w-0 gap-4 lg:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)]">
            <section className="rh-in rh-sheen relative min-w-0 overflow-hidden rounded-[24px] bg-gradient-to-br from-[#0A3D5C] via-[#0A5378] to-[#00678F] p-6 text-white shadow-[0_28px_48px_-28px_rgba(10,61,92,.75)] sm:p-8">
              <svg aria-hidden="true" viewBox="0 0 400 400" className="pointer-events-none absolute -right-24 -top-28 h-[420px] w-[420px] text-white">
                <g className="rh-orbit" fill="none" stroke="currentColor" strokeLinecap="round">
                  <circle cx="200" cy="200" r="190" strokeOpacity=".07" />
                  <circle cx="200" cy="200" r="150" strokeOpacity=".09" strokeDasharray="2 10" />
                  <circle cx="200" cy="200" r="110" strokeOpacity=".12" />
                  <path d="M200 10 A190 190 0 0 1 390 200" strokeOpacity=".28" strokeWidth="2" />
                  <path d="M200 90 A110 110 0 0 1 310 200" strokeOpacity=".22" strokeWidth="2" />
                </g>
              </svg>
              <div aria-hidden="true" className="pointer-events-none absolute inset-0 opacity-[0.05] [background-image:linear-gradient(white_1px,transparent_1px),linear-gradient(90deg,white_1px,transparent_1px)] [background-size:36px_36px]" />

              <div className="relative flex h-full min-w-0 flex-col">
                <p className="inline-flex w-fit items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-medium text-white/90 backdrop-blur-sm">
                  <Icon name="shield" className="h-3.5 w-3.5" />
                  {service}
                </p>
                <h2 className="men-serif mt-5 max-w-lg text-4xl font-normal leading-[1.1] sm:text-5xl">
                  Bonjour {nom || 'Chef de service'}
                </h2>
                <p className="mt-4 max-w-md text-sm leading-relaxed text-white/75">
                  {demandes.length > 0
                    ? `${demandes.length} demande${demandes.length > 1 ? 's' : ''} attendent votre visa.`
                    : 'Aucune demande en attente de visa.'}
                </p>
                <div className="mt-6 flex flex-wrap gap-3">
                  {demandes.length > 0 && (
                    <button type="button" onClick={() => setVue('demandes')} className="group inline-flex h-10 items-center gap-2 rounded-xl bg-white px-5 text-sm font-semibold text-[#00678F] shadow-[0_10px_24px_-12px_rgba(0,0,0,.4)] transition duration-200 hover:bg-[#F3F7FA] active:scale-[.98] focus:outline-none focus-visible:ring-4 focus-visible:ring-white/50">
                      Examiner les demandes
                      <Icon name="arrow" className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
                    </button>
                  )}
                </div>
                <div className="mt-auto pt-6">
                  <div className="mb-2 flex items-baseline justify-between text-xs text-white/70">
                    <span>Absences validées</span>
                    <span className="tabular-nums">{valeur(planning.filter((a) => a.statut_demande === 'VALIDE_DIR').length)} sur {valeur(planning.length)}</span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-white/15">
                    <div className="rh-bar h-full rounded-full bg-white" style={{ width: `${Math.round(ratioValides * 100)}%`, ...delai(600) }} />
                  </div>
                </div>
              </div>
            </section>

            <section className={`rh-in flex min-w-0 flex-col justify-center gap-4 p-5 sm:flex-row sm:items-center ${carte}`} style={delai(120)}>
              <div className="mx-auto sm:mx-0">
                <Donut segments={parStatut.length > 0 ? parStatut : [{ libelle: 'Aucune', valeur: 1, couleur: '#EAEFF4' }]} centre={
                  <div>
                    <p className="men-serif text-3xl leading-none tabular-nums text-[#0F2437]">{pourcentageAffiche}%</p>
                    <p className="mt-0.5 text-[11px] font-medium text-[#5B6B7C]">validées</p>
                  </div>
                } />
              </div>
              <div className="min-w-0 flex-1">
                {parStatut.length > 0 ? <Legende segments={parStatut} /> : <p className="text-center text-xs text-[#94A3B8] sm:text-left">Aucune absence</p>}
              </div>
            </section>
          </div>

          <div className="grid gap-4 sm:grid-cols-3">
            <TuileKpi libelle="Personnels" valeur={valeur(personnels.length)} note={erreurPersonnel ? 'Indisponible' : 'Agents du service'} part={100} icone="users" ton="bleu" retard={160} />
            <TuileKpi libelle="À examiner" valeur={valeur(demandes.length)} note={erreurDemandes ? 'Indisponible' : 'En attente de visa'} part={part(demandes.length)} icone="clock" ton="ambre" retard={220} />
            <TuileKpi libelle="Absences" valeur={valeur(planning.length)} note={erreurPlanning ? 'Indisponible' : 'Sur la période'} part={part(planning.length)} icone="calendar" ton="vert" retard={280} />
          </div>

          <div className="grid min-w-0 gap-4 lg:grid-cols-3">
            <Panneau titre="Calendrier des absences" sousTitre="Touchez un jour pour voir les absents" icone="calendar" accent="#00678F" retard={340} className="lg:col-span-2">
              <MiniCalendrier absences={planning} />
            </Panneau>
            <Panneau titre="Par statut" sousTitre="Sur la période" icone="users" accent="#518929" retard={400}>
              {parStatut.length === 0 ? (
                <p className="py-6 text-center text-xs text-[#94A3B8]">Aucune donnée</p>
              ) : (
                <div className="flex flex-col items-center gap-4">
                  <Donut segments={parStatut} centre={
                    <div>
                      <p className="men-serif text-2xl leading-none tabular-nums text-[#0F2437]">{planning.length}</p>
                      <p className="mt-0.5 text-[9px] font-semibold uppercase tracking-wide text-[#5B6B7C]">absences</p>
                    </div>
                  } />
                  <Legende segments={parStatut} />
                </div>
              )}
            </Panneau>
          </div>

          <div className="grid min-w-0 gap-4 lg:grid-cols-2">
            <Panneau titre="À examiner" sousTitre="Dernières demandes" icone="clock" accent="#F59E0B" retard={460} action={
              demandes.length > 0 ? (
                <button type="button" onClick={() => setVue('demandes')} className="shrink-0 rounded-lg px-2.5 py-1 text-xs font-semibold text-[#00678F] transition hover:bg-[#00678F]/10">
                  Tout voir
                </button>
              ) : undefined
            }>
              {demandes.length === 0 ? (
                <p className="py-4 text-center text-xs text-[#5B6B7C]">Rien à examiner</p>
              ) : (
                <ul className="-mx-2 space-y-0.5">
                  {demandes.slice(0, 4).map((demande) => {
                    const nomPersonnel = demande.personnel_detail?.nom_complet || `Personnel #${demande.personnel}`
                    return (
                      <li key={demande.id_demande} className="flex items-center gap-2.5 rounded-xl p-2 transition-colors hover:bg-[#F3F7FA]">
                        <Avatar nom={nomPersonnel} className="h-8 w-8 text-[10px]" />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-xs font-semibold text-[#0F2437]">{nomPersonnel}</p>
                          <p className="truncate text-[11px] text-[#5B6B7C]">{demande.type_absence_libelle || demande.type_absence} · {demande.nombre_jours} j</p>
                        </div>
                        <span className="hidden shrink-0 text-[11px] text-[#5B6B7C] sm:inline">{dateLisible(demande.date_debut)}</span>
                      </li>
                    )
                  })}
                </ul>
              )}
            </Panneau>

            <Panneau titre="Mon équipe" sousTitre={`${personnels.length} agent${personnels.length > 1 ? 's' : ''}`} icone="users" accent="#0A82B9" retard={520} action={
              personnels.length > 0 ? (
                <button type="button" onClick={() => setVue('personnels')} className="shrink-0 rounded-lg px-2.5 py-1 text-xs font-semibold text-[#00678F] transition hover:bg-[#00678F]/10">
                  Tout voir
                </button>
              ) : undefined
            }>
              {personnels.length === 0 ? (
                <p className="py-4 text-center text-xs text-[#5B6B7C]">Aucun personnel</p>
              ) : (
                <ul className="-mx-2 space-y-0.5">
                  {personnels.slice(0, 4).map((personnel) => (
                    <li key={personnel.id_personnel} className="flex items-center gap-2.5 rounded-xl p-2 transition-colors hover:bg-[#F3F7FA]">
                      <Avatar nom={nomAgent(personnel)} className="h-8 w-8 text-[10px]" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-xs font-semibold text-[#0F2437]">{nomAgent(personnel)}</p>
                        <p className="text-[11px] text-[#5B6B7C]">IM : {personnel.im}</p>
                      </div>
                      <span className="hidden shrink-0 text-[11px] font-medium text-[#5B6B7C] sm:block">{personnel.grade || personnel.corps || 'Agent'}</span>
                    </li>
                  ))}
                </ul>
              )}
            </Panneau>
          </div>
        </>
      )}

      {vue === 'demandes' && (
        <section className={`rh-in min-w-0 overflow-hidden ${carte}`}>
          <div className="flex flex-col gap-3 border-b border-[#E3E8EE] p-4 sm:p-5 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h2 className="text-sm font-semibold text-[#0F2437]">Demandes à examiner</h2>
              <p className="mt-0.5 text-[11px] text-[#5B6B7C]">{demandes.length} demande{demandes.length > 1 ? 's' : ''} en attente</p>
            </div>
          </div>
          {erreurDemandes && <div className="p-4"><Message type="erreur"><span className="text-xs">{erreurDemandes}</span></Message></div>}
          {demandes.length === 0 && !erreurDemandes ? aucuneDemande : tableauDemandes}
        </section>
      )}

      {vue === 'personnels' && (
        <>
          {erreurPersonnel && <Message type="erreur"><span className="text-xs">{erreurPersonnel}</span></Message>}

          <div className={`rh-in p-3 ${carte}`}>
            <label className="group relative block">
              <span className="sr-only">Rechercher</span>
              <Icon name="search" className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#94A3B8] transition-colors group-focus-within:text-[#00678F]" />
              <input type="search" value={rechercheEquipe} onChange={(event) => setRechercheEquipe(event.target.value)} placeholder="Nom ou IM" className={`${champ} pl-9 h-10 text-xs`} />
            </label>
          </div>

          {equipeFiltree.length === 0 && !erreurPersonnel ? (
            <p className={`rounded-[20px] px-4 py-10 text-center text-xs text-[#5B6B7C] ${carte}`}>Aucun agent trouvé.</p>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
              {equipeFiltree.map((personnel, index) => (
                <article key={personnel.id_personnel} className={`rh-in relative overflow-hidden p-4 ${carte}`} style={delai(Math.min(index, 10) * 40)}>
                  <div className="flex items-center gap-3">
                    <Avatar nom={nomAgent(personnel)} className="h-10 w-10 text-xs" />
                    <div className="min-w-0">
                      <p className="truncate text-xs font-semibold text-[#0F2437]">{nomAgent(personnel)}</p>
                      <p className="mt-0.5 text-[11px] text-[#5B6B7C]">IM : {personnel.im}</p>
                    </div>
                  </div>
                  <p className="mt-3 inline-flex rounded-lg bg-[#00678F]/10 px-2 py-1 text-[10px] font-semibold text-[#00678F]">
                    {personnel.grade || personnel.corps || 'Personnel'}
                  </p>
                </article>
              ))}
            </div>
          )}
        </>
      )}

      {vue === 'planning' && (
        <>
          {erreurPlanning && <Message type="erreur"><span className="text-xs">{erreurPlanning}</span></Message>}
          <div className="grid gap-4 xl:grid-cols-[340px_1fr]">
            <Panneau titre="Calendrier" sousTitre="Jours avec absences" icone="calendar" accent="#00678F" retard={0} className="self-start">
              <MiniCalendrier absences={planning} />
            </Panneau>
            <Panneau titre="Absences" sousTitre={`${planning.length} événement${planning.length > 1 ? 's' : ''} sur la période`} icone="list" accent="#518929" retard={60}>
              {listeAbsences}
            </Panneau>
          </div>
        </>
      )}

      {vue !== 'apercu' && (
        <div className="flex justify-center pt-2 lg:hidden">
          <button type="button" onClick={() => setVue('apercu')} className={btnPrimaire}>
            Retour à la vue d’ensemble
          </button>
        </div>
      )}
    </CoquilleService>
  )
}

export default DashboardChefServicePage