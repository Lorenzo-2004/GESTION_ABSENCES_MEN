import { useEffect, useRef, useState, type CSSProperties } from 'react'

/* ------------------------------------------------------------------ */
/*  Délai d'animation (lu par .men-rise, .men-draw, .men-bar, etc.)    */
/* ------------------------------------------------------------------ */

export const delai = (ms: number) => ({ '--d': `${ms}ms` }) as CSSProperties

/* ------------------------------------------------------------------ */
/*  Compteur animé (décélération douce, respecte reduced-motion)       */
/* ------------------------------------------------------------------ */

export function useCompteur(cible: number, duree = 1100) {
  const [valeur, setValeur] = useState(0)
  const precedent = useRef(0)

  useEffect(() => {
    const debut = performance.now()
    const depart = precedent.current
    const reduit = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    let id = 0

    const pas = (maintenant: number) => {
      const t = reduit ? 1 : Math.min(1, (maintenant - debut) / duree)
      const progression = 1 - Math.pow(1 - t, 4)
      const courant = Math.round(depart + (cible - depart) * progression)
      precedent.current = courant
      setValeur(courant)
      if (t < 1) id = requestAnimationFrame(pas)
    }

    id = requestAnimationFrame(pas)
    return () => cancelAnimationFrame(id)
  }, [cible, duree])

  return valeur
}

/* ------------------------------------------------------------------ */
/*  Champs de formulaire                                               */
/* ------------------------------------------------------------------ */

export const champBase =
  'w-full rounded-xl border border-[#D5DCE5] bg-white px-3.5 text-sm text-[#0F2437] outline-none transition duration-200 placeholder:text-[#94A3B8] hover:border-[#B8C4D1] focus:border-[#00678F] focus:ring-4 focus:ring-[#00678F]/15 disabled:border-[#E3E8EE] disabled:bg-[#F3F5F8] disabled:text-[#94A3B8]'

export const champ = `h-11 ${champBase}`
export const zoneTexte = `py-3 ${champBase}`

export const etiquette =
  'mb-2 block text-sm font-semibold text-[#0F2437] transition-colors duration-200 group-focus-within:text-[#00678F]'

/* ------------------------------------------------------------------ */
/*  Boutons                                                            */
/* ------------------------------------------------------------------ */

export const boutonPrimaire =
  'inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-xl bg-[#00678F] px-4 text-sm font-semibold text-white shadow-[0_1px_2px_rgba(0,103,143,0.3),0_8px_16px_-8px_rgba(0,103,143,0.55)] transition duration-200 hover:bg-[#005A7D] focus:outline-none focus-visible:ring-4 focus-visible:ring-[#00678F]/25 active:scale-[.98] disabled:pointer-events-none disabled:opacity-50'

export const boutonSecondaire =
  'inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-xl border border-[#D5DCE5] bg-white px-4 text-sm font-semibold text-[#0F2437] transition duration-200 hover:border-[#C0CBD7] hover:bg-[#F3F6F9] focus:outline-none focus-visible:ring-4 focus-visible:ring-[#00678F]/15 active:scale-[.98] disabled:cursor-not-allowed disabled:opacity-50'

/* À utiliser sur fond coloré (bandeaux bleus, en-têtes) */
export const boutonClair =
  'inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-xl bg-white px-4 text-sm font-semibold text-[#00678F] shadow-[0_8px_20px_-10px_rgba(0,0,0,0.35)] transition duration-200 hover:bg-[#F3F7FA] focus:outline-none focus-visible:ring-4 focus-visible:ring-white/40 active:scale-[.98] disabled:pointer-events-none disabled:opacity-60'

export const boutonIcone =
  'grid h-9 w-9 place-items-center rounded-lg text-[#5B6B7C] transition duration-200 hover:bg-[#EDF1F5] hover:text-[#0F2437] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00678F]/40 disabled:opacity-40'

/* ------------------------------------------------------------------ */
/*  Surface                                                            */
/* ------------------------------------------------------------------ */

export const carte =
  'rounded-[20px] border border-[#E3E8EE] bg-white shadow-[0_1px_2px_rgba(15,36,55,0.04),0_10px_28px_-18px_rgba(15,36,55,0.14)]'