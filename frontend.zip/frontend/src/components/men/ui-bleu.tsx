import type { ReactNode } from 'react'
import { Icon, type IconName } from './ui'
import { delai, useCompteur } from './ui-outils'

/* ------------------------------------------------------------------ */
/*  Styles partagés                                                    */
/*  (les noms d'export sont conservés pour ne rien casser ailleurs)    */
/* ------------------------------------------------------------------ */

export const cartePage =
  'rounded-[20px] border border-[#E3E8EE] bg-white shadow-[0_1px_2px_rgba(15,36,55,0.04),0_10px_28px_-18px_rgba(15,36,55,0.14)] transition-shadow duration-300 hover:shadow-[0_1px_2px_rgba(15,36,55,0.05),0_16px_36px_-18px_rgba(15,36,55,0.22)]'

export const btnPrimaire =
  'inline-flex h-10 items-center justify-center gap-2 rounded-xl bg-[#00678F] px-4 text-sm font-semibold text-white shadow-[0_1px_2px_rgba(0,103,143,0.3),0_8px_16px_-8px_rgba(0,103,143,0.55)] transition duration-200 hover:bg-[#005A7D] active:scale-[.98] focus:outline-none focus-visible:ring-4 focus-visible:ring-[#00678F]/25 disabled:pointer-events-none disabled:opacity-60'

export const btnContour =
  'inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-[#D5DCE5] bg-white px-4 text-sm font-semibold text-[#0F2437] transition duration-200 hover:border-[#C0CBD7] hover:bg-[#F3F6F9] active:scale-[.98] focus:outline-none focus-visible:ring-4 focus-visible:ring-[#00678F]/15 disabled:pointer-events-none disabled:opacity-60'

export const btnIcone =
  'grid h-8 w-8 place-items-center rounded-lg text-[#5B6B7C] transition-colors duration-200 hover:bg-[#EDF1F5] hover:text-[#0F2437] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00678F]/40 disabled:opacity-50'

export const etiquette = 'mb-1.5 block text-xs font-semibold text-[#0F2437]'

export const champ =
  'h-11 w-full rounded-xl border border-[#D5DCE5] bg-white px-3.5 text-sm text-[#0F2437] outline-none transition duration-200 placeholder:text-[#94A3B8] hover:border-[#B8C4D1] focus:border-[#00678F] focus:ring-4 focus:ring-[#00678F]/15 disabled:bg-[#F3F5F8] disabled:text-[#94A3B8]'

export const zoneTexte =
  'min-h-[92px] w-full resize-y rounded-xl border border-[#D5DCE5] bg-white px-3.5 py-2.5 text-sm text-[#0F2437] outline-none transition duration-200 placeholder:text-[#94A3B8] hover:border-[#B8C4D1] focus:border-[#00678F] focus:ring-4 focus:ring-[#00678F]/15'

/* ------------------------------------------------------------------ */
/*  Fonds par ton : teintes très légères, bordure assortie             */
/* ------------------------------------------------------------------ */

export const FONDS_FROSTED = {
  bleu: 'border border-[#D5E6EF] bg-[#F3F9FC]',
  vert: 'border border-[#DCE9D2] bg-[#F5F9F1]',
  ambre: 'border border-[#F3E4BF] bg-[#FFFAF0]',
  violet: 'border border-[#E3D9F5] bg-[#F8F5FD]',
  ardoise: 'border border-[#E3E8EE] bg-white',
} as const

export type TonKpi = keyof typeof FONDS_FROSTED

export const CHIPS_FROSTED = {
  bleu: 'bg-[#00678F]/10 text-[#00678F]',
  vert: 'bg-[#518929]/10 text-[#3F6F1F]',
  ambre: 'bg-amber-500/10 text-amber-700',
  violet: 'bg-violet-600/10 text-violet-700',
  ardoise: 'bg-slate-500/10 text-[#475569]',
} as const

const ACCENTS: Record<TonKpi, string> = {
  bleu: '#00678F',
  vert: '#518929',
  ambre: '#D98A0B',
  violet: '#7C3AED',
  ardoise: '#64748B',
}

/* ------------------------------------------------------------------ */
/*  Éléments                                                           */
/* ------------------------------------------------------------------ */

export function Initiales({
  nom, className = 'h-9 w-9 text-xs', ton = 'bleu',
}: {
  nom: string
  className?: string
  ton?: 'bleu' | 'ambre' | 'violet'
}) {
  const lettres =
    nom.split(/\s+/).filter(Boolean).slice(0, 2).map((mot) => mot[0]?.toUpperCase()).join('') || '?'

  const couleurs = {
    bleu: 'bg-[#00678F]/10 text-[#00678F] ring-[#00678F]/15',
    ambre: 'bg-amber-500/10 text-amber-800 ring-amber-500/20',
    violet: 'bg-violet-600/10 text-violet-800 ring-violet-600/20',
  }

  return (
    <span
      aria-hidden="true"
      className={`grid shrink-0 place-items-center rounded-full font-semibold ring-1 ring-inset ${couleurs[ton]} ${className}`}
    >
      {lettres}
    </span>
  )
}

export function TuileKpi({
  libelle, valeur, note, icone, ton, retard,
}: {
  libelle: string
  valeur: number
  note: string
  icone: IconName
  ton: TonKpi
  retard: number
}) {
  const affiche = useCompteur(valeur)

  return (
    <div
      className={`men-rise relative overflow-hidden rounded-[20px] p-6 transition-shadow duration-300 hover:shadow-[0_16px_32px_-20px_rgba(15,36,55,0.3)] ${FONDS_FROSTED[ton]}`}
      style={delai(retard)}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[13px] font-medium text-[#5B6B7C]">{libelle}</p>
          <p className="men-serif mt-2.5 text-4xl leading-none tabular-nums text-[#0F2437]">{affiche}</p>
        </div>

        <span className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl ${CHIPS_FROSTED[ton]}`}>
          <Icon name={icone} className="h-5 w-5" />
        </span>
      </div>

      <p className="mt-4 text-xs text-[#5B6B7C]">{note}</p>

      {/* Filet d'accent : se déploie une fois à l'arrivée */}
      <span
        aria-hidden="true"
        className="men-bar absolute inset-x-0 bottom-0 h-[3px]"
        style={{ ...delai(retard + 350), backgroundColor: ACCENTS[ton] }}
      />
    </div>
  )
}

export function Panneau({
  titre, sousTitre, action, retard = 0, className = '', children,
}: {
  titre: string
  sousTitre?: string
  action?: ReactNode
  retard?: number
  className?: string
  children: ReactNode
}) {
  return (
    <section
      className={`men-rise flex flex-col rounded-[20px] border border-[#E3E8EE] bg-white p-6 shadow-[0_1px_2px_rgba(15,36,55,0.04),0_10px_28px_-18px_rgba(15,36,55,0.14)] ${className}`}
      style={delai(retard)}
    >
      <header className="mb-5 flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h2 className="text-base font-semibold text-[#0F2437]">{titre}</h2>
          {sousTitre && <p className="mt-1 text-xs text-[#5B6B7C]">{sousTitre}</p>}
        </div>
        {action}
      </header>
      <div className="flex flex-1 flex-col justify-center">{children}</div>
    </section>
  )
}

export function Interrupteur({
  libelle, coche, onChange, desactive,
}: {
  libelle: string
  coche: boolean
  onChange: (valeur: boolean) => void
  desactive?: boolean
}) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-xl border border-[#E3E8EE] bg-white px-4 py-3 transition-colors duration-200 hover:border-[#D0D9E3]">
      <span className="text-sm font-semibold text-[#0F2437]">{libelle}</span>
      <button
        type="button"
        role="switch"
        aria-checked={coche}
        aria-label={libelle}
        disabled={desactive}
        onClick={() => onChange(!coche)}
        className={`relative h-6 w-11 shrink-0 rounded-full transition-colors duration-300 focus:outline-none focus-visible:ring-4 focus-visible:ring-[#00678F]/25 disabled:opacity-50 ${
          coche ? 'bg-[#518929]' : 'bg-[#CBD5E1]'
        }`}
      >
        <span
          className={`absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow-[0_1px_3px_rgba(15,36,55,0.3)] transition-transform duration-300 ease-[cubic-bezier(.22,1,.36,1)] ${
            coche ? 'translate-x-5' : 'translate-x-0'
          }`}
        />
      </button>
    </div>
  )
}