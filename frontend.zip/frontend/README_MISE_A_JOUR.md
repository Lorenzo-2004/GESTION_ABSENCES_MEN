# Mise à jour du frontend MEN

## Fonctionnalités intégrées

- Route `ROLE_CHEF_SERVICE` `/app/chef-service/nouvelle-demande` pour déposer une demande personnelle, envoyée au circuit de validation prévu par le backend.
- Dans `Personnels`, une action `Préparer une demande` permet au chef de saisir une demande pour un agent de son service. Le personnel ciblé est recontrôlé à partir du service retourné par l'API.
- Dans `Personnels`, une file de demandes en attente permet au chef d'accorder ou de refuser le visa, avec observation obligatoire pour une permission ou une autorisation.
- Le calendrier `/app/chef-service/planning` continue de lire les absences via `/api/demandes/planning/`.
- Dans `Mes demandes`, le bouton `Aperçu PDF officiel` récupère `/api/demandes/{id}/formulaire/` et affiche le formulaire officiel du backend dans un aperçu intégré, avec téléchargement et impression.
- IM saisi à la connexion : normalisation numérique limitée à six chiffres et message immédiat lorsqu'un IM numérique est incomplet.
- Adresse e-mail des comptes : validation immédiate imposant exactement le domaine `@gmail.com`.
- Lors de la sélection d'une fiche de personnel pour créer un compte, les contraintes IM (6 chiffres), CIN (12 chiffres), nom/prénoms, direction et service sont contrôlées. La création du compte est bloquée si la fiche existante est non conforme.

## Limite importante des formulaires actuels

Dans cette version de l'interface, les champs CIN, nom, prénoms, direction et service sont des données de fiches de personnel consultées en lecture seule ; il n'existe pas de page frontend dédiée à leur création ou modification. Ces données sont donc signalées et vérifiées au moment de la sélection d'une fiche, mais ne peuvent pas être corrigées depuis cette page. Pour imposer les règles à toutes les sources (API, imports, autres clients), il faudra aussi ajouter les validations correspondantes côté backend et dans un futur formulaire de gestion des personnels.

## Vérification

Le contrôle TypeScript `tsc -b` passe après les modifications. Le bundle Vite n'a pas pu être recompilé dans l'environnement d'édition, car les dépendances natives `rolldown` incluses dans l'archive sont pour Windows et le binaire Linux requis n'était pas présent. Sur le poste Windows du projet, exécuter :

```powershell
npm run build
```

L'archive ne contient ni `node_modules`, ni `dist`, ni fichier `.env`.
